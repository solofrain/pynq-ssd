#!/bin/sh

mv 10c.dat tuttemp.dat
mv 10b.dat 10c.dat
mv 10a.dat 10b.dat
mv 10.1.dat 10a.dat
mv tuttemp.dat 10.1.dat

