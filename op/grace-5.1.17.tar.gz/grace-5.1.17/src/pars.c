/* A Bison parser, made from pars.yacc
   by GNU bison 1.35.  */

#define YYBISON 1  /* Identify Bison output.  */

# define	KEY_VAR	257
# define	KEY_VEC	258
# define	KEY_CONST	259
# define	KEY_UNIT	260
# define	KEY_FUNC_I	261
# define	KEY_FUNC_D	262
# define	KEY_FUNC_NN	263
# define	KEY_FUNC_ND	264
# define	KEY_FUNC_DD	265
# define	KEY_FUNC_NND	266
# define	KEY_FUNC_PPD	267
# define	KEY_FUNC_PPPD	268
# define	KEY_FUNC_PPPPD	269
# define	KEY_FUNC_PPPPPD	270
# define	INDEX	271
# define	DATE	272
# define	VAR_D	273
# define	VEC_D	274
# define	CONSTANT	275
# define	UCONSTANT	276
# define	FUNC_I	277
# define	FUNC_D	278
# define	FUNC_NN	279
# define	FUNC_ND	280
# define	FUNC_DD	281
# define	FUNC_NND	282
# define	FUNC_PPD	283
# define	FUNC_PPPD	284
# define	FUNC_PPPPD	285
# define	FUNC_PPPPPD	286
# define	ABOVE	287
# define	ABSOLUTE	288
# define	ALIAS	289
# define	ALT	290
# define	ALTXAXIS	291
# define	ALTYAXIS	292
# define	ANGLE	293
# define	ANTIALIASING	294
# define	APPEND	295
# define	ARRANGE	296
# define	ARROW	297
# define	ASCENDING	298
# define	ASPLINE	299
# define	AUTO	300
# define	AUTOSCALE	301
# define	AUTOTICKS	302
# define	AVALUE	303
# define	AVG	304
# define	BACKGROUND	305
# define	BAR	306
# define	BARDY	307
# define	BARDYDY	308
# define	BASELINE	309
# define	BATCH	310
# define	BEGIN	311
# define	BELOW	312
# define	BETWEEN	313
# define	BLACKMAN	314
# define	BLOCK	315
# define	BOTH	316
# define	BOTTOM	317
# define	BOX	318
# define	CD	319
# define	CENTER	320
# define	CHAR	321
# define	CHART	322
# define	CHRSTR	323
# define	CLEAR	324
# define	CLICK	325
# define	CLIP	326
# define	CLOSE	327
# define	COEFFICIENTS	328
# define	COLOR	329
# define	COMMENT	330
# define	COMPLEX	331
# define	CONSTRAINTS	332
# define	COPY	333
# define	CYCLE	334
# define	DAYMONTH	335
# define	DAYOFWEEKL	336
# define	DAYOFWEEKS	337
# define	DAYOFYEAR	338
# define	DDMMYY	339
# define	DECIMAL	340
# define	DEF	341
# define	DEFAULT	342
# define	DEFINE	343
# define	DEGREESLAT	344
# define	DEGREESLON	345
# define	DEGREESMMLAT	346
# define	DEGREESMMLON	347
# define	DEGREESMMSSLAT	348
# define	DEGREESMMSSLON	349
# define	DESCENDING	350
# define	DESCRIPTION	351
# define	DEVICE	352
# define	DFT	353
# define	DIFFERENCE	354
# define	DISK	355
# define	DOWN	356
# define	DPI	357
# define	DROP	358
# define	DROPLINE	359
# define	ECHO	360
# define	ELLIPSE	361
# define	ENGINEERING	362
# define	ERRORBAR	363
# define	EXIT	364
# define	EXPONENTIAL	365
# define	FFT	366
# define	FILEP	367
# define	FILL	368
# define	FIT	369
# define	FIXED	370
# define	FIXEDPOINT	371
# define	FLUSH	372
# define	FOCUS	373
# define	FOLLOWS	374
# define	FONTP	375
# define	FORCE	376
# define	FORMAT	377
# define	FORMULA	378
# define	FRAMEP	379
# define	FREE	380
# define	FREQUENCY	381
# define	FROM	382
# define	GENERAL	383
# define	GETP	384
# define	GRAPH	385
# define	GRAPHNO	386
# define	GRID	387
# define	HAMMING	388
# define	HANNING	389
# define	HARDCOPY	390
# define	HBAR	391
# define	HELP	392
# define	HGAP	393
# define	HIDDEN	394
# define	HISTOGRAM	395
# define	HMS	396
# define	HORIZI	397
# define	HORIZONTAL	398
# define	HORIZO	399
# define	ID	400
# define	IFILTER	401
# define	IMAX	402
# define	IMIN	403
# define	IN	404
# define	INCREMENT	405
# define	INOUT	406
# define	INT	407
# define	INTEGRATE	408
# define	INTERPOLATE	409
# define	INVDFT	410
# define	INVERT	411
# define	INVFFT	412
# define	JUST	413
# define	KILL	414
# define	LABEL	415
# define	LANDSCAPE	416
# define	LAYOUT	417
# define	LEFT	418
# define	LEGEND	419
# define	LENGTH	420
# define	LINE	421
# define	LINEAR	422
# define	LINESTYLE	423
# define	LINEWIDTH	424
# define	LINK	425
# define	LOAD	426
# define	LOCTYPE	427
# define	LOG	428
# define	LOGARITHMIC	429
# define	LOGIT	430
# define	LOGX	431
# define	LOGXY	432
# define	LOGY	433
# define	MAGIC	434
# define	MAGNITUDE	435
# define	MAJOR	436
# define	MAP	437
# define	MAXP	438
# define	MESH	439
# define	MINP	440
# define	MINOR	441
# define	MMDD	442
# define	MMDDHMS	443
# define	MMDDYY	444
# define	MMDDYYHMS	445
# define	MMSSLAT	446
# define	MMSSLON	447
# define	MMYY	448
# define	MONTHDAY	449
# define	MONTHL	450
# define	MONTHS	451
# define	MONTHSY	452
# define	MOVE	453
# define	NEGATE	454
# define	NEW	455
# define	NONE	456
# define	NONLFIT	457
# define	NORMAL	458
# define	NXY	459
# define	OFF	460
# define	OFFSET	461
# define	OFFSETX	462
# define	OFFSETY	463
# define	OFILTER	464
# define	ON	465
# define	ONREAD	466
# define	OP	467
# define	OPPOSITE	468
# define	OUT	469
# define	PAGE	470
# define	PARA	471
# define	PARAMETERS	472
# define	PARZEN	473
# define	PATTERN	474
# define	PERIOD	475
# define	PERP	476
# define	PHASE	477
# define	PIE	478
# define	PIPE	479
# define	PLACE	480
# define	POINT	481
# define	POLAR	482
# define	POLYI	483
# define	POLYO	484
# define	POP	485
# define	PORTRAIT	486
# define	POWER	487
# define	PREC	488
# define	PREPEND	489
# define	PRINT	490
# define	PS	491
# define	PUSH	492
# define	PUTP	493
# define	RAND	494
# define	READ	495
# define	REAL	496
# define	RECIPROCAL	497
# define	REDRAW	498
# define	REFERENCE	499
# define	REGNUM	500
# define	REGRESS	501
# define	RESIZE	502
# define	RESTRICT	503
# define	REVERSE	504
# define	RIGHT	505
# define	RISER	506
# define	ROT	507
# define	ROUNDED	508
# define	RSUM	509
# define	RULE	510
# define	RUNAVG	511
# define	RUNMAX	512
# define	RUNMED	513
# define	RUNMIN	514
# define	RUNSTD	515
# define	SAVEALL	516
# define	SCALE	517
# define	SCIENTIFIC	518
# define	SCROLL	519
# define	SD	520
# define	SET	521
# define	SETNUM	522
# define	SFORMAT	523
# define	SIGN	524
# define	SIZE	525
# define	SKIP	526
# define	SLEEP	527
# define	SMITH	528
# define	SORT	529
# define	SOURCE	530
# define	SPEC	531
# define	SPLINE	532
# define	SPLIT	533
# define	STACK	534
# define	STACKED	535
# define	STACKEDBAR	536
# define	STACKEDHBAR	537
# define	STAGGER	538
# define	START	539
# define	STOP	540
# define	STRING	541
# define	SUM	542
# define	SUBTITLE	543
# define	SWAP	544
# define	SYMBOL	545
# define	TARGET	546
# define	TICKLABEL	547
# define	TICKP	548
# define	TICKSP	549
# define	TIMER	550
# define	TIMESTAMP	551
# define	TITLE	552
# define	TO	553
# define	TOP	554
# define	TRIANGULAR	555
# define	TYPE	556
# define	UP	557
# define	UPDATEALL	558
# define	USE	559
# define	VERSION	560
# define	VERTI	561
# define	VERTICAL	562
# define	VERTO	563
# define	VGAP	564
# define	VIEW	565
# define	VX1	566
# define	VX2	567
# define	VXMAX	568
# define	VY1	569
# define	VY2	570
# define	VYMAX	571
# define	WELCH	572
# define	WITH	573
# define	WORLD	574
# define	WRAP	575
# define	WRITE	576
# define	WX1	577
# define	WX2	578
# define	WY1	579
# define	WY2	580
# define	X_TOK	581
# define	X0	582
# define	X1	583
# define	XAXES	584
# define	XAXIS	585
# define	XCOR	586
# define	XMAX	587
# define	XMIN	588
# define	XY	589
# define	XYAXES	590
# define	XYBOXPLOT	591
# define	XYCOLOR	592
# define	XYCOLPAT	593
# define	XYDX	594
# define	XYDXDX	595
# define	XYDXDXDYDY	596
# define	XYDXDY	597
# define	XYDY	598
# define	XYDYDY	599
# define	XYHILO	600
# define	XYR	601
# define	XYSIZE	602
# define	XYSTRING	603
# define	XYVMAP	604
# define	XYZ	605
# define	Y_TOK	606
# define	Y0	607
# define	Y1	608
# define	Y2	609
# define	Y3	610
# define	Y4	611
# define	YAXES	612
# define	YAXIS	613
# define	YEAR	614
# define	YMAX	615
# define	YMIN	616
# define	YYMMDD	617
# define	YYMMDDHMS	618
# define	ZERO	619
# define	ZNORM	620
# define	FITPARM	621
# define	FITPMAX	622
# define	FITPMIN	623
# define	NUMBER	624
# define	NEW_TOKEN	625
# define	OR	626
# define	AND	627
# define	GT	628
# define	LT	629
# define	LE	630
# define	GE	631
# define	EQ	632
# define	NE	633
# define	UMINUS	634
# define	NOT	635

#line 1 "pars.yacc"

/*
 * Grace - GRaphing, Advanced Computation and Exploration of data
 * 
 * Home page: http://plasma-gate.weizmann.ac.il/Grace/
 * 
 * Copyright (c) 1991-1995 Paul J Turner, Portland, OR
 * Copyright (c) 1996-2003 Grace Development Team
 * 
 * Maintained by Evgeny Stambulchik
 * 
 * 
 *                           All Rights Reserved
 * 
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 * 
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 * 
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*  
 * 
 * evaluate expressions, commands, parameter files
 * 
 */

#include <config.h>
#include <cmath.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#if defined(HAVE_SYS_PARAM_H)
#  include <sys/param.h>
#endif

/* bison not always handles it well itself */
#if defined(HAVE_ALLOCA_H)
#  include <alloca.h>
#endif

#include "defines.h"
#include "globals.h"
#include "cephes/cephes.h"
#include "device.h"
#include "utils.h"
#include "files.h"
#include "graphs.h"
#include "graphutils.h"
#include "plotone.h"
#include "dlmodule.h"
#include "t1fonts.h"
#include "ssdata.h"
#include "protos.h"
#include "parser.h"
#include "mathstuff.h"

#define MAX_PARS_STRING_LENGTH  4096

#define CAST_DBL_TO_BOOL(x) (fabs(x) < 0.5 ? 0:1)

typedef double (*ParserFnc)();

extern graph *g;

static double  s_result;    /* return value if a scalar expression is scanned*/
static grarr *v_result;    /* return value if a vector expression is scanned*/

static int expr_parsed, vexpr_parsed;

static int interr;

static grarr freelist[100]; 	/* temporary vectors */
static int fcnt = 0;		/* number of the temporary vectors allocated */

static target trgt_pool[100]; 	/* pool of temporary targets */
static int tgtn = 0;		/* number of the temporary targets used */

int naxis = 0;	/* current axis */
static int curline, curbox, curellipse, curstring;
/* these guys attempt to avoid reentrancy problems */
static int gotparams = FALSE, gotread = FALSE, gotnlfit = FALSE; 
int readxformat;
static int nlfit_gno, nlfit_setno, nlfit_nsteps;
static double *nlfit_warray = NULL;

char batchfile[GR_MAXPATHLEN] = "",
     paramfile[GR_MAXPATHLEN] = "",
     readfile[GR_MAXPATHLEN] = "";

static char f_string[MAX_PARS_STRING_LENGTH]; /* buffer for string to parse */
static int pos;

/* the graph, set, and its length of the parser's current state */
static int whichgraph;
static int whichset;

/* the graph and set of the left part of a vector assignment */
static int vasgn_gno;
static int vasgn_setno;

static int alias_force = FALSE; /* controls whether aliases can override
                                                       existing keywords */

extern char print_file[];
extern char *close_input;

static int filltype_obs;

static int index_shift = 0;     /* 0 for C, 1 for F77 index notation */

static void free_tmpvrbl(grarr *vrbl);
static void copy_vrbl(grarr *dest, grarr *src);
static int find_set_bydata(double *data, target *tgt);

static int getcharstr(void);
static void ungetchstr(void);
static int follow(int expect, int ifyes, int ifno);

static int yylex(void);
static int yyparse(void);
static void yyerror(char *s);

static int findf(symtab_entry *keytable, char *s);

/* Total (intrinsic + user-defined) list of functions and keywords */
symtab_entry *key;


#line 142 "pars.yacc"
#ifndef YYSTYPE
typedef union {
    int     ival;
    double  dval;
    char   *sval;
    double *dptr;
    target *trgt;
    grarr  *vrbl;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
#ifndef YYDEBUG
# define YYDEBUG 1
#endif



#define	YYFINAL		1659
#define	YYFLAG		-32768
#define	YYNTBASE	398

/* YYTRANSLATE(YYLEX) -- Bison token number corresponding to YYLEX. */
#define YYTRANSLATE(x) ((unsigned)(x) <= 635 ? yytranslate[x] : 473)

/* YYTRANSLATE[YYLEX] -- Bison token number corresponding to YYLEX. */
static const short yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,   386,     2,     2,
     391,   392,   384,   382,   393,   383,   394,   385,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   373,   390,
       2,   397,     2,   372,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   395,     2,   396,   389,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
     186,   187,   188,   189,   190,   191,   192,   193,   194,   195,
     196,   197,   198,   199,   200,   201,   202,   203,   204,   205,
     206,   207,   208,   209,   210,   211,   212,   213,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   241,   242,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,   253,   254,   255,
     256,   257,   258,   259,   260,   261,   262,   263,   264,   265,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   280,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   311,   312,   313,   314,   315,
     316,   317,   318,   319,   320,   321,   322,   323,   324,   325,
     326,   327,   328,   329,   330,   331,   332,   333,   334,   335,
     336,   337,   338,   339,   340,   341,   342,   343,   344,   345,
     346,   347,   348,   349,   350,   351,   352,   353,   354,   355,
     356,   357,   358,   359,   360,   361,   362,   363,   364,   365,
     366,   367,   368,   369,   370,   371,   374,   375,   376,   377,
     378,   379,   380,   381,   387,   388
};

#if YYDEBUG
static const short yyprhs[] =
{
       0,     0,     2,     4,     6,     8,    12,    13,    15,    17,
      19,    21,    23,    25,    27,    29,    31,    33,    35,    37,
      39,    41,    43,    45,    48,    53,    60,    64,    68,    72,
      76,    78,    81,    83,    88,    93,   100,   107,   114,   123,
     132,   143,   156,   171,   175,   179,   183,   187,   191,   195,
     199,   203,   208,   217,   232,   234,   236,   238,   240,   242,
     244,   246,   248,   250,   252,   256,   260,   264,   267,   270,
     274,   278,   282,   286,   292,   296,   300,   304,   308,   312,
     316,   320,   324,   327,   329,   331,   333,   335,   337,   339,
     343,   345,   347,   351,   353,   360,   365,   374,   379,   384,
     389,   394,   399,   406,   413,   420,   427,   436,   445,   456,
     469,   484,   488,   492,   496,   500,   504,   508,   512,   516,
     520,   524,   528,   532,   536,   540,   544,   548,   552,   556,
     559,   565,   571,   577,   583,   587,   591,   595,   599,   603,
     607,   611,   615,   619,   623,   627,   631,   635,   639,   643,
     647,   651,   655,   659,   663,   667,   671,   675,   679,   682,
     686,   689,   693,   697,   701,   705,   710,   712,   716,   720,
     723,   728,   734,   737,   740,   744,   748,   755,   764,   767,
     771,   774,   777,   780,   790,   796,   801,   804,   810,   816,
     824,   829,   835,   840,   845,   849,   853,   857,   862,   865,
     870,   875,   880,   884,   894,   897,   900,   903,   906,   911,
     915,   918,   922,   925,   928,   937,   941,   944,   947,   950,
     954,   958,   961,   964,   968,   971,   974,   983,   987,   990,
     993,   996,  1000,  1004,  1007,  1010,  1014,  1017,  1020,  1029,
    1033,  1036,  1039,  1042,  1046,  1051,  1056,  1063,  1066,  1069,
    1073,  1076,  1079,  1084,  1088,  1091,  1095,  1098,  1102,  1107,
    1111,  1114,  1117,  1122,  1126,  1129,  1134,  1138,  1141,  1144,
    1147,  1150,  1155,  1158,  1163,  1167,  1175,  1189,  1198,  1201,
    1210,  1213,  1216,  1220,  1223,  1226,  1229,  1233,  1236,  1240,
    1244,  1248,  1252,  1256,  1260,  1264,  1268,  1271,  1274,  1277,
    1281,  1285,  1289,  1293,  1297,  1302,  1307,  1311,  1315,  1319,
    1323,  1328,  1333,  1336,  1339,  1342,  1346,  1349,  1352,  1355,
    1358,  1362,  1366,  1369,  1373,  1377,  1381,  1386,  1390,  1396,
    1403,  1410,  1415,  1418,  1424,  1427,  1430,  1433,  1436,  1440,
    1442,  1444,  1447,  1450,  1453,  1455,  1458,  1460,  1465,  1467,
    1471,  1475,  1478,  1481,  1484,  1486,  1489,  1492,  1496,  1500,
    1504,  1510,  1516,  1521,  1526,  1531,  1534,  1538,  1543,  1548,
    1551,  1555,  1558,  1561,  1563,  1576,  1595,  1616,  1623,  1632,
    1639,  1646,  1653,  1666,  1677,  1688,  1695,  1700,  1711,  1718,
    1727,  1729,  1732,  1735,  1738,  1740,  1743,  1746,  1750,  1754,
    1759,  1763,  1767,  1772,  1776,  1781,  1784,  1789,  1794,  1801,
    1804,  1807,  1809,  1813,  1815,  1817,  1819,  1822,  1825,  1828,
    1831,  1834,  1837,  1841,  1845,  1848,  1851,  1854,  1857,  1859,
    1861,  1864,  1868,  1872,  1876,  1880,  1884,  1888,  1893,  1898,
    1903,  1908,  1913,  1918,  1923,  1927,  1931,  1935,  1939,  1944,
    1949,  1953,  1957,  1961,  1966,  1970,  1974,  1979,  1985,  1989,
    1993,  1998,  2003,  2008,  2015,  2020,  2025,  2029,  2033,  2037,
    2041,  2046,  2050,  2054,  2059,  2064,  2070,  2077,  2081,  2085,
    2087,  2091,  2094,  2097,  2100,  2103,  2106,  2109,  2112,  2117,
    2119,  2122,  2126,  2130,  2133,  2136,  2139,  2141,  2145,  2149,
    2151,  2154,  2157,  2159,  2162,  2165,  2168,  2171,  2175,  2179,
    2181,  2185,  2188,  2193,  2198,  2200,  2203,  2206,  2209,  2212,
    2215,  2218,  2221,  2224,  2226,  2229,  2232,  2235,  2239,  2243,
    2247,  2251,  2255,  2257,  2259,  2263,  2266,  2269,  2274,  2276,
    2279,  2282,  2285,  2288,  2293,  2296,  2300,  2302,  2304,  2306,
    2308,  2310,  2312,  2314,  2317,  2320,  2324,  2327,  2329,  2332,
    2336,  2341,  2343,  2346,  2349,  2353,  2355,  2357,  2359,  2361,
    2363,  2365,  2367,  2369,  2371,  2373,  2375,  2377,  2379,  2381,
    2383,  2385,  2387,  2389,  2391,  2393,  2395,  2397,  2399,  2401,
    2403,  2405,  2407,  2409,  2411,  2413,  2415,  2417,  2419,  2421,
    2423,  2425,  2427,  2429,  2431,  2433,  2435,  2437,  2439,  2441,
    2443,  2445,  2447,  2449,  2451,  2453,  2455,  2457,  2459,  2461,
    2463,  2465,  2467,  2469,  2471,  2473,  2475,  2477,  2479,  2481,
    2483,  2485,  2487,  2489,  2491,  2493,  2495,  2497,  2499,  2501,
    2503,  2505,  2507,  2509,  2511,  2513,  2515,  2517,  2519,  2521,
    2523,  2525,  2527,  2529,  2531,  2533,  2535,  2537,  2539,  2541,
    2543,  2545,  2547,  2549,  2551,  2553,  2555,  2557,  2559,  2561,
    2563,  2565,  2567,  2569,  2571,  2573,  2575,  2577,  2579,  2581,
    2583,  2585,  2587,  2589,  2591,  2593,  2595,  2597,  2599,  2601,
    2603,  2605,  2607,  2609,  2611,  2613,  2615,  2617,  2619,  2621,
    2623,  2625,  2627,  2629,  2631,  2633,  2635,  2637,  2639,  2641,
    2643,  2645,  2647,  2649,  2651,  2653,  2655,  2657,  2659,  2661,
    2663,  2665,  2667,  2669,  2671,  2673,  2675,  2677,  2679,  2681,
    2684,  2687,  2690,  2693,  2696,  2699,  2708,  2711,  2714,  2716,
    2718,  2720,  2724,  2729,  2732,  2736,  2741,  2759,  2763,  2767,
    2770,  2773,  2776,  2779,  2783,  2787,  2791,  2796,  2801,  2807,
    2810,  2813,  2817,  2821,  2825,  2829,  2833,  2837,  2841,  2845,
    2849,  2853,  2857,  2861,  2865,  2869,  2873,  2877,  2881,  2885,
    2890,  2895,  2900,  2904,  2909,  2914,  2917,  2919,  2921,  2926,
    2930,  2934,  2939,  2944,  2947,  2950,  2953,  2958,  2964,  2969,
    2974,  2977,  2980,  2983,  2986,  2989,  2992,  2995,  2998,  3001,
    3004,  3008,  3010,  3012,  3015,  3018,  3021,  3024,  3027,  3031,
    3035,  3037,  3040,  3042,  3044,  3046,  3049,  3051,  3053,  3055,
    3057
};
static const short yyrhs[] =
{
     399,     0,   401,     0,   408,     0,   400,     0,   399,   390,
     400,     0,     0,   414,     0,   465,     0,   413,     0,   427,
       0,   417,     0,   415,     0,   416,     0,   409,     0,   411,
       0,   412,     0,     1,     0,   370,     0,    19,     0,   367,
       0,   368,     0,   369,     0,   407,   406,     0,   457,   391,
     408,   392,     0,   153,   391,   408,   393,   408,   392,     0,
     407,   394,   166,     0,   426,   394,   166,     0,   426,   394,
     146,     0,   425,   394,   146,     0,    21,     0,   401,    22,
       0,   240,     0,    23,   391,   404,   392,     0,    24,   391,
     401,   392,     0,    26,   391,   404,   393,   401,   392,     0,
      25,   391,   404,   393,   404,   392,     0,    27,   391,   401,
     393,   401,   392,     0,    28,   391,   404,   393,   404,   393,
     401,   392,     0,    29,   391,   401,   393,   401,   393,   401,
     392,     0,    30,   391,   401,   393,   401,   393,   401,   393,
     401,   392,     0,    31,   391,   401,   393,   401,   393,   401,
     393,   401,   393,   401,   392,     0,    32,   391,   401,   393,
     401,   393,   401,   393,   401,   393,   401,   393,   401,   392,
       0,   425,   394,   312,     0,   425,   394,   313,     0,   425,
     394,   315,     0,   425,   394,   316,     0,   425,   394,   323,
       0,   425,   394,   324,     0,   425,   394,   325,     0,   425,
     394,   326,     0,    18,   391,   402,   392,     0,    18,   391,
     404,   393,   405,   393,   405,   392,     0,    18,   391,   404,
     393,   405,   393,   405,   393,   405,   393,   405,   393,   401,
     392,     0,   312,     0,   313,     0,   315,     0,   316,     0,
     323,     0,   324,     0,   325,     0,   326,     0,   314,     0,
     317,     0,   391,   401,   392,     0,   401,   382,   401,     0,
     401,   383,   401,     0,   383,   401,     0,   382,   401,     0,
     401,   384,   401,     0,   401,   385,   401,     0,   401,   386,
     401,     0,   401,   389,   401,     0,   401,   372,   401,   373,
     401,     0,   401,   376,   401,     0,   401,   377,   401,     0,
     401,   378,   401,     0,   401,   379,   401,     0,   401,   380,
     401,     0,   401,   381,   401,     0,   401,   375,   401,     0,
     401,   374,   401,     0,   388,   401,     0,   401,     0,    69,
       0,   401,     0,    69,     0,   401,     0,   404,     0,   395,
     404,   396,     0,    20,     0,   448,     0,   426,   394,   448,
       0,   407,     0,   407,   395,   404,   373,   404,   396,     0,
     185,   391,   405,   392,     0,   185,   391,   401,   393,   401,
     393,   405,   392,     0,   240,   391,   405,   392,     0,   246,
     391,   426,   392,     0,   255,   391,   408,   392,     0,    23,
     391,   408,   392,     0,    24,   391,   408,   392,     0,    27,
     391,   408,   393,   408,   392,     0,    27,   391,   401,   393,
     408,   392,     0,    27,   391,   408,   393,   401,   392,     0,
      26,   391,   404,   393,   408,   392,     0,    28,   391,   404,
     393,   404,   393,   408,   392,     0,    29,   391,   401,   393,
     401,   393,   408,   392,     0,    30,   391,   401,   393,   401,
     393,   401,   393,   408,   392,     0,    31,   391,   401,   393,
     401,   393,   401,   393,   401,   393,   408,   392,     0,    32,
     391,   401,   393,   401,   393,   401,   393,   401,   393,   401,
     393,   408,   392,     0,   408,   382,   408,     0,   408,   382,
     401,     0,   401,   382,   408,     0,   408,   383,   408,     0,
     408,   383,   401,     0,   401,   383,   408,     0,   408,   384,
     408,     0,   408,   384,   401,     0,   401,   384,   408,     0,
     408,   385,   408,     0,   408,   385,   401,     0,   401,   385,
     408,     0,   408,   386,   408,     0,   408,   386,   401,     0,
     401,   386,   408,     0,   408,   389,   408,     0,   408,   389,
     401,     0,   401,   389,   408,     0,   408,    22,     0,   408,
     372,   401,   373,   401,     0,   408,   372,   401,   373,   408,
       0,   408,   372,   408,   373,   401,     0,   408,   372,   408,
     373,   408,     0,   408,   374,   408,     0,   408,   374,   401,
       0,   401,   374,   408,     0,   408,   375,   408,     0,   408,
     375,   401,     0,   401,   375,   408,     0,   408,   376,   408,
       0,   408,   376,   401,     0,   401,   376,   408,     0,   408,
     377,   408,     0,   408,   377,   401,     0,   401,   377,   408,
       0,   408,   379,   408,     0,   408,   379,   401,     0,   401,
     379,   408,     0,   408,   378,   408,     0,   408,   378,   401,
       0,   401,   378,   408,     0,   408,   380,   408,     0,   408,
     380,   401,     0,   401,   380,   408,     0,   408,   381,   408,
       0,   408,   381,   401,     0,   401,   381,   408,     0,   388,
     408,     0,   391,   408,   392,     0,   383,   408,     0,    19,
     397,   401,     0,   367,   397,   401,     0,   368,   397,   401,
       0,   369,   397,   401,     0,   407,   406,   397,   401,     0,
     407,     0,   410,   397,   408,     0,   410,   397,   401,     0,
      89,   371,     0,    89,   371,   395,   396,     0,    89,   371,
     395,   405,   396,     0,    70,    19,     0,    70,    20,     0,
      35,    69,    69,     0,    35,   122,   439,     0,   305,    69,
     302,   429,   128,    69,     0,   305,    69,   302,   429,   128,
      69,    35,    69,     0,   246,   439,     0,   246,   302,   437,
       0,   246,   461,     0,   246,   459,     0,   246,   462,     0,
     246,   167,   401,   393,   401,   393,   401,   393,   401,     0,
     246,   335,   401,   393,   401,     0,   171,   246,   299,   425,
       0,   306,   405,     0,   216,   248,   405,   393,   405,     0,
     216,   271,   405,   393,   405,     0,    98,    69,   216,   271,
     405,   393,   405,     0,    98,    69,   103,   401,     0,    98,
      69,   121,    40,   439,     0,    98,    69,   121,   439,     0,
      98,    69,   213,    69,     0,   136,    98,    69,     0,   245,
      18,   403,     0,    18,   321,   439,     0,    18,   321,   360,
     404,     0,    51,   461,     0,   216,    51,   114,   439,     0,
     216,   265,   401,   386,     0,   216,   152,   401,   386,     0,
     171,   216,   439,     0,   280,   320,   401,   393,   401,   393,
     401,   393,   401,     0,   296,   405,     0,   292,   426,     0,
     319,   425,     0,   319,   426,     0,   426,   171,   441,    69,
       0,   426,   171,   439,     0,   319,    64,     0,   319,    64,
     405,     0,    64,   439,     0,    64,   425,     0,    64,   401,
     393,   401,   393,   401,   393,   401,     0,    64,   173,   447,
       0,    64,   459,     0,    64,   462,     0,    64,   461,     0,
      64,   114,   461,     0,    64,   114,   460,     0,    64,    87,
       0,   319,   107,     0,   319,   107,   405,     0,   107,   439,
       0,   107,   425,     0,   107,   401,   393,   401,   393,   401,
     393,   401,     0,   107,   173,   447,     0,   107,   459,     0,
     107,   462,     0,   107,   461,     0,   107,   114,   461,     0,
     107,   114,   460,     0,   107,    87,     0,   319,   167,     0,
     319,   167,   405,     0,   167,   439,     0,   167,   425,     0,
     167,   401,   393,   401,   393,   401,   393,   401,     0,   167,
     173,   447,     0,   167,   462,     0,   167,   459,     0,   167,
     461,     0,   167,    43,   405,     0,   167,    43,   166,   401,
       0,   167,    43,   302,   405,     0,   167,    43,   163,   401,
     393,   401,     0,   167,    87,     0,   319,   287,     0,   319,
     287,   405,     0,   287,   439,     0,   287,   425,     0,   287,
     401,   393,   401,     0,   287,   173,   447,     0,   287,   461,
       0,   287,   253,   405,     0,   287,   458,     0,   287,   159,
     405,     0,   287,    67,   271,   401,     0,   287,    87,    69,
       0,   297,   439,     0,   297,   458,     0,   297,    67,   271,
     401,     0,   297,   253,   405,     0,   297,   461,     0,   297,
     401,   393,   401,     0,   297,    87,    69,     0,    88,   459,
       0,    88,   462,     0,    88,   461,     0,    88,   460,     0,
      88,    67,   271,   401,     0,    88,   458,     0,    88,   291,
     271,   401,     0,    88,   269,    69,     0,   183,   121,   405,
     299,    69,   393,    69,     0,   183,    75,   405,   299,   391,
     405,   393,   405,   393,   405,   392,   393,    69,     0,   320,
     401,   393,   401,   393,   401,   393,   401,     0,   366,   401,
       0,   311,   401,   393,   401,   393,   401,   393,   401,     0,
     298,    69,     0,   298,   458,     0,   298,   271,   401,     0,
     298,   461,     0,   289,    69,     0,   289,   458,     0,   289,
     271,   401,     0,   289,   461,     0,   330,   263,   438,     0,
     358,   263,   438,     0,   330,   157,   439,     0,   358,   157,
     439,     0,    47,   212,   202,     0,    47,   212,   330,     0,
      47,   212,   358,     0,    47,   212,   336,     0,    97,    69,
       0,    70,    97,     0,   165,   439,     0,   165,   173,   447,
       0,   165,   310,   405,     0,   165,   139,   405,     0,   165,
     166,   405,     0,   165,   157,   439,     0,   165,    64,   114,
     461,     0,   165,    64,   114,   460,     0,   165,    64,   461,
       0,   165,    64,   460,     0,   165,    64,   459,     0,   165,
      64,   462,     0,   165,   401,   393,   401,     0,   165,    67,
     271,   401,     0,   165,   458,     0,   165,   461,     0,   125,
     439,     0,   125,   302,   405,     0,   125,   459,     0,   125,
     462,     0,   125,   461,     0,   125,   460,     0,   125,    51,
     461,     0,   125,    51,   460,     0,   425,   439,     0,   425,
     140,   439,     0,   425,   302,   434,     0,   425,   281,   439,
       0,   425,    52,   139,   401,     0,   425,   117,   439,     0,
     425,   117,   123,   444,   444,     0,   425,   117,   234,   401,
     393,   401,     0,   425,   117,   335,   401,   393,   401,     0,
     425,   117,   302,   405,     0,   302,   433,     0,    89,   431,
      69,   432,    69,     0,    70,   431,     0,   276,   441,     0,
     123,   444,     0,   115,   424,     0,   367,    78,   439,     0,
     244,     0,   304,     0,    65,    69,     0,   106,    69,     0,
     106,   401,     0,    73,     0,    73,    69,     0,   110,     0,
     110,   391,   404,   392,     0,   236,     0,   236,   299,    98,
       0,   236,   299,    69,     0,   216,   446,     0,   273,   401,
       0,   138,    69,     0,   138,     0,   130,    69,     0,   239,
      69,     0,   426,   140,   439,     0,   426,   166,   405,     0,
      20,   166,   405,     0,   426,   227,   401,   393,   401,     0,
     426,   104,   405,   393,   405,     0,   275,   426,   450,   449,
       0,    79,   426,   299,   426,     0,    41,   426,   299,   426,
       0,   250,   426,     0,   279,   426,   405,     0,   199,   426,
     299,   426,     0,   290,   426,   375,   426,     0,   160,   426,
       0,   160,   426,   262,     0,   160,   425,     0,   160,   246,
       0,   118,     0,    42,   391,   405,   393,   405,   393,   401,
     393,   401,   393,   401,   392,     0,    42,   391,   405,   393,
     405,   393,   401,   393,   401,   393,   401,   393,   439,   393,
     439,   393,   439,   392,     0,    42,   391,   405,   393,   405,
     393,   401,   393,   401,   393,   401,   393,   439,   393,   439,
     393,   439,   393,   439,   392,     0,   203,   391,   426,   393,
     405,   392,     0,   203,   391,   426,   393,   408,   393,   405,
     392,     0,   247,   391,   426,   393,   405,   392,     0,   440,
     391,   426,   393,   405,   392,     0,   451,   391,   426,   393,
     405,   392,     0,   451,   391,   426,   393,   452,   393,   455,
     393,   453,   393,   454,   392,     0,   155,   391,   426,   393,
     408,   393,   456,   393,   439,   392,     0,   141,   391,   426,
     393,   408,   393,   439,   393,   439,   392,     0,   100,   391,
     426,   393,   405,   392,     0,   154,   391,   426,   392,     0,
     332,   391,   426,   393,   426,   393,   405,   393,   439,   392,
       0,   249,   391,   426,   393,   408,   392,     0,   249,   391,
     426,   393,   246,   393,   439,   392,     0,    47,     0,    47,
     330,     0,    47,   358,     0,    47,   426,     0,    48,     0,
     119,   425,     0,   241,    69,     0,   241,    56,    69,     0,
     241,    61,    69,     0,   241,    61,   441,    69,     0,    61,
     433,    69,     0,   241,   433,    69,     0,   241,   433,   441,
      69,     0,   241,   205,    69,     0,   241,   205,   441,    69,
       0,   322,   426,     0,   322,   426,   123,    69,     0,   322,
     426,   113,    69,     0,   322,   426,   113,    69,   123,    69,
       0,   262,    69,     0,   172,    69,     0,   201,     0,   201,
     128,    69,     0,   238,     0,   231,     0,    80,     0,   280,
     405,     0,    70,   280,     0,    70,    64,     0,    70,   107,
       0,    70,   167,     0,    70,   287,     0,   216,   163,   435,
       0,    46,   244,   439,     0,   119,   439,     0,   119,   267,
       0,   119,   120,     0,   119,    71,     0,   418,     0,   467,
       0,   426,   439,     0,   426,   302,   433,     0,   426,   291,
     405,     0,   426,   291,   461,     0,   426,   291,   460,     0,
     426,   291,   462,     0,   426,   291,   459,     0,   426,   291,
     114,   461,     0,   426,   291,   114,   460,     0,   426,   291,
     271,   401,     0,   426,   291,    67,   405,     0,   426,   291,
      67,   458,     0,   426,   291,   272,   405,     0,   426,   167,
     302,   405,     0,   426,   167,   459,     0,   426,   167,   462,
       0,   426,   167,   461,     0,   426,   167,   460,     0,   426,
     114,   302,   405,     0,   426,   114,   256,   405,     0,   426,
     114,   461,     0,   426,   114,   460,     0,   426,    55,   439,
       0,   426,    55,   302,   405,     0,   426,   105,   439,     0,
     426,    49,   439,     0,   426,    49,   302,   405,     0,   426,
      49,    67,   271,   401,     0,   426,    49,   458,     0,   426,
      49,   461,     0,   426,    49,   253,   405,     0,   426,    49,
     123,   444,     0,   426,    49,   234,   405,     0,   426,    49,
     207,   401,   393,   401,     0,   426,    49,   235,    69,     0,
     426,    49,    41,    69,     0,   426,   109,   439,     0,   426,
     109,   463,     0,   426,   109,   461,     0,   426,   109,   460,
       0,   426,   109,   271,   401,     0,   426,   109,   462,     0,
     426,   109,   459,     0,   426,   109,   252,   462,     0,   426,
     109,   252,   459,     0,   426,   109,   252,    72,   439,     0,
     426,   109,   252,    72,   166,   401,     0,   426,    76,    69,
       0,   426,   165,    69,     0,   439,     0,   302,   365,   439,
       0,   294,   420,     0,   294,   468,     0,   293,   421,     0,
     293,   469,     0,   161,   422,     0,   161,   466,     0,    52,
     423,     0,   207,   401,   393,   401,     0,   439,     0,   182,
     401,     0,   187,   295,   405,     0,   226,   254,   439,     0,
     208,   401,     0,   209,   401,     0,    88,   405,     0,   443,
       0,   182,   271,   401,     0,   187,   271,   401,     0,   461,
       0,   182,   461,     0,   187,   461,     0,   462,     0,   182,
     462,     0,   187,   462,     0,   182,   459,     0,   187,   459,
       0,   182,   133,   439,     0,   187,   133,   439,     0,   463,
       0,   277,   302,   430,     0,   277,   405,     0,   182,   405,
     393,   401,     0,   187,   405,   393,   401,     0,   439,     0,
     234,   405,     0,   123,   444,     0,   123,   401,     0,    41,
      69,     0,   235,    69,     0,    39,   405,     0,   272,   405,
       0,   284,   405,     0,   463,     0,   124,    69,     0,   285,
     401,     0,   286,   401,     0,   285,   302,   277,     0,   285,
     302,    46,     0,   286,   302,   277,     0,   286,   302,    46,
       0,    67,   271,   401,     0,   458,     0,   461,     0,   405,
     393,    69,     0,   207,    46,     0,   207,   277,     0,   207,
     401,   393,   401,     0,    69,     0,   163,   222,     0,   163,
     217,     0,   226,    46,     0,   226,   277,     0,   226,   401,
     393,   401,     0,   159,   442,     0,    67,   271,   401,     0,
     458,     0,   461,     0,   463,     0,   439,     0,   461,     0,
     459,     0,   462,     0,   298,    69,     0,   124,    69,     0,
     319,   405,   218,     0,   234,   401,     0,   132,     0,   131,
     406,     0,   425,   394,   268,     0,   425,   394,   267,   406,
       0,   268,     0,   267,   406,     0,   428,   419,     0,   425,
     428,   419,     0,   331,     0,   359,     0,    37,     0,    38,
       0,     5,     0,     6,     0,     7,     0,     8,     0,    10,
       0,     9,     0,    11,     0,    12,     0,    13,     0,    14,
       0,    15,     0,    16,     0,   202,     0,   295,     0,    62,
       0,   147,     0,   210,     0,   180,     0,   220,     0,   335,
       0,    52,     0,    53,     0,    54,     0,   351,     0,   340,
       0,   344,     0,   341,     0,   345,     0,   343,     0,   342,
       0,   346,     0,   347,     0,   348,     0,   338,     0,   339,
       0,   350,     0,   337,     0,   349,     0,   335,     0,    68,
       0,   228,     0,   274,     0,   116,     0,   224,     0,   126,
       0,   116,     0,   162,     0,   232,     0,    33,     0,    58,
       0,   164,     0,   251,     0,   229,     0,   230,     0,   143,
       0,   307,     0,   145,     0,   309,     0,   204,     0,   175,
       0,   243,     0,   176,     0,   211,     0,   206,     0,   257,
       0,   261,     0,   259,     0,   258,     0,   260,     0,   101,
       0,   225,     0,   251,     0,   164,     0,    66,     0,   150,
       0,   215,     0,    62,     0,    86,     0,   111,     0,   129,
       0,   264,     0,   108,     0,   233,     0,    85,     0,   190,
       0,   363,     0,   194,     0,   188,     0,   195,     0,    81,
       0,   197,     0,   198,     0,   196,     0,    83,     0,    82,
       0,    84,     0,   142,     0,   189,     0,   191,     0,   364,
       0,    91,     0,    93,     0,    95,     0,   193,     0,    90,
       0,    92,     0,    94,     0,   192,     0,   204,     0,    34,
       0,   200,     0,   303,     0,   102,     0,   251,     0,   164,
       0,   150,     0,   215,     0,   320,     0,   311,     0,   327,
       0,   352,     0,   328,     0,   353,     0,   354,     0,   355,
       0,   356,     0,   357,     0,    44,     0,    96,     0,   327,
       0,   352,     0,    99,     0,   112,     0,   156,     0,   158,
       0,   242,     0,    77,     0,    17,     0,   127,     0,   221,
       0,   181,     0,   223,     0,    74,     0,   202,     0,   301,
       0,   135,     0,   318,     0,   134,     0,    60,     0,   219,
       0,   168,     0,   278,     0,    45,     0,   186,     0,   184,
       0,    50,     0,   266,     0,   288,     0,   149,     0,   148,
       0,   121,   405,     0,   121,    69,     0,   169,   405,     0,
     220,   405,     0,    75,   405,     0,    75,    69,     0,    75,
     391,   405,   393,   405,   393,   405,   392,     0,   170,   401,
       0,   226,   464,     0,   204,     0,   214,     0,    62,     0,
     216,   163,   436,     0,   216,   271,   370,   370,     0,   216,
     405,     0,   216,   152,   405,     0,    88,   121,   276,   401,
       0,   280,   320,   401,   393,   401,   393,   401,   393,   401,
     294,   401,   393,   401,   393,   401,   393,   401,     0,    64,
     114,   470,     0,   107,   114,   470,     0,   287,   462,     0,
     297,   462,     0,   298,   462,     0,   289,   462,     0,   165,
      64,   439,     0,   165,   329,   401,     0,   165,   354,   401,
       0,   165,   287,   405,    69,     0,   165,    64,   114,   439,
       0,   165,    64,   114,   319,   470,     0,   165,   459,     0,
     165,   462,     0,   425,   161,   439,     0,   425,   302,   177,
       0,   425,   302,   179,     0,   425,   302,   178,     0,   425,
     302,    52,     0,   425,   302,   137,     0,   425,   302,   282,
       0,   425,   302,   283,     0,   320,   334,   401,     0,   320,
     333,   401,     0,   320,   362,   401,     0,   320,   361,   401,
       0,   311,   334,   401,     0,   311,   333,   401,     0,   311,
     362,   401,     0,   311,   361,   401,     0,   165,   163,   401,
       0,   125,   114,   439,     0,   425,    47,   302,    46,     0,
     425,    47,   302,   277,     0,   167,    43,   271,   401,     0,
     136,    98,   401,     0,   237,   170,    57,   401,     0,   237,
     170,   151,   401,     0,   237,   462,     0,   462,     0,   471,
       0,   426,   291,   114,   405,     0,   426,   272,   405,     0,
     426,   114,   405,     0,   426,   109,   302,   472,     0,   426,
     291,    66,   439,     0,   426,   459,     0,   426,   462,     0,
     426,   461,     0,   426,   114,   319,   470,     0,   426,   351,
     401,   393,   401,     0,   426,   109,   166,   401,     0,   426,
     109,   252,   439,     0,   182,   439,     0,   187,   439,     0,
      36,   439,     0,   186,   370,     0,   184,   370,     0,   174,
     439,     0,   302,    46,     0,   302,   277,     0,   187,   401,
       0,   271,   401,     0,   405,   393,   401,     0,   471,     0,
     462,     0,   302,    46,     0,   302,   277,     0,   163,   277,
       0,   163,   144,     0,   163,   308,     0,   226,   211,   295,
       0,   226,    59,   295,     0,   471,     0,   270,   445,     0,
     202,     0,    75,     0,   220,     0,   213,   472,     0,   300,
       0,    63,     0,   164,     0,   251,     0,    62,     0
};

#endif

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined. */
static const short yyrline[] =
{
       0,   618,   620,   624,   630,   632,   635,   637,   638,   639,
     640,   641,   642,   643,   644,   645,   646,   647,   654,   657,
     660,   663,   666,   669,   676,   710,   718,   721,   724,   727,
     730,   734,   738,   742,   746,   750,   754,   758,   762,   766,
     770,   774,   778,   782,   785,   788,   791,   794,   797,   800,
     803,   806,   809,   812,   816,   823,   830,   837,   844,   851,
     858,   865,   872,   877,   882,   885,   888,   891,   894,   897,
     900,   909,   917,   928,   931,   934,   937,   940,   943,   946,
     949,   952,   955,   960,   963,   978,   981,   996,  1006,  1015,
    1025,  1030,  1043,  1058,  1063,  1085,  1103,  1121,  1137,  1166,
    1176,  1186,  1196,  1211,  1222,  1233,  1244,  1255,  1266,  1277,
    1288,  1299,  1314,  1325,  1336,  1351,  1362,  1373,  1388,  1399,
    1410,  1429,  1444,  1459,  1479,  1494,  1510,  1533,  1552,  1571,
    1581,  1590,  1603,  1616,  1629,  1644,  1655,  1666,  1681,  1692,
    1703,  1718,  1729,  1740,  1755,  1766,  1777,  1792,  1803,  1814,
    1829,  1840,  1851,  1866,  1877,  1888,  1903,  1914,  1925,  1935,
    1945,  1957,  1962,  1966,  1970,  1974,  1984,  2011,  2023,  2032,
    2050,  2058,  2069,  2074,  2080,  2098,  2101,  2108,  2118,  2122,
    2125,  2128,  2131,  2134,  2141,  2149,  2155,  2166,  2169,  2172,
    2187,  2201,  2215,  2229,  2244,  2248,  2251,  2254,  2257,  2260,
    2263,  2266,  2269,  2273,  2278,  2282,  2286,  2289,  2294,  2298,
    2303,  2306,  2313,  2320,  2327,  2337,  2340,  2343,  2346,  2349,
    2352,  2355,  2386,  2389,  2396,  2403,  2410,  2420,  2423,  2426,
    2429,  2432,  2435,  2438,  2469,  2472,  2479,  2486,  2493,  2503,
    2506,  2509,  2512,  2515,  2518,  2521,  2524,  2528,  2545,  2548,
    2555,  2562,  2569,  2577,  2580,  2583,  2586,  2589,  2592,  2595,
    2611,  2614,  2617,  2620,  2623,  2626,  2630,  2636,  2639,  2642,
    2645,  2648,  2651,  2654,  2657,  2661,  2669,  2682,  2692,  2695,
    2705,  2713,  2720,  2727,  2734,  2742,  2749,  2756,  2764,  2771,
    2778,  2785,  2792,  2795,  2798,  2801,  2805,  2814,  2818,  2825,
    2832,  2839,  2846,  2853,  2860,  2867,  2874,  2881,  2888,  2895,
    2902,  2910,  2917,  2924,  2932,  2939,  2946,  2953,  2960,  2967,
    2974,  2982,  2991,  2994,  2997,  3000,  3004,  3008,  3011,  3015,
    3019,  3023,  3027,  3032,  3039,  3043,  3046,  3049,  3050,  3055,
    3059,  3066,  3070,  3074,  3079,  3082,  3085,  3088,  3091,  3098,
    3101,  3106,  3128,  3133,  3141,  3148,  3153,  3165,  3168,  3171,
    3174,  3178,  3183,  3188,  3191,  3201,  3204,  3207,  3210,  3213,
    3216,  3219,  3222,  3225,  3228,  3231,  3237,  3243,  3250,  3262,
    3265,  3268,  3271,  3291,  3295,  3299,  3302,  3305,  3308,  3325,
    3340,  3345,  3350,  3355,  3358,  3361,  3369,  3374,  3378,  3382,
    3386,  3399,  3405,  3412,  3416,  3420,  3427,  3435,  3443,  3452,
    3460,  3464,  3467,  3471,  3474,  3477,  3480,  3484,  3487,  3490,
    3493,  3496,  3502,  3508,  3511,  3514,  3517,  3520,  3526,  3528,
    3531,  3535,  3539,  3542,  3545,  3548,  3551,  3554,  3557,  3560,
    3563,  3566,  3569,  3573,  3577,  3581,  3585,  3589,  3594,  3598,
    3602,  3620,  3640,  3644,  3649,  3654,  3658,  3662,  3666,  3670,
    3674,  3678,  3682,  3686,  3690,  3695,  3701,  3704,  3707,  3710,
    3713,  3716,  3719,  3722,  3725,  3728,  3731,  3735,  3740,  3747,
    3755,  3762,  3763,  3764,  3765,  3766,  3767,  3768,  3769,  3779,
    3787,  3794,  3801,  3809,  3816,  3823,  3830,  3837,  3844,  3851,
    3858,  3865,  3872,  3879,  3886,  3893,  3900,  3907,  3914,  3921,
    3928,  3935,  3942,  3950,  3960,  3968,  3975,  3982,  3989,  3997,
    4005,  4012,  4019,  4026,  4033,  4042,  4049,  4056,  4063,  4070,
    4077,  4084,  4091,  4098,  4105,  4120,  4127,  4134,  4144,  4153,
    4160,  4167,  4174,  4181,  4189,  4196,  4203,  4210,  4217,  4226,
    4234,  4241,  4248,  4257,  4262,  4266,  4269,  4274,  4279,  4285,
    4299,  4312,  4325,  4340,  4342,  4345,  4347,  4348,  4349,  4352,
    4354,  4355,  4356,  4357,  4358,  4359,  4360,  4361,  4362,  4363,
    4364,  4367,  4369,  4370,  4373,  4375,  4378,  4380,  4383,  4385,
    4386,  4387,  4388,  4389,  4390,  4391,  4392,  4393,  4394,  4395,
    4396,  4397,  4398,  4399,  4400,  4401,  4402,  4405,  4407,  4408,
    4409,  4410,  4411,  4414,  4416,  4419,  4421,  4424,  4426,  4427,
    4428,  4429,  4430,  4431,  4432,  4433,  4434,  4437,  4438,  4439,
    4440,  4443,  4444,  4447,  4448,  4449,  4450,  4451,  4454,  4456,
    4466,  4467,  4468,  4471,  4472,  4473,  4476,  4477,  4478,  4479,
    4480,  4481,  4482,  4483,  4484,  4485,  4486,  4487,  4488,  4489,
    4490,  4491,  4492,  4493,  4494,  4495,  4496,  4497,  4498,  4499,
    4500,  4501,  4502,  4503,  4504,  4505,  4506,  4509,  4510,  4511,
    4514,  4515,  4516,  4517,  4518,  4519,  4522,  4523,  4526,  4527,
    4528,  4529,  4530,  4531,  4532,  4533,  4536,  4537,  4540,  4541,
    4544,  4545,  4546,  4547,  4550,  4552,  4555,  4557,  4558,  4561,
    4563,  4564,  4567,  4569,  4570,  4571,  4572,  4573,  4574,  4577,
    4579,  4580,  4583,  4584,  4585,  4586,  4587,  4588,  4589,  4592,
    4597,  4604,  4617,  4630,  4641,  4651,  4669,  4685,  4691,  4692,
    4693,  4697,  4710,  4713,  4716,  4720,  4723,  4728,  4730,  4732,
    4734,  4736,  4737,  4739,  4748,  4755,  4762,  4770,  4771,  4772,
    4773,  4775,  4777,  4781,  4785,  4791,  4797,  4802,  4807,  4814,
    4821,  4828,  4835,  4843,  4850,  4857,  4864,  4872,  4875,  4883,
    4885,  4888,  4892,  4893,  4894,  4895,  4899,  4901,  4910,  4925,
    4929,  4952,  4960,  4961,  4964,  4967,  4970,  4971,  4972,  4975,
    4979,  4988,  4989,  4990,  4991,  4992,  4993,  5000,  5009,  5021,
    5028,  5036,  5045,  5047,  5056,  5063,  5065,  5072,  5079,  5080,
    5081,  5088,  5110,  5111,  5112,  5115,  5121,  5122,  5123,  5124,
    5125
};
#endif


#if (YYDEBUG) || defined YYERROR_VERBOSE

/* YYTNAME[TOKEN_NUM] -- String name of the token TOKEN_NUM. */
static const char *const yytname[] =
{
  "$", "error", "$undefined.", "KEY_VAR", "KEY_VEC", "KEY_CONST", 
  "KEY_UNIT", "KEY_FUNC_I", "KEY_FUNC_D", "KEY_FUNC_NN", "KEY_FUNC_ND", 
  "KEY_FUNC_DD", "KEY_FUNC_NND", "KEY_FUNC_PPD", "KEY_FUNC_PPPD", 
  "KEY_FUNC_PPPPD", "KEY_FUNC_PPPPPD", "INDEX", "DATE", "VAR_D", "VEC_D", 
  "CONSTANT", "UCONSTANT", "FUNC_I", "FUNC_D", "FUNC_NN", "FUNC_ND", 
  "FUNC_DD", "FUNC_NND", "FUNC_PPD", "FUNC_PPPD", "FUNC_PPPPD", 
  "FUNC_PPPPPD", "ABOVE", "ABSOLUTE", "ALIAS", "ALT", "ALTXAXIS", 
  "ALTYAXIS", "ANGLE", "ANTIALIASING", "APPEND", "ARRANGE", "ARROW", 
  "ASCENDING", "ASPLINE", "AUTO", "AUTOSCALE", "AUTOTICKS", "AVALUE", 
  "AVG", "BACKGROUND", "BAR", "BARDY", "BARDYDY", "BASELINE", "BATCH", 
  "BEGIN", "BELOW", "BETWEEN", "BLACKMAN", "BLOCK", "BOTH", "BOTTOM", 
  "BOX", "CD", "CENTER", "CHAR", "CHART", "CHRSTR", "CLEAR", "CLICK", 
  "CLIP", "CLOSE", "COEFFICIENTS", "COLOR", "COMMENT", "COMPLEX", 
  "CONSTRAINTS", "COPY", "CYCLE", "DAYMONTH", "DAYOFWEEKL", "DAYOFWEEKS", 
  "DAYOFYEAR", "DDMMYY", "DECIMAL", "DEF", "DEFAULT", "DEFINE", 
  "DEGREESLAT", "DEGREESLON", "DEGREESMMLAT", "DEGREESMMLON", 
  "DEGREESMMSSLAT", "DEGREESMMSSLON", "DESCENDING", "DESCRIPTION", 
  "DEVICE", "DFT", "DIFFERENCE", "DISK", "DOWN", "DPI", "DROP", 
  "DROPLINE", "ECHO", "ELLIPSE", "ENGINEERING", "ERRORBAR", "EXIT", 
  "EXPONENTIAL", "FFT", "FILEP", "FILL", "FIT", "FIXED", "FIXEDPOINT", 
  "FLUSH", "FOCUS", "FOLLOWS", "FONTP", "FORCE", "FORMAT", "FORMULA", 
  "FRAMEP", "FREE", "FREQUENCY", "FROM", "GENERAL", "GETP", "GRAPH", 
  "GRAPHNO", "GRID", "HAMMING", "HANNING", "HARDCOPY", "HBAR", "HELP", 
  "HGAP", "HIDDEN", "HISTOGRAM", "HMS", "HORIZI", "HORIZONTAL", "HORIZO", 
  "ID", "IFILTER", "IMAX", "IMIN", "IN", "INCREMENT", "INOUT", "INT", 
  "INTEGRATE", "INTERPOLATE", "INVDFT", "INVERT", "INVFFT", "JUST", 
  "KILL", "LABEL", "LANDSCAPE", "LAYOUT", "LEFT", "LEGEND", "LENGTH", 
  "LINE", "LINEAR", "LINESTYLE", "LINEWIDTH", "LINK", "LOAD", "LOCTYPE", 
  "LOG", "LOGARITHMIC", "LOGIT", "LOGX", "LOGXY", "LOGY", "MAGIC", 
  "MAGNITUDE", "MAJOR", "MAP", "MAXP", "MESH", "MINP", "MINOR", "MMDD", 
  "MMDDHMS", "MMDDYY", "MMDDYYHMS", "MMSSLAT", "MMSSLON", "MMYY", 
  "MONTHDAY", "MONTHL", "MONTHS", "MONTHSY", "MOVE", "NEGATE", "NEW", 
  "NONE", "NONLFIT", "NORMAL", "NXY", "OFF", "OFFSET", "OFFSETX", 
  "OFFSETY", "OFILTER", "ON", "ONREAD", "OP", "OPPOSITE", "OUT", "PAGE", 
  "PARA", "PARAMETERS", "PARZEN", "PATTERN", "PERIOD", "PERP", "PHASE", 
  "PIE", "PIPE", "PLACE", "POINT", "POLAR", "POLYI", "POLYO", "POP", 
  "PORTRAIT", "POWER", "PREC", "PREPEND", "PRINT", "PS", "PUSH", "PUTP", 
  "RAND", "READ", "REAL", "RECIPROCAL", "REDRAW", "REFERENCE", "REGNUM", 
  "REGRESS", "RESIZE", "RESTRICT", "REVERSE", "RIGHT", "RISER", "ROT", 
  "ROUNDED", "RSUM", "RULE", "RUNAVG", "RUNMAX", "RUNMED", "RUNMIN", 
  "RUNSTD", "SAVEALL", "SCALE", "SCIENTIFIC", "SCROLL", "SD", "SET", 
  "SETNUM", "SFORMAT", "SIGN", "SIZE", "SKIP", "SLEEP", "SMITH", "SORT", 
  "SOURCE", "SPEC", "SPLINE", "SPLIT", "STACK", "STACKED", "STACKEDBAR", 
  "STACKEDHBAR", "STAGGER", "START", "STOP", "STRING", "SUM", "SUBTITLE", 
  "SWAP", "SYMBOL", "TARGET", "TICKLABEL", "TICKP", "TICKSP", "TIMER", 
  "TIMESTAMP", "TITLE", "TO", "TOP", "TRIANGULAR", "TYPE", "UP", 
  "UPDATEALL", "USE", "VERSION", "VERTI", "VERTICAL", "VERTO", "VGAP", 
  "VIEW", "VX1", "VX2", "VXMAX", "VY1", "VY2", "VYMAX", "WELCH", "WITH", 
  "WORLD", "WRAP", "WRITE", "WX1", "WX2", "WY1", "WY2", "X_TOK", "X0", 
  "X1", "XAXES", "XAXIS", "XCOR", "XMAX", "XMIN", "XY", "XYAXES", 
  "XYBOXPLOT", "XYCOLOR", "XYCOLPAT", "XYDX", "XYDXDX", "XYDXDXDYDY", 
  "XYDXDY", "XYDY", "XYDYDY", "XYHILO", "XYR", "XYSIZE", "XYSTRING", 
  "XYVMAP", "XYZ", "Y_TOK", "Y0", "Y1", "Y2", "Y3", "Y4", "YAXES", 
  "YAXIS", "YEAR", "YMAX", "YMIN", "YYMMDD", "YYMMDDHMS", "ZERO", "ZNORM", 
  "FITPARM", "FITPMAX", "FITPMIN", "NUMBER", "NEW_TOKEN", "'?'", "':'", 
  "OR", "AND", "GT", "LT", "LE", "GE", "EQ", "NE", "'+'", "'-'", "'*'", 
  "'/'", "'%'", "UMINUS", "NOT", "'^'", "';'", "'('", "')'", "','", "'.'", 
  "'['", "']'", "'='", "full_list", "multi_list", "list", "expr", "jdate", 
  "jrawdate", "iexpr", "nexpr", "indx", "array", "vexpr", "asgn", 
  "lside_array", "vasgn", "defines", "regionset", "parmset", "actions", 
  "options", "set_setprop", "setprop", "axisfeature", "tickattr", 
  "ticklabelattr", "axislabeldesc", "axisbardesc", "nonlfitopts", 
  "selectgraph", "selectset", "setaxis", "axis", "proctype", 
  "tickspectype", "filtertype", "filtermethod", "xytype", "graphtype", 
  "pagelayout", "pageorient", "regiontype", "scaletype", "onoff", 
  "runtype", "sourcetype", "justchoice", "inoutchoice", "formatchoice", 
  "signchoice", "direction", "worldview", "datacolumn", "sortdir", 
  "sorton", "ffttype", "fourierdata", "fourierloadx", "fourierloady", 
  "windowtype", "interpmethod", "stattype", "font_select", "lines_select", 
  "pattern_select", "color_select", "linew_select", "opchoice_sel", 
  "opchoice", "parmset_obs", "axislabeldesc_obs", "setprop_obs", 
  "tickattr_obs", "ticklabelattr_obs", "colpat_obs", "opchoice_sel_obs", 
  "opchoice_obs", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives. */
static const short yyr1[] =
{
       0,   398,   398,   398,   399,   399,   400,   400,   400,   400,
     400,   400,   400,   400,   400,   400,   400,   400,   401,   401,
     401,   401,   401,   401,   401,   401,   401,   401,   401,   401,
     401,   401,   401,   401,   401,   401,   401,   401,   401,   401,
     401,   401,   401,   401,   401,   401,   401,   401,   401,   401,
     401,   401,   401,   401,   401,   401,   401,   401,   401,   401,
     401,   401,   401,   401,   401,   401,   401,   401,   401,   401,
     401,   401,   401,   401,   401,   401,   401,   401,   401,   401,
     401,   401,   401,   402,   402,   403,   403,   404,   405,   406,
     407,   407,   407,   408,   408,   408,   408,   408,   408,   408,
     408,   408,   408,   408,   408,   408,   408,   408,   408,   408,
     408,   408,   408,   408,   408,   408,   408,   408,   408,   408,
     408,   408,   408,   408,   408,   408,   408,   408,   408,   408,
     408,   408,   408,   408,   408,   408,   408,   408,   408,   408,
     408,   408,   408,   408,   408,   408,   408,   408,   408,   408,
     408,   408,   408,   408,   408,   408,   408,   408,   408,   408,
     408,   409,   409,   409,   409,   409,   410,   411,   411,   412,
     412,   412,   412,   412,   412,   412,   412,   412,   413,   413,
     413,   413,   413,   413,   413,   413,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   414,
     414,   414,   414,   414,   414,   414,   414,   414,   414,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   415,   415,   415,   415,   415,   415,   415,   415,
     415,   415,   416,   416,   416,   416,   416,   416,   417,   417,
     418,   418,   418,   418,   418,   418,   418,   418,   418,   418,
     418,   418,   418,   418,   418,   418,   418,   418,   418,   418,
     418,   418,   418,   418,   418,   418,   418,   418,   418,   418,
     418,   418,   418,   418,   418,   418,   418,   418,   418,   418,
     418,   418,   418,   418,   418,   418,   418,   418,   418,   419,
     419,   419,   419,   419,   419,   419,   419,   419,   419,   420,
     420,   420,   420,   420,   420,   420,   420,   420,   420,   420,
     420,   420,   420,   420,   420,   420,   420,   420,   420,   420,
     420,   420,   420,   420,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   421,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   421,   421,   421,   421,   421,   422,   422,
     422,   422,   422,   422,   422,   422,   422,   422,   422,   423,
     423,   423,   423,   424,   424,   424,   424,   425,   425,   426,
     426,   426,   426,   427,   427,   428,   428,   428,   428,   429,
     429,   429,   429,   429,   429,   429,   429,   429,   429,   429,
     429,   430,   430,   430,   431,   431,   432,   432,   433,   433,
     433,   433,   433,   433,   433,   433,   433,   433,   433,   433,
     433,   433,   433,   433,   433,   433,   433,   434,   434,   434,
     434,   434,   434,   435,   435,   436,   436,   437,   437,   437,
     437,   437,   437,   437,   437,   437,   437,   438,   438,   438,
     438,   439,   439,   440,   440,   440,   440,   440,   441,   441,
     442,   442,   442,   443,   443,   443,   444,   444,   444,   444,
     444,   444,   444,   444,   444,   444,   444,   444,   444,   444,
     444,   444,   444,   444,   444,   444,   444,   444,   444,   444,
     444,   444,   444,   444,   444,   444,   444,   445,   445,   445,
     446,   446,   446,   446,   446,   446,   447,   447,   448,   448,
     448,   448,   448,   448,   448,   448,   449,   449,   450,   450,
     451,   451,   451,   451,   452,   452,   453,   453,   453,   454,
     454,   454,   455,   455,   455,   455,   455,   455,   455,   456,
     456,   456,   457,   457,   457,   457,   457,   457,   457,   458,
     458,   459,   460,   461,   461,   461,   462,   463,   464,   464,
     464,   465,   465,   465,   465,   465,   465,   465,   465,   465,
     465,   465,   465,   465,   465,   465,   465,   465,   465,   465,
     465,   465,   465,   465,   465,   465,   465,   465,   465,   465,
     465,   465,   465,   465,   465,   465,   465,   465,   465,   465,
     465,   465,   465,   465,   465,   465,   466,   466,   467,   467,
     467,   467,   467,   467,   467,   467,   467,   467,   467,   467,
     468,   468,   468,   468,   468,   468,   468,   468,   468,   468,
     468,   468,   469,   469,   469,   469,   469,   469,   469,   469,
     469,   469,   470,   470,   470,   471,   472,   472,   472,   472,
     472
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN. */
static const short yyr2[] =
{
       0,     1,     1,     1,     1,     3,     0,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     4,     6,     3,     3,     3,     3,
       1,     2,     1,     4,     4,     6,     6,     6,     8,     8,
      10,    12,    14,     3,     3,     3,     3,     3,     3,     3,
       3,     4,     8,    14,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     3,     3,     2,     2,     3,
       3,     3,     3,     5,     3,     3,     3,     3,     3,     3,
       3,     3,     2,     1,     1,     1,     1,     1,     1,     3,
       1,     1,     3,     1,     6,     4,     8,     4,     4,     4,
       4,     4,     6,     6,     6,     6,     8,     8,    10,    12,
      14,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     2,
       5,     5,     5,     5,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     2,     3,
       2,     3,     3,     3,     3,     4,     1,     3,     3,     2,
       4,     5,     2,     2,     3,     3,     6,     8,     2,     3,
       2,     2,     2,     9,     5,     4,     2,     5,     5,     7,
       4,     5,     4,     4,     3,     3,     3,     4,     2,     4,
       4,     4,     3,     9,     2,     2,     2,     2,     4,     3,
       2,     3,     2,     2,     8,     3,     2,     2,     2,     3,
       3,     2,     2,     3,     2,     2,     8,     3,     2,     2,
       2,     3,     3,     2,     2,     3,     2,     2,     8,     3,
       2,     2,     2,     3,     4,     4,     6,     2,     2,     3,
       2,     2,     4,     3,     2,     3,     2,     3,     4,     3,
       2,     2,     4,     3,     2,     4,     3,     2,     2,     2,
       2,     4,     2,     4,     3,     7,    13,     8,     2,     8,
       2,     2,     3,     2,     2,     2,     3,     2,     3,     3,
       3,     3,     3,     3,     3,     3,     2,     2,     2,     3,
       3,     3,     3,     3,     4,     4,     3,     3,     3,     3,
       4,     4,     2,     2,     2,     3,     2,     2,     2,     2,
       3,     3,     2,     3,     3,     3,     4,     3,     5,     6,
       6,     4,     2,     5,     2,     2,     2,     2,     3,     1,
       1,     2,     2,     2,     1,     2,     1,     4,     1,     3,
       3,     2,     2,     2,     1,     2,     2,     3,     3,     3,
       5,     5,     4,     4,     4,     2,     3,     4,     4,     2,
       3,     2,     2,     1,    12,    18,    20,     6,     8,     6,
       6,     6,    12,    10,    10,     6,     4,    10,     6,     8,
       1,     2,     2,     2,     1,     2,     2,     3,     3,     4,
       3,     3,     4,     3,     4,     2,     4,     4,     6,     2,
       2,     1,     3,     1,     1,     1,     2,     2,     2,     2,
       2,     2,     3,     3,     2,     2,     2,     2,     1,     1,
       2,     3,     3,     3,     3,     3,     3,     4,     4,     4,
       4,     4,     4,     4,     3,     3,     3,     3,     4,     4,
       3,     3,     3,     4,     3,     3,     4,     5,     3,     3,
       4,     4,     4,     6,     4,     4,     3,     3,     3,     3,
       4,     3,     3,     4,     4,     5,     6,     3,     3,     1,
       3,     2,     2,     2,     2,     2,     2,     2,     4,     1,
       2,     3,     3,     2,     2,     2,     1,     3,     3,     1,
       2,     2,     1,     2,     2,     2,     2,     3,     3,     1,
       3,     2,     4,     4,     1,     2,     2,     2,     2,     2,
       2,     2,     2,     1,     2,     2,     2,     3,     3,     3,
       3,     3,     1,     1,     3,     2,     2,     4,     1,     2,
       2,     2,     2,     4,     2,     3,     1,     1,     1,     1,
       1,     1,     1,     2,     2,     3,     2,     1,     2,     3,
       4,     1,     2,     2,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       2,     2,     2,     2,     2,     8,     2,     2,     1,     1,
       1,     3,     4,     2,     3,     4,    17,     3,     3,     2,
       2,     2,     2,     3,     3,     3,     4,     4,     5,     2,
       2,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     4,
       4,     4,     3,     4,     4,     2,     1,     1,     4,     3,
       3,     4,     4,     2,     2,     2,     4,     5,     4,     4,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       3,     1,     1,     2,     2,     2,     2,     2,     3,     3,
       1,     2,     1,     1,     1,     2,     1,     1,     1,     1,
       1
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error. */
static const short yydefact[] =
{
       0,    17,     0,    19,    90,    30,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   567,   568,     0,
       0,     0,   390,   394,   724,     0,     0,     0,     0,     0,
     344,     0,   415,     0,     0,     0,     0,   700,     0,     0,
       0,   346,   701,     0,   373,     0,     0,     0,     0,     0,
     557,     0,   354,     0,   728,   727,     0,     0,     0,   702,
     703,     0,     0,     0,     0,     0,     0,   723,     0,   722,
       0,   411,     0,     0,   414,   348,     0,   413,     0,    32,
       0,   339,     0,     0,     0,     0,     0,     0,   633,   636,
     635,   637,   634,     0,   725,     0,   561,     0,     0,     0,
       0,     0,     0,   726,     0,     0,     0,     0,     0,     0,
       0,   340,     0,     0,     0,    54,    55,    62,    56,    57,
      63,     0,     0,     0,    58,    59,    60,    61,   688,   690,
       0,   565,     0,   689,   691,   692,   693,   694,   695,     0,
     566,     0,    20,    21,    22,    18,     0,     0,     0,     0,
       1,     4,     2,    93,     3,    14,     0,    15,    16,     9,
       7,    12,    13,    11,   428,     0,     0,    10,     0,     0,
      91,     0,     0,     8,   429,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   391,   392,   393,     0,
     198,   589,   590,   591,   588,   605,   602,   603,   593,   595,
     598,   597,   594,   596,   599,   600,   601,   606,   604,   592,
       0,     0,    19,    90,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   221,     0,     0,     0,     0,   632,   631,
      32,    20,    21,    22,     0,     0,     0,     0,     0,   213,
       0,   212,   216,   218,   217,   341,   172,   173,   418,   297,
     419,   584,   420,   585,   417,   421,   334,   345,     0,     0,
       0,     0,     0,     0,   272,   267,   270,   269,   268,   169,
       0,   296,     0,     0,   342,   343,     0,   233,     0,     0,
       0,   225,   224,   228,   230,   229,     0,     0,     0,     0,
       0,   337,   427,   426,   425,   395,   424,   658,   663,   662,
     664,   652,   646,   673,   669,   674,   670,   675,   671,   650,
     647,   648,   665,   656,   666,   653,   667,   676,   672,   655,
     657,   661,   659,   660,   651,   649,   654,   668,   336,     0,
       0,     0,   314,   316,   319,   318,   317,   355,     0,   558,
       0,   353,     0,     0,     0,     0,   372,   371,   369,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     692,     0,   298,   312,   759,   313,   760,     0,   247,     0,
       0,   237,   236,   241,   242,   240,     0,     0,   410,     0,
       0,     0,     0,     0,     0,     0,   681,   684,     0,     0,
     683,   685,     0,   682,     0,     0,   680,    87,    88,   743,
     351,     0,     0,   785,   356,     0,     0,     0,   396,     0,
       0,     0,     0,     0,     0,     0,   178,   181,   180,   182,
       0,     0,   365,     0,   409,   562,   352,     0,   638,   639,
     335,     0,     0,   416,     0,     0,     0,     0,     0,     0,
     251,   250,   256,   254,   749,   284,     0,   285,   287,   752,
       0,   205,   204,     0,     0,     0,     0,   260,   261,   264,
     750,   280,     0,   281,   283,   751,   332,     0,   186,     0,
       0,     0,     0,     0,   210,   222,   234,   248,   206,   207,
       0,     0,     0,     0,     0,   405,     0,     0,     0,     0,
       0,   278,     0,     0,     0,     0,    68,     0,    67,    93,
     160,    82,   158,     0,     0,     0,    31,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    23,   129,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   322,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     430,   793,   795,   794,     0,     0,     0,     0,     0,     0,
     563,   479,     0,     0,     0,     0,   196,    84,    83,     0,
       0,   161,   359,    87,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   174,   175,     0,
       0,     0,   423,   292,   293,   295,   294,   734,     0,   733,
     400,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     823,   822,   824,   220,   219,   747,   731,   736,   687,   686,
     215,    67,    82,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    23,
       0,     0,   730,     0,   729,   732,   274,     0,     0,     0,
       0,     0,     0,     0,     0,   232,   231,   748,   227,     0,
       0,   554,   556,   553,     0,   321,   320,   778,   315,     0,
     194,   782,     0,     0,     0,     0,     0,   370,     0,   753,
     308,   307,   306,   309,     0,   301,   303,   777,   302,   299,
       0,   300,   754,   755,     0,     0,     0,     0,     0,   243,
     239,     0,   202,     0,     0,     0,    87,     0,     0,   412,
       0,     0,    87,   744,   614,   613,   615,   616,   422,   741,
       0,     0,    18,     0,   350,   349,     0,     0,     0,   397,
     398,     0,   403,     0,   401,     0,    86,    85,   195,     0,
     617,   618,   623,   625,   619,   621,   622,   620,   624,   626,
     179,     0,     0,     0,     0,     0,   698,   699,     0,   366,
       0,     0,   259,   257,   253,   255,     0,   286,     0,     0,
     266,   263,     0,   282,     0,   774,   773,   776,   775,     0,
     211,   223,   235,   249,   770,   769,   772,   771,     0,     0,
       0,   290,   628,   630,   627,   629,   288,     0,   291,   289,
     338,   162,   163,   164,    64,   159,     0,     0,     0,     0,
       0,     0,     5,   166,     0,     0,     0,    81,   136,    80,
     139,    74,   142,    75,   145,    76,   151,    77,   148,    78,
     154,    79,   157,    65,   113,    66,   116,    69,   119,    70,
     122,    71,   125,    72,   128,    26,     0,     0,     0,     0,
     135,   134,   138,   137,   141,   140,   144,   143,   150,   149,
     147,   146,   153,   152,   156,   155,   112,   111,   115,   114,
     118,   117,   121,   120,   124,   123,   127,   126,   168,   167,
       0,     0,     0,     0,     0,     0,   327,   323,   761,   325,
     765,   608,   611,   766,   762,   764,   763,   612,   609,   610,
     767,   768,   607,   324,    29,     0,   559,    43,    44,    45,
      46,    47,    48,    49,    50,   564,     0,     0,     0,     0,
       0,     0,     0,     0,   455,   458,   459,     0,   452,   477,
       0,   454,     0,     0,     0,     0,     0,   466,   472,   469,
     468,   471,   467,     0,     0,     0,   790,   451,   450,   357,
     478,   358,     0,   444,   447,   446,   445,   209,     0,     0,
     789,     0,     0,     0,     0,     0,   432,   436,   434,   433,
     435,   431,     0,    28,    27,    92,   487,   549,   551,   550,
     552,     0,   538,     0,     0,     0,     0,   485,   546,   547,
     786,   548,   486,   787,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   483,   514,   532,   533,   812,   523,   484,   820,
       0,   645,     0,   643,     0,     0,   723,   722,     0,     0,
       0,   644,     0,     0,     0,     0,     0,   481,   489,   496,
     499,   502,   509,   482,   811,     0,     0,     0,     0,   197,
      51,     0,    33,   100,    34,   101,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   364,     0,    87,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    81,    80,    74,
      75,    76,    77,    78,    79,    65,    66,    69,    70,    71,
      72,     0,   363,   271,   745,   273,   170,     0,   586,   587,
       0,   190,     0,   192,   193,     0,     0,     0,   347,   555,
      89,     0,     0,   386,     0,     0,   757,   305,   304,   311,
     756,   310,     0,   244,   781,   245,     0,   185,     0,     0,
       0,    95,   367,     0,   199,   201,     0,   200,   742,     0,
     783,   784,    97,   399,   404,   402,     0,     0,    98,     0,
       0,    99,   696,   697,   362,     0,   258,   252,   368,   262,
     265,   569,   570,   571,   572,   574,   573,   575,   576,   577,
     578,   579,   580,     0,     0,     0,   407,   406,     0,     0,
       0,     0,     0,   165,     0,     0,   779,   780,   326,     0,
       0,   331,     0,   560,   465,     0,   461,     0,   462,   464,
     460,   456,   453,     0,   798,   740,   738,   739,   737,     0,
     799,   474,   473,   470,   830,   827,   828,   829,   826,   791,
     449,   448,   823,   824,   796,   443,   208,     0,   792,   440,
     441,   788,   438,   437,   439,   442,     0,     0,   642,   641,
     640,   544,   540,   539,   825,   541,   542,     0,     0,   520,
     518,     0,   517,   516,   524,   816,   815,   817,   535,   536,
       0,     0,     0,   515,   519,   678,   679,   677,   821,   521,
     522,     0,   525,     0,   526,   813,   814,     0,   802,   495,
     805,     0,     0,   490,     0,   800,   505,   500,   503,   804,
     803,     0,     0,     0,   808,     0,   801,   506,   501,   504,
     493,   494,     0,   809,     0,   511,   806,   807,     0,   480,
       0,     0,    24,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   171,   333,   191,     0,
       0,     0,     0,     0,     0,   758,     0,     0,     0,     0,
       0,     0,     0,   187,   188,     0,   184,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    73,     0,   130,   131,
     132,   133,   328,     0,     0,   457,     0,   361,     0,   475,
     360,   797,   545,     0,   488,   531,     0,   819,   818,   528,
     527,   530,   529,   534,   507,   497,     0,   508,   498,   491,
       0,   492,   583,   581,   582,   510,   810,     0,   705,   704,
       0,     0,     0,    36,    35,   105,    37,   103,   104,   102,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   385,     0,     0,    25,
       0,   246,     0,     0,     0,     0,   377,     0,     0,   379,
       0,   388,     0,   176,     0,     0,   408,     0,    94,   329,
     330,   463,   476,   543,   537,   512,   513,   380,   381,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   189,     0,     0,   721,
     719,   720,     0,     0,     0,   275,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   717,   716,   714,   712,   718,
     713,   715,     0,    52,     0,    38,   106,    39,   107,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   214,
     226,     0,     0,   238,     0,    96,   378,     0,   389,     0,
     177,   279,   277,     0,     0,     0,     0,     0,     0,     0,
       0,   735,     0,     0,     0,     0,     0,     0,   183,   203,
       0,   706,   707,   708,     0,     0,    40,   108,     0,     0,
       0,     0,     0,     0,   384,   383,     0,     0,   387,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   711,
     709,   710,     0,     0,    41,   109,     0,   374,     0,     0,
       0,     0,     0,   382,     0,     0,     0,     0,     0,   276,
       0,    53,    42,   110,     0,     0,     0,     0,     0,     0,
       0,     0,   746,   375,     0,     0,   376,     0,     0,     0
};

static const short yydefgoto[] =
{
    1657,   150,   151,   407,   599,   768,   408,   629,   669,   248,
     154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   590,  1067,  1042,  1017,  1006,   301,   286,   250,   167,
     168,  1203,  1435,   266,  1130,   220,   933,   748,   749,   780,
     826,   426,   169,   440,  1271,  1069,   338,  1298,   410,   650,
     170,  1184,   788,   171,  1441,  1594,  1622,  1542,  1522,   172,
     274,   427,   276,   428,   429,   972,  1238,   173,  1022,   174,
    1073,  1048,   645,  1023,  1249
};

static const short yypact[] =
{
    2778,-32768,  -299,  -350,   -70,-32768,  -298,  -278,  -275,  -232,
    -221,  -164,  -111,  -108,   -39,   -37,   -43,-32768,-32768,   231,
     -16,    90,    62,-32768,-32768,   282,   553,  5232,   296,   -12,
     310,   231,-32768,   663,  -128,   326,   332,-32768,    12,  8524,
    5421,    17,-32768,   -96,-32768,   364, 11723,    70,   341,    28,
  -32768,   321,   367,    49,-32768,-32768,    66,    68,    72,-32768,
  -32768,   265,  4287,  5610,  -113,   396,   218,-32768,    78,-32768,
     231,   348,    92,  4558,-32768,   190,   324,-32768,   428,   110,
    4747,-32768,   488,   -50,   164,   165,   231,   178,-32768,-32768,
  -32768,-32768,-32768,   446,-32768,    28,-32768, 10543,   231,   -34,
     231,  8671,  4812,-32768,   -38,   231,   231, 10543,  5799,   144,
     553,-32768,   447, 10543,  6594,-32768,-32768,-32768,-32768,-32768,
  -32768,   809,  6740,   231,-32768,-32768,-32768,-32768,-32768,-32768,
     -91,-32768,   182,-32768,-32768,-32768,-32768,-32768,-32768,   -26,
  -32768, 10543,   -72,   117,   138,-32768, 10543,  7122,  7122,  7122,
     177,-32768,  5910,     5,  6662,-32768,   169,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,  1360, 11672,-32768,   654,   185,
  -32768,   186,   188,-32768,-32768,  -161,  8898, 10543, 10543,  7122,
    7122, 10543, 10543,  7122, 10543, 10543, 10543, 10543, 10543,   513,
    -146,   193,   291, 10543,  -146,   -63,-32768,-32768,-32768,  9045,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
     523,   204,-32768,-32768,   207,   208,   210,   211,   212,   213,
     219,   233,   234,-32768,   -31, 10543, 10543,    57,-32768,-32768,
  -32768,-32768,-32768,-32768, 10543, 10543, 10543,   237,  -252,   235,
     239,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   328,   370,
    7520, 10543,   578,   377,-32768,-32768,-32768,-32768,-32768,   255,
     582,-32768,    -9,   231,-32768,  8110,   235,-32768,   -31,    57,
     365,   235,-32768,-32768,-32768,-32768, 10543,   583, 10543,   584,
   10543,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -51,
    -146, 10543,-32768,-32768,-32768,-32768,-32768,-32768, 10543,-32768,
    9272,-32768,   231,  7122,   231,   231,-32768,   193,   407,   830,
     399,  9419, 10543,  -146, 10543, 10543,    57, 10543, 10543, 10543,
   10543,   445,-32768,-32768,-32768,-32768,-32768,  6972,-32768,    57,
     854,   235,-32768,-32768,-32768,-32768,  -146,   375,-32768, 10543,
   10543, 10543,   376,   607,   231,   564,-32768,-32768, 10543,   175,
  -32768,-32768, 10543,-32768, 10543, 10770,-32768,  8110,-32768,-32768,
  -32768,   172,  7774,-32768,-32768, 10543,   610,    81,-32768,   131,
     191,  9646, 10543,   -20, 10543,   231,-32768,-32768,-32768,-32768,
     231,   231,-32768,  7122,-32768,-32768,  8110,    15,-32768,-32768,
  -32768, 10543, 10543,-32768,   412,   615, 10543,    57, 10543,   908,
     235,-32768,-32768,-32768,-32768,-32768, 10543,-32768,-32768,-32768,
     311,-32768,-32768,   414,   618, 10543,   951,-32768,-32768,-32768,
  -32768,-32768, 10543,-32768,-32768,-32768,-32768,   388,-32768, 10543,
   10543, 10543, 10543,  1323, 10543, 10543, 10543, 10543,   193,-32768,
   10543, 10543, 10543, 10543,  1636,   -24,  -146,   230,   231,  -146,
     230,  8110,  -146, 10543, 10543, 10543,   314,   317,   318,    19,
     320,   318,   320,  3534,  3850,  3152,-32768, 10543,  7122,  7122,
    7122,  7122,  7122,  7122,  7122,  7122,  7122,  7122,  7122,  7122,
    7122,  7122,   544, 10543,   315,-32768,  7122,  7122,  7122,  7122,
    7122,  7122,  7122,  7122,  7122,  7122,  7122,  7122,  7122,  7122,
    7122,  7122,   413,   577,   125,  -146,  -146,  -146,    38,   162,
     654,-32768,    43,   137,   648, 10543,  -146,   701,  2288,  -146,
     651, 10543,    -2,   107, 10543, 10543,  5001,   553, 10543,   864,
  -32768,-32768,-32768,-32768,   301,  1395, 10543,  3721,  4032,   356,
  -32768,-32768,   231,   231,  7122, 10543,-32768,-32768,  1838,   330,
     335,  8110,-32768,  5910,   331,  4625, 10263, 10458,   342,   343,
    1862,  1890,   359,  2306,  2328,  2380,  3151,-32768,-32768,   150,
     231,   360,-32768,-32768,-32768,-32768,-32768,-32768, 10543,-32768,
  -32768, 10543, 10543, 10543, 10543, 10543, 10543, 10543, 10543, 10543,
    9045,-32768, 10543,-32768,-32768,-32768,-32768,  8110,-32768,-32768,
  -32768,   314,   314, 10561, 10543, 10543, 10543, 10543, 10543, 10543,
   10543, 10543, 10543, 10543, 10543, 10543, 10543, 10543, 10543,-32768,
     231, 10543,-32768, 10543,-32768,-32768,-32768, 10543,  1802,  -105,
   10543,    14,   686,   489,   366,-32768,-32768,-32768,-32768, 10543,
     369,-32768,  8110,-32768,   545,-32768,-32768,-32768,-32768,   378,
  -32768,  8110,   373,  5910,  3208,   380,   382,-32768,   -14,-32768,
  -32768,-32768,-32768,-32768, 10543,-32768,-32768,  8110,-32768,-32768,
     704,-32768,  8110,  8110, 10543, 10543, 10543, 10543, 10543,-32768,
  -32768, 10543,-32768,   294,   478,   479,  3247,   389,   231,-32768,
     392,  -146,  8486,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
     394,  8860,   418,   397,-32768,-32768, 10543, 10543,   400,-32768,
  -32768,   720,-32768,   724,-32768,   725,-32768,  8110,-32768,  3294,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,  3334,   403,   405,   408, 10585,-32768,-32768,    44,-32768,
    3425, 10543,-32768,-32768,-32768,-32768, 10543,  8110,   231, 10543,
  -32768,-32768, 10543,  8110,  2047,  8110,  8110,  8110,  8110, 10543,
  -32768,-32768,-32768,-32768,  8110,  8110,  8110,  8110, 10543,   731,
     735,-32768,-32768,-32768,-32768,-32768,-32768,   415,-32768,-32768,
  -32768,  8110,  8110,  8110,-32768,-32768,   484,  -350,   -33,   -72,
     117,   138,-32768,    28,  4048, 11679,  1059,   316,   689,   971,
    1159,  1299,  2118,  1299,  2118,  1299,  2118,  1299,  2118,  1299,
    2118,  1299,  2118,   124,   176,   124,   176,   318,   320,   318,
     320,   318,   320,   318,   320,-32768,  -295, 10543,  5047,  6326,
     316,   689,   971,  1159,  1299,  2118,  1299,  2118,  1299,  2118,
    1299,  2118,  1299,  2118,  1299,  2118,   124,   176,   124,   176,
     318,   320,   318,   320,   318,   320,   318,   320,  5910,  6662,
     -30, 10543, 11723, 10543, 10543, 10543,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,    28,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,   738,   539, 11723, 10543,
   10543,   743, 10543, 10543,-32768,-32768,-32768, 10543,-32768,-32768,
     420,-32768, 10543,   112,   600, 10543,    89,-32768,-32768,-32768,
  -32768,-32768,-32768, 10543, 10543,    36,-32768,-32768,-32768,-32768,
  -32768,-32768, 10543,-32768,-32768,-32768,-32768,-32768,   745,  3588,
  -32768,  -146,  9795,  7919, 10543, 10543,-32768,-32768,-32768,-32768,
  -32768,-32768,  3747,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,   565,-32768,   -55,   -57,    89,  6366,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,  3767, 10543,   747,   566,  3467,   766,
     -74,  8150,   167, 10543,   771,   123, 10543, 10543, 10022, 10169,
     -13,   449,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    -146,-32768, 10543,-32768,  -146,  6177,   473,   474,  5988, 10543,
   10543,-32768,     7, 10543, 10396,    -5,   452,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,  -146,   454,   455, 10604,-32768,
  -32768, 10543,-32768,-32768,-32768,-32768, 10543,  7122,  7122,  7122,
   10543, 10543, 10543, 10543, 10543,-32768, 10543, 10561,   456, 10637,
     457,  3899,   458,  3989,  4132,  4154,  4245,   824,  2203,  2241,
    2241,  2241,  2241,  2241,  2241,   260,   260,   314,   314,   314,
     314,  4354,-32768,  8110,  8110,  8110,-32768,   459,-32768,-32768,
     784,  8110,  -146,-32768,-32768, 10543, 10543,  4374,-32768,-32768,
  -32768,  7122,  7122,-32768,  7122,    36,-32768,-32768,-32768,  8110,
  -32768,  8110,  4400,  8110,  8110,-32768,  4664,-32768,   463,   787,
   10543,-32768,-32768,  7122,-32768, 10543, 10543, 10543,-32768, 10543,
    8110,  8110,-32768,-32768,-32768,-32768, 10543, 10543,-32768, 10543,
    7375,-32768,-32768,-32768,-32768, 10543,  8110,  8110,-32768,  8110,
    8110,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,   734,  4830,  4854,   740,-32768,   231,   315,
     917, 10543, 10543,  8110,  7122,  7122,-32768,-32768,  8110, 11723,
    4916,-32768,  4958,-32768,-32768, 10543,-32768,  5084,-32768,-32768,
  -32768,-32768,-32768, 10543,  8110,-32768,-32768,-32768,-32768,  -134,
  -32768,-32768,-32768,  8110,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768, 10543,-32768,-32768,
  -32768,-32768,-32768,-32768,  8110,-32768, 10543, 10543,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,  5108, 10543,-32768,
  -32768, 10543,  8110,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    5290,   569,   571,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,     2,  8110,     9,  8110,-32768,-32768,   799,-32768,-32768,
  -32768,  -146, 10543,  1838,   485,-32768,-32768,-32768,-32768,-32768,
  -32768,  -146, 10543, 10543,  1838,   486,-32768,-32768,-32768,-32768,
    8110,  8110,  -146,  8110,   -44,-32768,-32768,-32768, 10543,-32768,
   10543,  8297,-32768,   491,   480, 10667, 10790, 10823, 10842, 10861,
   10882,   492,  5338,  5528,  5717,  5840,   493, 10543, 10543, 10543,
   10543, 10543, 10543, 10543, 10543, 10543,-32768,-32768,-32768,   494,
     490, 10543,  5860, 10905,  6095,-32768, 10543, 10543, 10543,   516,
    6209,   514,  6284,-32768,-32768,  6417,  8110,   518,   -69, 10926,
    6437,   848, 10543, 10543,   849,   529,  9234,   528,  9608,  9715,
    9608,  9715,-32768, 10543, 10543,  8110, 10543,-32768, 10543,-32768,
    8110,  8110,  8110, 10543,  8110,  8110, 10543,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,  8110, 10543,-32768,  8110,-32768,
   10543,-32768,-32768,-32768,-32768,-32768,  8110,   533,-32768,-32768,
     534,   535, 10543,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    7122,  7122, 10543, 10543, 10543, 10543,   536, 10950, 10969,   538,
    6461,  6785,  6805,  6841,  7037, 10543,-32768,  7219,  -146,-32768,
     -15,  8110,  7437,   540,   865, 10543,-32768, 10543, 10543,-32768,
    -146,-32768, 10543,   900,  7477,  7596,-32768, 10543,-32768,  8110,
    8110,  8110,  8110,  8110,  8110,  8110,  8110,-32768,-32768,    -7,
      39, 11002, 11032, 11051, 11070,  7623,  7643,  7732,  7876, 10543,
   10543, 10543, 10543, 10543, 10543, 10543,-32768, 10543,   543,-32768,
  -32768,-32768,   546, 10543, 10543,-32768,   550,   551,  7974,   554,
    8017,   868, 10543, 10543,   552,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,   557,-32768, 10543,-32768,-32768,-32768,-32768,  7122,
   10543, 10543, 10543,   559, 11089, 11108,  8255,  8348,  8391,  8110,
    8110,  -146,  -146,  8110,   562,-32768,-32768, 10543,-32768, 10543,
  -32768,  8110,  8110,  -146,     3,   567, 11127, 11155,  8722,  8765,
    9096,-32768, 10543, 10543, 10543,   560,   574, 10543,  8110,  7335,
     575,-32768,-32768,-32768,   568, 10543,-32768,-32768,  7122, 10543,
   10543, 11174,  9139,  9472,-32768,-32768,   576, 10543,-32768,   -18,
     570, 11207, 11226,  9513,    69, 10543, 10543,   581,  9846,-32768,
  -32768,-32768,   579, 10543,-32768,-32768,  7122,-32768,  -146, 11247,
    9889,   888, 10543,-32768, 11270, 11291, 11315,   586, 10543,-32768,
   10084,-32768,-32768,-32768,  -146, 11334, 10543,   588, 10220,  -146,
   10543,    45,  8110,-32768,  -146,   590,-32768,   959,   969,-32768
};

static const short yypgoto[] =
{
  -32768,-32768,   460,     0,-32768,-32768,  -167,  1396,   -46,   585,
    1380,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,   410,-32768,-32768,-32768,-32768,-32768,   288,  1978,-32768,
    -163,-32768,-32768,   949,-32768,   -75,-32768,-32768,-32768,-32768,
     495,   812,-32768,   -73,-32768,-32768,  -902,-32768,-32768,  -165,
    -575,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
     -28,    24,    21,    -4,   195,  -203,-32768,-32768,-32768,-32768,
  -32768,-32768,  -287,   -35,   -29
};


#define	YYLAST		12087


static const short yytable[] =
{
     152,   687,   560,   349,  1005,   420,   502,   256,   257,   600,
    1219,  1268,   604,   770,   608,   609,  1216,   612,  1432,   261,
    1591,   200,   175,   253,   199,   199,   189,   247,   297,   277,
    1519,   455,  1408,  1305,   373,   476,   294,   199,   771,   285,
     290,  1336,   199,   345,   640,   238,  1226,   177,  1419,   435,
     239,   252,   258,  1535,  1132,  1421,  1619,   275,   375,   384,
     238,   199,   371,   380,   293,   239,   496,   438,   344,  1235,
    1285,   343,   238,   199,   452,  1128,   457,   239,  1212,   190,
     468,   473,   263,   361,   946,   259,   374,   383,  1182,   819,
     920,   516,   176,   179,   680,   260,   178,   436,   453,   820,
     458,  1140,   449,   386,   469,   474,   921,   534,   466,  1269,
     947,  1252,   681,   180,   483,  1129,   181,   422,   199,   235,
     236,   339,   494,   772,   688,   773,  1283,  1536,  1537,   690,
    1592,   499,   236,   387,   422,   261,   235,   236,   298,   623,
    1183,   501,   532,   348,   774,   199,   506,   508,   511,   513,
     760,  1244,  1245,  1520,   922,   262,   238,  1295,  1433,   182,
    1272,   239,   582,  1620,   361,  1273,   948,   235,   236,   271,
     183,   641,   497,   238,  1235,   923,   598,   601,   239,   603,
     606,   699,   438,   610,   340,   613,   614,   615,   616,   642,
     581,   439,   238,    49,    50,  1538,  1270,   239,   263,   595,
     762,   719,   299,  1286,   682,  1621,   271,   683,   438,   775,
     776,  1236,  1539,   471,   730,   924,   925,   926,   271,   199,
     238,  1237,   254,   300,  1593,   239,  1291,   184,   278,  1235,
     644,   777,   438,   456,  1287,   295,   647,   500,   641,   235,
     236,   754,   346,   279,   651,   652,   653,  1217,   912,   238,
     949,  1434,   423,  1246,   239,   643,  1253,   376,   385,   516,
     764,  1332,   927,  1521,  1306,   361,   928,   624,   264,   423,
     755,   413,  1337,   625,   195,   265,   238,   950,   951,  1420,
     185,   239,   794,   186,   686,   424,  1422,   778,   165,   779,
     271,   744,   438,   389,  1540,   626,   952,   454,   692,   459,
     982,   745,   424,   470,   475,  1145,   439,   191,   934,   685,
     191,  1541,   929,   238,   236,   249,  1236,  1402,   239,   191,
     930,   931,   425,  1296,  1480,   503,  1237,  1297,   291,    95,
      96,   238,   439,   305,   194,   696,   239,   746,   516,   390,
    1247,   425,   786,   238,   761,   953,   763,   765,   239,   357,
     701,   381,   187,   703,   188,   712,   439,   199,   191,   913,
     695,   583,    49,    50,   717,   255,   876,   787,   648,   722,
     723,  1236,   341,   932,   191,   193,   199,   649,  1292,   267,
     711,  1237,  1021,   710,  1047,  1072,   191,   516,   191,  1248,
     450,   736,   196,   191,   191,   281,    49,    50,   742,   532,
     533,   282,  -166,   283,   751,   822,   823,   747,   296,   488,
     347,   191,   647,   532,   533,   472,   439,   935,   936,   350,
     197,   767,   769,   348,   781,    49,    50,   914,  1079,   935,
     936,  1543,  1544,   703,   824,   302,   351,  1653,  1654,   957,
     352,   517,   790,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,   797,   353,   667,   354,
     915,  1627,  1628,   355,   604,   388,  1100,   516,  1102,   391,
     235,   236,   803,   825,   937,   938,   393,   939,   940,   805,
     806,   807,   808,   394,   303,   941,   942,   943,   944,   411,
     814,   815,   816,   817,   412,    49,    50,   414,    95,    96,
     988,   415,  1001,   831,   832,   833,   421,   238,   528,   529,
     530,   356,   239,   531,   504,   434,   477,   846,   847,   849,
     851,   853,   855,   857,   859,   861,   863,   865,   867,   869,
     871,   873,    95,    96,   955,   505,   878,   880,   882,   884,
     886,   888,   890,   892,   894,   896,   898,   900,   902,   904,
     906,   908,  1049,  1074,   713,   430,   431,  1018,   956,  1044,
     547,   548,   549,   970,   978,   550,   551,   515,   985,   433,
     238,   191,   999,   498,   989,   239,   592,   593,  1002,   594,
    1009,  1019,   617,  1045,  1070,   153,  1024,   619,   969,   977,
     620,   968,   630,   984,   703,   176,   983,   998,   631,   632,
     997,   633,   634,   635,   636,   201,   202,   203,  1008,   517,
     637,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,   638,   639,   667,   670,  1097,   559,
     668,   304,  1099,   579,  1101,  1005,  1103,  1104,  1105,  1106,
     191,   671,   191,   191,   664,   665,   666,   676,   677,   667,
     678,   679,   691,   693,  1107,  1108,  1109,  1110,  1111,  1112,
    1113,  1114,  1115,  1116,  1117,  1118,  1119,  1120,  1121,   707,
     714,  1123,  1239,  1124,   733,   738,   739,  1125,   741,   759,
    1131,   560,   191,   791,   792,   799,   798,   800,  1254,  1137,
     804,   519,   520,   521,   522,   523,   524,   525,   526,   527,
     528,   529,   530,   667,  1148,   531,   584,   531,   425,   550,
     875,   535,   877,   191,  1149,   910,   911,   959,   191,   191,
     980,  1075,  1080,  1082,  1151,  1152,  1153,  1154,  1081,  1147,
     269,  1156,   509,   509,   509,  1086,  1087,   517,   199,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,  1090,  1096,   667,  1134,  1170,  1171,   689,  1136,
    1135,  1138,   971,  1139,   509,   509,  1141,   986,   509,   235,
     236,  1000,  1143,  1150,  1140,  1144,   199,  1158,  1159,  1010,
    1020,  1161,  1046,  1071,   270,  1163,   191,  1166,  1168,  1173,
    1169,  1186,  1172,  1174,  1175,  1178,  1187,  1209,  1179,  1189,
    1206,  1180,  1190,   844,  1207,   175,   238,  1224,  1208,  1204,
    1225,   239,  1229,  1233,  1256,   585,  1280,   517,  1205,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,   235,   236,   667,  1284,  1267,  1281,   724,   251,
    1294,   582,  1307,  1319,  1320,  1338,   516,  1340,  1341,  1357,
    1358,  1360,   292,  1367,  1378,  1366,  1379,   306,  1375,   342,
     238,   586,  1391,  1394,  1417,   239,  1418,   962,  1423,   581,
     235,   236,  1443,   484,   372,   382,   516,  1213,  1426,  1430,
     191,   191,  1466,   271,  1442,  1450,  1455,  1465,   204,  1223,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   199,  1476,   238,   191,  1474,
    1479,  1218,   239,  1220,   451,  1222,   485,  1483,  1486,  1344,
     467,   271,  1487,  1351,  1488,  1497,  1498,   963,  1499,  1509,
     516,  1510,   272,  1524,  1525,  1531,  1561,  1570,   509,  1562,
      49,    50,  1565,  1566,   708,  1573,  1568,   587,   588,  1227,
    1574,  1581,  1604,   964,   273,  1587,   589,  1639,   191,  1658,
    1595,  1609,  1234,  1623,  1260,  1243,  1605,  1608,  1617,  1659,
     945,  1633,   965,   516,  1631,   842,   486,   561,   580,  1644,
     591,  1649,  1656,   280,     0,     0,  1274,   596,  1241,  1263,
       0,     0,     0,   516,  1264,   829,     0,     0,     0,   235,
     236,     0,   618,   966,     0,     0,   622,     0,     0,     0,
    1003,     0,     0,     0,  1262,     0,  1277,     0,   509,     0,
       0,  1157,     0,     0,     0,     0,   191,     0,  1282,     0,
    1004,  1290,     0,     0,     0,     0,   238,     0,  1302,  1304,
     583,   239,     0,     0,     0,  1397,     0,     0,     0,     0,
     271,  1317,     0,     0,  1328,  1313,     0,     0,  1324,  1330,
    1331,     0,     0,  1333,   538,   539,   540,   541,   542,   543,
     544,   545,   546,   547,   548,   549,    95,    96,   550,  1316,
       0,   516,  1327,     0,     0,     0,   191,  1345,  1347,  1349,
       0,  1352,  1353,  1354,  1355,     0,   487,     0,     0,     0,
     843,     0,     0,   509,   509,   509,   509,   509,   509,   509,
     509,   509,   509,   509,   509,   509,   509,     0,     0,     0,
       0,   509,   509,   509,   509,   509,   509,   509,   509,   509,
     509,   509,   509,   509,   509,   509,   509,     0,     0,     0,
       0,   703,   703,     0,   703,     0,     0,     0,     0,     0,
       0,     0,   697,     0,     0,     0,     0,     0,     0,  1242,
    1380,     0,     0,   603,     0,  1119,     0,  1119,     0,     0,
       0,   709,     0,     0,     0,   716,  1385,  1386,     0,   509,
     703,   535,     0,     0,     0,  1390,     0,     0,     0,     0,
       0,   128,   129,  1459,     0,     0,     0,     0,   732,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,  1396,     0,   667,  1398,  1400,   133,   134,   135,   136,
     137,   138,     0,     0,     0,  1405,   517,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,   128,   129,     0,   731,     0,     0,
    1318,     0,     0,  1329,     0,     0,     0,  1410,     0,     0,
       0,     0,     0,     0,     0,     0,  1411,  1412,     0,   133,
     134,   135,   136,   137,   138,     0,     0,     0,  1414,     0,
     517,  1415,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,     0,   667,     0,     0,
       0,   796,     0,     0,     0,     0,     0,     0,   821,     0,
       0,   828,  1425,     0,   830,     0,     0,     0,     0,     0,
       0,   516,  1428,   517,     0,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,   664,   665,   666,  1436,     0,
     667,     0,     0,     0,   802,   516,     0,   520,   521,   522,
     523,   524,   525,   526,   527,   528,   529,   530,  1457,  1458,
     531,  1460,  1461,  1462,  1463,  1464,   916,   917,   918,   919,
       0,  1467,   591,     0,   954,   958,  1471,  1472,   961,   967,
       0,   979,     0,     0,     0,   987,     0,     0,     0,     0,
       0,     0,  1484,  1485,     0,     0,  1007,    17,    18,  1043,
    1068,     0,     0,  1489,  1490,     0,  1491,   552,  1492,     0,
       0,     0,   553,  1493,     0,     0,  1494,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1495,     0,     0,     0,
    1496,   517,  1211,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
    1501,  1503,  1505,  1506,  1507,  1508,     0,     0,     0,     0,
       0,     0,  1011,     0,  1012,     0,     0,     0,     0,   409,
     199,     0,     0,     0,     0,     0,     0,   554,  1528,     0,
       0,     0,  1530,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1133,     0,     0,   191,   443,     0,     0,
     555,     0,     0,   462,     0,     0,     0,     0,     0,   478,
    1554,  1555,  1556,  1557,  1558,  1559,   361,  1560,     0,     0,
    1146,   556,     0,  1563,     0,     0,     0,   510,   512,   514,
       0,     0,  1571,  1572,     0,   539,   540,   541,   542,   543,
     544,   545,   546,   547,   548,   549,     0,     0,   550,  1576,
    1578,  1579,  1580,  1164,  1013,     0,     0,     0,  1014,   605,
     607,     0,     0,   611,     0,   236,   238,  1588,     0,  1589,
       0,   239,     0,     0,   602,     0,     0,     0,     0,     0,
       0,     0,  1601,  1602,  1603,     0,     0,     0,     0,   621,
       0,     0,     0,     0,     0,     0,     0,     0,  1611,  1613,
    1614,     0,     0,     0,     0,     0,     0,  1618,  1015,     0,
       0,     0,     0,     0,     0,  1629,  1630,     0,     0,     0,
       0,  1016,     0,  1634,     0,     0,  1635,     0,     0,     0,
       0,   646,  1640,     0,     0,     0,     0,     0,  1645,     0,
       0,   557,     0,     0,     0,     0,  1648,     0,     0,     0,
    1652,     0,     0,     0,     0,     0,   561,   580,   516,     0,
       0,     0,   558,     0,     0,     0,   674,   675,     0,     0,
       0,     0,   509,   509,   509,-32768,-32768,-32768,-32768,-32768,
  -32768,   526,   527,   528,   529,   530,     0,     0,   531,     0,
       0,   131,     0,     0,     0,   517,   694,   654,   655,   656,
     657,   658,   659,   660,   661,   662,   663,   664,   665,   666,
       0,     0,   667,     0,     0,     0,   809,     0,     0,   140,
       0,     0,     0,     0,     0,     0,   509,   509,     0,   509,
       0,     0,     0,   704,     0,     0,     0,   698,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   509,     0,
       0,     0,     0,     0,   559,     0,     0,   674,   715,     0,
       0,   718,     0,   720,   721,   509,     0,     0,     0,     0,
       0,     0,     0,   729,     0,     0,  1240,     0,     0,     0,
       0,     0,     0,     0,     0,   734,   735,   737,     0,     0,
       0,     0,     0,     0,   743,     0,     0,     0,   750,   509,
     509,   753,     0,  1258,     0,     0,     0,     0,     0,     0,
       0,   758,     0,   785,     0,     0,     0,     0,     0,     0,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,     0,   789,     0,     0,
       0,     0,   793,     0,   795,     0,     0,     0,     0,     0,
       0,     0,    24,     0,     0,     0,     0,     0,     0,     0,
     516,   801,  1308,     0,     0,     0,  1310,  1315,     0,     0,
    1326,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     810,   811,   812,   813,   516,     0,     0,  1339,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   848,   850,
     852,   854,   856,   858,   860,   862,   864,   866,   868,   870,
     872,   874,   535,     0,     0,     0,   879,   881,   883,   885,
     887,   889,   891,   893,   895,   897,   899,   901,   903,   905,
     907,   909,     0,    49,    50,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1368,     0,     0,     0,     0,     0,
      54,    55,     0,     0,     0,    56,     0,     0,     0,     0,
       0,   960,     0,     0,   976,     0,     0,   981,     0,     0,
       0,   990,   996,     0,  1078,     0,     0,     0,   166,     0,
       0,     0,     0,  1041,  1066,     0,    67,     0,    69,     0,
       0,     0,     0,     0,     0,     0,     0,   192,     0,     0,
     198,     0,     0,     0,     0,     0,     0,     0,   517,   268,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,  1098,   667,     0,     0,     0,   818,
       0,     0,     0,     0,     0,   509,   509,     0,   675,   358,
       0,     0,   240,     0,     0,     0,     0,     0,   392,     0,
       0,  1409,  1191,  1192,  1193,  1194,  1195,  1196,  1197,  1198,
    1199,  1200,  1201,  1202,   432,     0,     0,     0,    94,    95,
      96,     0,     0,     0,  1127,     0,   437,     0,   441,     0,
       0,     0,     0,   460,   461,     0,     0,     0,     0,     0,
     103,     0,     0,     0,     0,     0,     0,     0,     0,   489,
       0,   495,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
       0,     0,     0,  1424,  1155,   124,   125,   126,   127,   128,
     129,     0,     0,  1427,   509,     0,     0,     0,     0,     0,
     535,     0,     0,     0,  1431,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   509,   146,   244,     0,     0,     0,     0,
     245,     0,     0,   246,     0,     0,     0,     0,  1126,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     517,   509,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,   516,     0,   667,     0,     0,
       0,   -87,     0,     0,   517,     0,   518,   519,   520,   521,
     522,   523,   524,   525,   526,   527,   528,   529,   530,     0,
       0,   531,     0,     0,     0,  1088,     0,     0,     0,     0,
       0,   684,   536,   516,   537,   538,   539,   540,   541,   542,
     543,   544,   545,   546,   547,   548,   549,     0,     0,   550,
    1518,     0,     0,  1089,     0,     0,     0,     0,     0,     0,
       0,     0,  1529,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   221,   222,   223,     5,
    1221,   224,   225,     8,   226,   227,   228,   229,   230,   231,
     232,     0,     0,     0,     0,     0,     0,     0,   516,     0,
     702,     0,   705,   706,     0,     0,     0,     0,    24,     0,
       0,     0,     0,     0,     0,     0,  1228,     0,  1230,  1231,
     516,     0,     0,  1232,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   199,     0,     0,     0,     0,     0,  1250,
    1251,     0,   740,  1585,  1586,     0,     0,     0,  1255,     0,
       0,     0,     0,     0,     0,  1590,     0,     0,  1259,  1261,
       0,  1265,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   516,   782,     0,     0,     0,     0,   783,   784,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    49,
      50,  1279,     0,     0,     0,     0,     0,     0,     0,  1293,
       0,     0,  1299,  1300,     0,     0,    54,    55,     0,     0,
    1637,    56,     0,     0,     0,     0,     0,     0,  1309,     0,
       0,  1314,     0,     0,  1325,     0,  1647,     0,     0,     0,
    1335,  1651,     0,     0,     0,     0,  1655,  1346,  1348,  1350,
       0,     0,    67,     0,    69,     0,   827,  1343,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1356,   845,-32768,-32768,-32768,-32768,-32768,-32768,
     545,   546,   547,   548,   549,     0,     0,   550,   271,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1372,  1373,     0,  1374,     0,     0,     0,   240,     0,
       0,  1369,  1370,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1382,   973,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    94,    95,    96,     0,     0,  1381,
    1389,     0,  1383,     0,     0,  1384,     0,     0,     0,     0,
    1076,  1077,     0,     0,     0,  1387,   103,     0,     0,   656,
     657,   658,   659,   660,   661,   662,   663,   664,   665,   666,
     974,     0,   667,     0,  1399,  1401,     0,     0,  1095,     0,
     115,   116,   117,   118,   119,   120,     0,   975,     0,     0,
       0,   124,   125,   126,   127,   128,   129,-32768,-32768,-32768,
  -32768,-32768,-32768,   662,   663,   664,   665,   666,     0,  1407,
     667,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     133,   134,   135,   136,   137,   138,     0,     0,  1122,     0,
       0,     0,     0,     0,     0,   241,   242,   243,   145,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     146,   244,     0,     0,     0,     0,   245,     0,   517,   246,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,     0,   667,     0,     0,     0,  1091,
     517,     0,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,  1162,   667,     0,  1429,
       0,  1092,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1437,  1440,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   517,  1456,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,     0,     0,   667,
       0,     0,     0,  1093,  1473,     0,  1188,     0,    -6,     1,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     2,     3,     4,     5,
       0,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,     0,     0,    16,     0,    17,    18,     0,     0,    19,
      20,     0,     0,     0,    21,    22,    23,     0,    24,    25,
    1502,  1504,     0,     0,     0,     0,     0,     0,  1500,    26,
       0,     0,    27,    28,     0,     0,     0,     0,    29,     0,
       0,    30,     0,     0,     0,     0,     0,    31,    32,     0,
       0,  1516,     0,     0,     0,     0,    33,    34,     0,     0,
       0,  1526,     0,  1527,     0,    35,    36,    37,    38,     0,
       0,     0,     0,  1534,    39,    40,     0,     0,    41,     0,
      42,     0,     0,    43,     0,     0,    44,    45,     0,     0,
       0,    46,     0,    47,     0,  1553,     0,     0,    48,    49,
      50,     0,     0,     0,    51,     0,    52,     0,     0,    53,
    1564,     0,     0,     0,     0,     0,    54,    55,     0,  1577,
       0,    56,    57,    58,    59,     0,    60,     0,    61,     0,
    1575,     0,     0,    62,     0,    63,     0,     0,     0,    64,
      65,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    66,    67,    68,    69,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    70,  1612,    71,
       0,    72,     0,  1606,     0,     0,     0,     0,     0,     0,
       0,  1610,     0,     0,    73,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1636,     0,     0,    74,
       0,     0,     0,     0,    75,    76,    77,    78,    79,    80,
       0,     0,    81,    82,    83,    84,     0,    85,    86,     0,
       0,     0,     0,    87,     0,    88,    89,    90,    91,    92,
      93,     0,     0,     0,    94,    95,    96,     0,     0,     0,
       0,    97,     0,    98,    99,     0,     0,   100,   101,     0,
       0,     0,     0,     0,     0,   102,   103,   104,   105,     0,
     106,     0,     0,     0,   107,   108,   109,     0,     0,     0,
     110,     0,   111,   112,   113,     0,     0,     0,     0,   114,
     115,   116,   117,   118,   119,   120,     0,   121,   122,     0,
     123,   124,   125,   126,   127,   128,   129,     0,   130,   131,
     132,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     133,   134,   135,   136,   137,   138,   139,   140,     0,     0,
       0,     0,     0,     0,   141,   142,   143,   144,   145,     0,
       0,     0,    -6,     1,     0,     0,     0,     0,     0,     0,
     146,   147,     0,     0,     0,     0,   148,     0,    -6,   149,
     836,   837,     4,   516,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1395,    16,     0,    17,
      18,     0,     0,    19,    20,     0,     0,     0,    21,    22,
      23,     0,     0,    25,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    26,     0,     0,    27,    28,     0,     0,
       0,     0,    29,     0,     0,    30,     0,     0,     0,     0,
     535,    31,    32,     0,     0,     0,     0,     0,     0,     0,
      33,    34,     0,     0,     0,     0,     0,     0,     0,    35,
      36,    37,    38,     0,     0,     0,     0,     0,    39,    40,
       0,     0,    41,     0,    42,     0,     0,    43,     0,   516,
      44,    45,     0,     0,     0,    46,     0,    47,     0,     0,
       0,     0,    48,    49,    50,     0,     0,     0,    51,     0,
      52,     0,     0,    53,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    57,    58,    59,     0,
      60,     0,    61,     0,     0,     0,   516,    62,     0,    63,
       0,     0,     0,    64,    65,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    66,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    70,     0,    71,     0,    72,   516,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    73,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    74,     0,     0,     0,     0,    75,    76,
      77,    78,     0,    80,     0,     0,    81,    82,   838,    84,
       0,    85,    86,     0,     0,     0,     0,     0,     0,    88,
      89,    90,    91,    92,    93,     0,     0,     0,     0,    95,
      96,     0,     0,     0,     0,    97,     0,    98,    99,     0,
       0,   100,   101,     0,     0,     0,     0,     0,     0,   102,
       0,   104,   105,     0,   106,     0,     0,   516,   107,   108,
     109,     0,     0,     0,   110,     0,   111,   112,   113,     0,
       0,     0,     0,   114,     0,     0,     0,     0,     0,     0,
       0,   121,   122,     0,   123,     0,     0,     0,     0,   128,
     129,     0,   130,   131,   132,   221,   222,   223,     5,     0,
     224,   225,     8,   226,   227,   228,   229,   230,   231,   232,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
     139,   140,     0,     0,     0,     0,     0,    24,   141,   839,
     840,   841,     0,   517,     0,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,   664,   665,   666,     0,     0,
     667,     0,    -6,     0,  1094,     0,     0,     0,   307,   308,
     309,   310,   311,   312,     0,     0,   516,   313,   314,   315,
     316,   317,   318,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   319,     0,     0,   320,     0,
     536,     0,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,     0,   321,   550,    49,    50,
       0,  1142,     0,     0,     0,     0,     0,     0,     0,   322,
     516,     0,     0,     0,     0,    54,    55,     0,     0,   517,
      56,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,     0,     0,     0,
    1160,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    67,     0,    69,     0,   323,   324,   325,   326,   327,
     328,   329,   330,   331,   332,   333,   517,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,     0,     0,     0,  1176,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     334,     0,     0,     0,     0,     0,   517,   240,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,     0,     0,     0,  1177,     0,     0,
       0,   335,     0,    94,    95,    96,     0,     0,     0,   221,
     222,   223,     5,     0,   224,   225,     8,   226,   227,   228,
     229,   230,   231,   232,     0,   103,     0,     0,     0,     0,
    1025,     0,  1026,     0,     0,     0,     0,     0,     0,   516,
       0,    24,     0,     0,     0,     0,     0,     0,     0,   115,
     116,   117,   118,   119,   120,     0,     0,     0,  1027,   516,
     124,   125,   126,   127,   128,   129,   199,   517,     0,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,     0,     0,   667,     0,     0,     0,  1185,   133,
     134,   135,   136,   137,   138,     0,     0,     0,     0,     0,
     336,   337,     0,     0,   241,   242,   243,   145,     0,     0,
       0,     0,   361,     0,  1028,  1029,     0,     0,     0,   146,
     244,     0,    49,    50,     0,   245,     0,     0,   246,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    54,
      55,     0,   535,     0,    56,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1030,     0,     0,     0,     0,     0,
       0,   236,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    67,   517,    69,   518,   519,
     520,   521,   522,   523,   524,   525,   526,   527,   528,   529,
     530,   516,     0,   531,     0,     0,   834,   238,  1031,     0,
       0,     0,   239,     0,  1015,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1032,     0,     0,
       0,     0,     0,     0,     0,  1033,  1034,     0,     0,     0,
     517,   240,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,     0,   667,     0,     0,
       0,  1257,     0,     0,     0,     0,     0,    94,    95,    96,
       0,  1035,     0,  1036,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1037,  1038,  1039,     0,   103,
       0,   516,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1040,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   115,   116,   117,   118,   119,   120,     0,
       0,     0,     0,     0,   124,   125,   126,   127,   128,   129,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,     0,     0,  1050,     0,
       0,     0,     0,   133,   134,   135,   136,   137,   138,     0,
       0,     0,    24,     0,     0,    17,    18,     0,   241,   242,
     243,   145,     0,     0,  1051,   552,     0,     0,     0,     0,
     553,     0,     0,   146,   244,     0,     0,   199,     0,   245,
       0,     0,   246,     0,     0,     0,     0,     0,     0,   517,
    1052,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,     0,     0,   517,
    1266,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,   516,     0,   667,     0,     0,     0,
    1278,     0,     0,    49,    50,   554,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   516,     0,     0,     0,
      54,    55,  1053,     0,     0,    56,     0,     0,   555,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   236,     0,     0,     0,  1054,     0,     0,   556,
       0,     0,     0,     0,  1055,     0,  1056,     0,  1057,  1058,
       0,     0,   536,     0,   537,   538,   539,   540,   541,   542,
     543,   544,   545,   546,   547,   548,   549,     0,   238,   550,
    1059,  1060,   835,   239,     0,  1015,     0,  1061,     0,     0,
       0,     0,     0,     0,   238,     0,     0,     0,  1062,   239,
       0,     0,     0,     0,     0,     0,     0,   516,     0,     0,
       0,   517,   240,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
       0,     0,  1359,     0,     0,     0,     0,     0,    94,    95,
      96,     0,     0,  1063,     0,   221,   222,   223,     5,  1064,
     224,   225,     8,   226,   227,   228,   229,   230,   231,   232,
     103,     0,     0,     0,     0,     0,     0,     0,     0,   557,
       0,     0,     0,     0,  1065,     0,     0,    24,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
     558,   359,     0,     0,   360,   124,   125,   126,   127,   128,
     129,   517,   199,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,   516,     0,   667,   131,
       0,     0,  1361,     0,   133,   134,   135,   136,   137,   138,
       0,     0,     0,     0,     0,     0,   516,     0,     0,   241,
     242,   243,   145,     0,     0,     0,     0,   140,   361,     0,
       0,     0,     0,     0,   146,   244,     0,     0,    49,    50,
     245,     0,   516,   246,     0,     0,   362,     0,     0,     0,
       0,     0,     0,     0,     0,    54,    55,     0,     0,     0,
      56,     0,   619,     0,   363,     0,     0,     0,     0,     0,
     364,     0,     0,   365,     0,     0,   235,   236,     0,     0,
     366,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    67,     0,    69,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   238,     0,     0,     0,     0,   239,     0,
       0,     0,     0,     0,   517,     0,   654,   655,   656,   657,
     658,   659,   660,   661,   662,   663,   664,   665,   666,     0,
       0,   667,     0,     0,     0,  1362,   517,   240,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,     0,     0,     0,  1363,     0,     0,
       0,     0,     0,    94,    95,    96,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   367,   103,   221,   222,   223,     5,
       0,   224,   225,     8,   226,   227,   228,   229,   230,   231,
     232,     0,     0,     0,     0,     0,     0,   368,     0,   115,
     116,   117,   118,   119,   120,     0,     0,     0,    24,   395,
     124,   125,   126,   127,   128,   129,   369,   517,     0,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,     0,     0,   667,     0,     0,     0,  1364,   133,
     134,   370,   136,   137,   138,     0,     0,   535,     0,     0,
       0,     0,     0,     0,   241,   242,   243,   145,     0,     0,
     396,     0,     0,     0,     0,     0,     0,     0,     0,   146,
     244,     0,     0,     0,     0,   245,     0,     0,   246,     0,
       0,     0,     0,     0,     0,     0,   516,     0,     0,    49,
      50,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    54,    55,   397,     0,
     398,    56,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   399,   400,     0,     0,     0,   517,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,    67,   667,    69,     0,   517,  1365,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,     0,     0,     0,  1371,     0,     0,
       0,     0,   517,   401,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,     0,     0,   667,
       0,     0,     0,  1376,     0,     0,     0,     0,   240,   201,
     202,   203,     0,   416,     0,     0,   402,     0,   417,   403,
       0,     0,     0,     0,     0,     0,   418,     0,     0,     0,
       0,     0,     0,   404,    94,    95,    96,     0,     0,   405,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,   103,     0,     0,     0,
       0,     0,   516,     0,     0,     0,     0,     0,     0,     0,
       0,   406,    24,     0,     0,     0,     0,     0,     0,     0,
     115,   116,   117,   118,   119,   120,   516,     0,     0,   444,
       0,   124,   125,   126,   127,   128,   129,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   445,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     133,   134,   135,   136,   137,   138,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   241,   242,   243,   145,     0,
       0,     0,     0,   361,     0,     0,     0,     0,   516,     0,
     146,   244,     0,    49,    50,     0,   245,     0,     0,   246,
       0,     0,   419,     0,     0,     0,     0,     0,     0,     0,
      54,    55,     0,     0,     0,    56,     0,     0,     0,     0,
       0,   446,     0,     0,     0,     0,     0,     0,     0,     0,
     516,     0,   236,     0,     0,   447,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    67,   536,    69,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,     0,     0,   550,     0,     0,  1083,   238,   221,
     222,   223,     5,   239,   224,   225,     8,   226,   227,   228,
     229,   230,   231,   232,     0,     0,   517,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,    24,   240,   667,     0,     0,     0,  1377,     0,     0,
       0,     0,     0,     0,     0,   448,     0,   991,   992,   516,
       0,     0,     0,     0,     0,     0,   199,     0,    94,    95,
      96,     0,   204,     0,   205,   206,   207,   208,   209,   210,
     211,   212,   213,   214,   215,   216,   217,   218,   219,     0,
     103,     0,     0,     0,     0,     0,   516,     0,     0,     0,
       0,     0,     0,     0,     0,   993,     0,     0,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
     516,     0,    49,    50,     0,   124,   125,   126,   127,   128,
     129,     0,     0,     0,     0,     0,     0,     0,     0,    54,
      55,     0,     0,     0,    56,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
     235,   236,     0,     0,     0,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,    67,     0,    69,     0,     0,
       0,     0,     0,     0,   146,   244,     0,     0,     0,     0,
     245,     0,   517,   246,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,     0,     0,   667,
       0,   271,     0,  1392,     0,     0,   517,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,   240,     0,   667,     0,     0,     0,  1393,     0,     0,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,     0,    94,    95,    96,
       0,     0,   994,   995,     0,     0,     0,     0,     0,     0,
       0,     0,    24,     0,     0,     0,     0,     0,   517,   103,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,     0,   667,     0,   199,     0,  1403,
       0,     0,   516,   115,   116,   117,   118,   119,   120,   233,
       0,     0,     0,     0,   124,   125,   126,   127,   128,   129,
     517,     0,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,   234,   667,     0,     0,
       0,  1404,     0,   133,   134,   135,   136,   137,   138,     0,
     516,     0,     0,    49,    50,     0,     0,     0,   241,   242,
     243,   145,     0,     0,     0,     0,     0,     0,     0,     0,
      54,    55,     0,   146,   244,    56,     0,     0,     0,   245,
       0,     0,   246,     0,     0,     0,     0,     0,     0,     0,
       0,   235,   236,     0,     0,   237,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    67,     0,    69,   517,
    1214,   518,   519,   520,   521,   522,   523,   524,   525,   526,
     527,   528,   529,   530,     0,     0,   531,     0,   238,   221,
     222,   223,     5,   239,   224,   225,     8,   226,   227,   228,
     229,   230,   231,   232,     0,     0,   517,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,    24,   240,   667,     0,     0,     0,  1406,     0,     0,
     517,     0,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,   199,   667,    94,    95,
      96,  1413,     0,     0,     0,     0,     0,     0,   287,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     103,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   288,     0,     0,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
     516,     0,    49,    50,     0,   124,   125,   126,   127,   128,
     129,     0,     0,     0,     0,     0,     0,     0,     0,    54,
      55,     0,     0,     0,    56,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
     235,   236,     0,     0,   289,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,    67,     0,    69,     0,     0,
       0,     0,     0,     0,   146,   244,     0,     0,     0,     0,
     245,     0,     0,   246,     0,     0,     0,   238,   221,   222,
     223,     5,   239,   224,   225,     8,   226,   227,   228,   229,
     230,   231,   232,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   377,     0,     0,     0,     0,     0,     0,
      24,   240,   517,     0,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,     0,     0,   667,
       0,     0,     0,  1416,     0,   199,     0,    94,    95,    96,
       0,     0,     0,     0,     0,     0,     0,   378,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   103,
     517,     0,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,     0,   667,     0,     0,
       0,  1451,     0,   115,   116,   117,   118,   119,   120,   516,
       0,    49,    50,     0,   124,   125,   126,   127,   128,   129,
       0,     0,     0,     0,     0,     0,     0,     0,    54,    55,
       0,     0,     0,    56,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   133,   134,   135,   136,   137,   138,   235,
     236,     0,     0,   379,     0,     0,     0,     0,   241,   242,
     243,   145,     0,     0,    67,     0,    69,     0,     0,     0,
       0,     0,     0,   146,   244,     0,     0,     0,     0,   245,
       0,     0,   246,     0,     0,     0,   238,   221,   222,   223,
       5,   239,   224,   225,     8,   226,   227,   228,   229,   230,
     231,   232,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    24,
     240,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   516,     0,     0,     0,   463,     0,     0,     0,
       0,     0,     0,     0,   199,     0,    94,    95,    96,     0,
       0,     0,   535,     0,     0,     0,   464,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   103,     0,
     517,     0,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,     0,   667,     0,     0,
     361,  1452,   115,   116,   117,   118,   119,   120,     0,     0,
      49,    50,   516,   124,   125,   126,   127,   128,   129,     0,
       0,     0,     0,     0,     0,     0,     0,    54,    55,     0,
       0,     0,    56,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   133,   134,   135,   136,   137,   138,     0,   236,
       0,     0,     0,     0,     0,     0,     0,   241,   242,   243,
     145,     0,     0,    67,     0,    69,     0,     0,     0,     0,
       0,     0,   146,   244,     0,     0,     0,     0,   245,     0,
       0,   246,     0,     0,     0,   238,   221,   222,   223,     5,
     239,   224,   225,     8,   226,   227,   228,   229,   230,   231,
     232,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    24,   240,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   465,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   199,     0,    94,    95,    96,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   103,     0,   517,
       0,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,     0,     0,     0,
    1453,   115,   116,   117,   118,   119,   120,   535,     0,    49,
      50,  1321,   124,   125,   126,   127,   128,   129,     0,     0,
       0,     0,     0,     0,     0,     0,    54,    55,     0,     0,
       0,    56,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   133,   134,   135,   136,   137,   138,   235,   236,     0,
       0,     0,     0,     0,     0,     0,   241,   242,   243,   145,
       0,     0,    67,     0,    69,     0,     0,     0,     0,     0,
       0,   146,   244,     0,     0,     0,     0,   245,     0,     0,
     246,     0,     0,     0,   238,   221,   222,   223,     5,   239,
     224,   225,     8,   226,   227,   228,   229,   230,   231,   232,
       0,     0,   517,     0,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,    24,   240,   667,
       0,   516,   536,  1454,   537,   538,   539,   540,   541,   542,
     543,   544,   545,   546,   547,   548,   549,     0,     0,   550,
       0,     0,   199,  1468,    94,    95,    96,     0,     0,  1322,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   103,     0,     0,     0,
       0,     0,   517,  1323,   518,   519,   520,   521,   522,   523,
     524,   525,   526,   527,   528,   529,   530,     0,     0,   531,
     115,   116,   117,   118,   119,   120,   535,     0,    49,    50,
    1311,   124,   125,   126,   127,   128,   129,     0,     0,     0,
       0,     0,     0,     0,     0,    54,    55,     0,     0,     0,
      56,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     133,   134,   135,   136,   137,   138,   235,   236,   535,     0,
       0,     0,     0,     0,     0,   241,   242,   243,   145,     0,
       0,    67,     0,    69,     0,     0,     0,     0,     0,     0,
     146,   244,     0,     0,     0,     0,   245,     0,     0,   246,
       0,     0,     0,   238,   221,   222,   223,     5,   239,   224,
     225,     8,   226,   227,   228,   229,   230,   231,   232,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1275,     0,     0,     0,    24,   240,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1235,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   516,
       0,     0,     0,    94,    95,    96,     0,     0,  1312,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   516,
       0,     0,     0,     0,     0,   103,     0,   536,     0,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,     0,   516,   550,     0,     0,     0,  1470,   115,
     116,   117,   118,   119,   120,     0,     0,    49,    50,     0,
     124,   125,   126,   127,   128,   129,     0,     0,     0,     0,
       0,     0,     0,     0,    54,    55,     0,     0,     0,    56,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   133,
     134,   135,   136,   137,   138,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   241,   242,   243,   145,     0,     0,
      67,     0,    69,     0,     0,     0,     0,     0,     0,   146,
     244,     0,     0,     0,     0,   245,     0,     0,   246,     0,
    1236,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1237,   517,     0,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
       0,     0,  1475,     0,     0,     0,   240,     0,     0,     0,
       0,     0,   221,   222,   223,     5,     0,   224,   225,     8,
     226,   227,   228,   229,   230,   231,   232,     0,     0,     0,
       0,     0,    94,    95,    96,     0,     0,     0,     0,     0,
       0,     0,     0,  1276,    24,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   103,     0,   536,     0,   537,   538,
     539,   540,   541,   542,   543,   544,   545,   546,   547,   548,
     549,     0,     0,   550,     0,     0,     0,  1477,   115,   116,
     117,   118,   119,   120,   535,     0,     0,     0,     0,   124,
     125,   126,   127,   128,   129,     0,     0,     0,   536,  1215,
     537,   538,   539,   540,   541,   542,   543,   544,   545,   546,
     547,   548,   549,     0,     0,   550,     0,     0,   133,   134,
     135,   136,   137,   138,     0,    49,    50,     0,     0,     0,
       0,     0,     0,   241,   242,   243,   145,     0,     0,     0,
       0,     0,    54,    55,     0,     0,     0,    56,   146,   244,
       0,     0,     0,     0,   245,     0,     0,   246,   221,   222,
     223,     5,     0,   224,   225,     8,   226,   227,   228,   229,
     230,   231,   232,     0,     0,     0,     0,     0,    67,     0,
      69,     0,     0,     0,     0,     0,     0,     0,     0,   517,
      24,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,   516,     0,   517,
    1478,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,   516,     0,     0,
    1482,     0,     0,   517,   240,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,   664,   665,   666,     0,     0,
     667,     0,     0,     0,  1511,     0,     0,     0,     0,     0,
      94,    95,    96,   516,     0,     0,     0,     0,     0,     0,
       0,    49,    50,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   103,     0,     0,     0,     0,     0,    54,    55,
       0,     0,     0,    56,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   115,   116,   117,   118,
     119,   120,     0,     0,     0,     0,     0,   124,   125,   126,
     127,   128,   129,     0,    67,     0,    69,   479,   480,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   133,   134,   135,   136,
     137,   138,     0,     0,     0,   481,   482,     0,     0,     0,
       0,   241,   242,   243,   145,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   146,   244,     0,     0,
     240,     0,   245,     0,     0,   246,     0,     0,     0,     0,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,    94,    95,    96,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    24,     0,     0,     0,     0,     0,   103,     0,
       0,     0,     0,     0,   536,     0,   537,   538,   539,   540,
     541,   542,   543,   544,   545,   546,   547,   548,   549,     0,
       0,   550,   115,   116,   117,   118,   119,   120,     0,   516,
       0,     0,     0,   124,   125,   126,   127,   128,   129,     0,
       0,     0,     0,   490,   491,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   133,   134,   135,   136,   137,   138,     0,     0,
       0,   492,   493,    49,    50,     0,     0,   241,   242,   243,
     145,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      54,    55,   146,   244,     0,    56,     0,     0,   245,     0,
       0,   246,     0,     0,     0,   725,     0,     0,   726,     0,
     221,   222,   223,     5,     0,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,     0,    67,   517,    69,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,    24,     0,   667,     0,     0,   517,  1512,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,     0,     0,   667,     0,     0,     0,  1513,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   240,   517,     0,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,   664,   665,   666,     0,     0,
     667,     0,     0,     0,  1514,     0,     0,     0,    94,    95,
      96,   516,     0,   727,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    49,    50,     0,     0,     0,     0,     0,
     103,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      54,    55,     0,     0,   728,    56,     0,     0,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
       0,     0,     0,     0,     0,   124,   125,   126,   127,   128,
     129,     0,     0,     0,     0,     0,    67,    68,    69,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   146,   244,     0,   516,     0,     0,
     245,     0,    79,   246,     0,     0,     0,     0,   507,     0,
       0,     0,     0,     0,     0,     0,     0,    87,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    94,    95,
      96,     0,     0,   221,   222,   223,     5,     0,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,     0,   517,
     103,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,    24,   667,     0,     0,     0,
    1515,     0,     0,     0,   115,   116,   117,   118,   119,   120,
       0,     0,     0,     0,     0,   124,   125,   126,   127,   128,
     129,     0,     0,     0,     0,     0,     0,     0,     0,   516,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,     0,     0,     0,     0,   516,
       0,     0,     0,     0,   146,   147,    49,    50,     0,     0,
     148,     0,     0,   149,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    54,    55,     0,     0,     0,    56,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   221,   222,
     223,     5,     0,   224,   225,     8,   226,   227,   228,   229,
     230,   231,   232,     0,     0,     0,     0,     0,     0,    67,
      68,    69,     0,     0,     0,     0,     0,     0,     0,     0,
      24,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   672,
       0,   517,     0,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
       0,     0,  1517,     0,     0,    79,     0,     0,   516,     0,
       0,  1388,     0,     0,     0,     0,     0,     0,     0,  1607,
      87,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    94,    95,    96,     0,   516,     0,     0,     0,     0,
       0,    49,    50,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   103,     0,   516,     0,     0,    54,    55,
       0,     0,     0,    56,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   115,   116,   117,
     118,   119,   120,     0,     0,     0,     0,     0,   124,   125,
     126,   127,   128,   129,    67,     0,    69,   517,     0,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,     0,     0,   667,     0,     0,   133,   134,   135,
     136,   137,   138,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   241,   242,   243,   145,     0,     0,     0,     0,
       0,     0,     0,     0,   516,     0,     0,   146,   147,     0,
     240,     0,     0,   148,     0,     0,   149,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    94,    95,    96,     0,
       0,     0,   221,   222,   223,     5,   673,   224,   225,     8,
     226,   227,   228,   229,   230,   231,   232,     0,   103,   517,
       0,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,    24,     0,   667,     0,     0,     0,
    1523,   756,   115,   116,   117,   118,   119,   120,     0,     0,
       0,     0,     0,   124,   125,   126,   127,   128,   129,   517,
       0,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,     0,     0,     0,
    1532,     0,   133,   134,   135,   136,   137,   138,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   241,   242,   243,
     145,     0,     0,     0,     0,     0,     0,     0,   516,     0,
       0,     0,   146,   244,     0,    49,    50,     0,   245,     0,
       0,   246,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    54,    55,     0,   757,     0,    56,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   221,   222,   223,
       5,     0,   224,   225,     8,   226,   227,   228,   229,   230,
     231,   232,     0,     0,     0,     0,     0,     0,    67,     0,
      69,     0,     0,     0,     0,     0,     0,     0,   517,    24,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,     0,   667,     0,     0,     0,  1533,
       0,     0,     0,     0,   199,   517,   516,   654,   655,   656,
     657,   658,   659,   660,   661,   662,   663,   664,   665,   666,
       0,     0,   667,     0,   240,   517,  1549,   654,   655,   656,
     657,   658,   659,   660,   661,   662,   663,   664,   665,   666,
       0,     0,   667,     0,     0,     0,  1550,     0,     0,   516,
      94,    95,    96,     0,     0,     0,     0,     0,     0,     0,
      49,    50,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   103,     0,     0,     0,     0,    54,    55,     0,
       0,     0,    56,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   115,   116,   117,   118,
     119,   120,     0,     0,     0,     0,     0,   124,   125,   126,
     127,   128,   129,    67,   517,    69,   654,   655,   656,   657,
     658,   659,   660,   661,   662,   663,   664,   665,   666,     0,
       0,   667,     0,     0,     0,  1551,   133,   134,   135,   136,
     137,   138,   516,     0,     0,     0,     0,     0,     0,   271,
       0,   241,   242,   243,   145,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   146,   244,     0,   240,
       0,     0,   245,     0,     0,   246,     0,     0,   221,   222,
     223,     5,     0,   224,   225,     8,   226,   227,   228,   229,
     230,   231,   232,     0,     0,    94,    95,    96,     0,     0,
       0,     0,     0,     0,     0,     0,  1288,     0,     0,     0,
      24,     0,     0,     0,     0,     0,     0,   103,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   115,   116,   117,   118,   119,   120,     0,     0,     0,
       0,     0,   124,   125,   126,   127,   128,   129,   517,     0,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,     0,   667,     0,     0,     0,  1552,
       0,   133,   134,   135,   136,   137,   138,   516,     0,     0,
       0,    49,    50,     0,     0,     0,   241,   242,   243,   145,
       0,     0,     0,     0,     0,     0,     0,     0,    54,    55,
       0,   146,   244,    56,     0,     0,     0,   245,     0,     0,
     246,     0,     0,     0,     0,   221,   222,   223,     5,     0,
     224,   225,     8,   226,   227,   228,   229,   230,   231,   232,
       0,     0,     0,     0,    67,     0,    69,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   517,    24,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,     0,     0,     0,  1567,     0,     0,
     516,     0,     0,     0,  1438,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   517,
     240,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,     0,     0,     0,
    1569,     0,     0,   516,     0,     0,    94,    95,    96,     0,
       0,     0,     0,     0,     0,     0,     0,  1289,    49,    50,
       0,     0,     0,     0,     0,     0,     0,     0,   103,     0,
       0,     0,     0,     0,     0,    54,    55,     0,     0,     0,
      56,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   115,   116,   117,   118,   119,   120,     0,     0,
       0,     0,     0,   124,   125,   126,   127,   128,   129,     0,
       0,    67,   517,    69,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,     0,     0,   667,
       0,     0,   133,   134,   135,   136,   137,   138,   516,     0,
       0,     0,     0,     0,     0,     0,     0,   241,   242,   243,
     145,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   146,   244,     0,     0,     0,   240,   245,  1439,
       0,   246,   221,   222,   223,     5,     0,   224,   225,     8,
     226,   227,   228,   229,   230,   231,   232,     0,     0,     0,
       0,     0,     0,    94,    95,    96,     0,     0,     0,     0,
       0,     0,     0,     0,    24,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   103,     0,     0,     0,     0,
       0,     0,     0,   284,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   115,
     116,   117,   118,   119,   120,     0,     0,     0,     0,     0,
     124,   125,   126,   127,   128,   129,     0,   517,     0,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,     0,     0,   667,     0,     0,     0,  1582,   133,
     134,   135,   136,   137,   138,    49,    50,     0,     0,     0,
       0,     0,     0,     0,   241,   242,   243,   145,     0,     0,
       0,     0,    54,    55,     0,     0,     0,    56,     0,   146,
     244,     0,     0,     0,     0,   245,     0,     0,   246,   221,
     222,   223,     5,     0,   224,   225,     8,   226,   227,   228,
     229,   230,   231,   232,     0,     0,     0,     0,    67,     0,
      69,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     517,    24,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,     0,   667,     0,     0,
       0,  1583,     0,     0,   516,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   517,   240,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,   664,   665,   666,     0,     0,
     667,     0,     0,     0,  1584,     0,     0,   516,     0,     0,
      94,    95,    96,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    49,    50,     0,     0,     0,     0,     0,     0,
       0,     0,   103,     0,     0,     0,     0,     0,     0,    54,
      55,     0,     0,     0,    56,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   115,   116,   117,   118,
     119,   120,     0,     0,     0,     0,     0,   124,   125,   126,
     127,   128,   129,     0,     0,    67,     0,    69,   517,     0,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,  1165,     0,     0,   667,   133,   134,   135,   136,
     137,   138,   516,     0,     0,     0,     0,     0,     0,     0,
       0,   241,   242,   243,   145,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   146,   244,     0,     0,
       0,   240,   245,     0,     0,   246,   221,   222,   223,     5,
       0,   224,   225,     8,   226,   227,   228,   229,   230,   231,
     232,     0,     0,     0,     0,     0,     0,    94,    95,    96,
       0,     0,     0,     0,     0,     0,     0,     0,    24,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   103,
       0,     0,     0,     0,     0,     0,     0,   597,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   115,   116,   117,   118,   119,   120,     0,
       0,   442,     0,     0,   124,   125,   126,   127,   128,   129,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   133,   134,   135,   136,   137,   138,    49,
      50,     0,     0,     0,     0,     0,     0,     0,   241,   242,
     243,   145,     0,     0,     0,     0,    54,    55,     0,     0,
       0,    56,     0,   146,   244,     0,     0,     0,     0,   245,
       0,     0,   246,   221,   222,   223,     5,     0,   224,   225,
       8,   226,   227,   228,   229,   230,   231,   232,     0,     0,
       0,     0,    67,     0,    69,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   517,    24,   654,   655,   656,   657,
     658,   659,   660,   661,   662,   663,   664,   665,   666,     0,
       0,   667,     0,     0,   627,  1598,     0,     0,   516,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   517,   240,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,     0,     0,   667,     0,     0,     0,  1599,     0,
       0,   516,     0,     0,    94,    95,    96,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    49,    50,     0,     0,
       0,     0,     0,     0,     0,     0,   103,     0,     0,     0,
       0,     0,     0,    54,    55,     0,     0,     0,    56,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     115,   116,   117,   118,   119,   120,     0,     0,     0,     0,
       0,   124,   125,   126,   127,   128,   129,     0,     0,    67,
       0,    69,   517,     0,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,  1167,     0,     0,   667,
     133,   134,   135,   136,   137,   138,   516,     0,     0,     0,
       0,     0,     0,     0,     0,   241,   242,   243,   145,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     146,   244,     0,     0,     0,   240,   245,     0,     0,   246,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,     0,     0,     0,     0,
       0,    94,    95,    96,     0,     0,     0,     0,     0,     0,
       0,     0,    24,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   103,     0,     0,     0,     0,     0,     0,
       0,   700,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   115,   116,   117,
     118,   119,   120,     0,     0,     0,     0,     0,   124,   125,
     126,   127,   128,   129,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   133,   134,   135,
     136,   137,   138,    49,    50,     0,     0,     0,     0,     0,
       0,     0,   241,   242,   243,   145,     0,     0,     0,     0,
      54,    55,     0,     0,     0,    56,     0,   146,   244,     0,
       0,     0,     0,   245,     0,     0,   628,   221,   222,   223,
       5,     0,   224,   225,     8,   226,   227,   228,   229,   230,
     231,   232,     0,     0,     0,     0,    67,     0,    69,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   517,    24,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,     0,   667,     0,     0,   672,  1600,
       0,     0,     0,     0,   516,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   517,   240,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
       0,     0,  1615,     0,     0,   516,     0,     0,    94,    95,
      96,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      49,    50,     0,     0,     0,     0,     0,     0,     0,     0,
     103,     0,     0,     0,     0,     0,     0,    54,    55,     0,
       0,     0,    56,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
       0,     0,     0,     0,     0,   124,   125,   126,   127,   128,
     129,     0,     0,    67,     0,    69,-32768,     0,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,   133,   134,   135,   136,   137,   138,
     516,     0,     0,     0,     0,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   146,   244,     0,     0,     0,   240,
     245,     0,     0,   246,   221,   222,   223,     5,     0,   224,
     225,     8,   226,   227,   228,   229,   230,   231,   232,     0,
       0,     0,     0,     0,     0,    94,    95,    96,     0,     0,
       0,     0,     0,     0,     0,     0,    24,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   103,     0,     0,
       0,     0,     0,     0,     0,   766,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   115,   116,   117,   118,   119,   120,   535,     0,     0,
       0,     0,   124,   125,   126,   127,   128,   129,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   133,   134,   135,   136,   137,   138,    49,    50,     0,
       0,     0,     0,     0,     0,     0,   241,   242,   243,   145,
       0,     0,     0,     0,    54,    55,     0,     0,     0,    56,
       0,   146,   244,     0,     0,     0,     0,   245,     0,     0,
     246,     0,     0,   221,   222,   223,     5,     0,   224,   225,
       8,   226,   227,   228,   229,   230,   231,   232,     0,     0,
      67,     0,    69,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   517,    24,   654,   655,   656,   657,
     658,   659,   660,   661,   662,   663,   664,   665,   666,     0,
       0,   667,     0,     0,     0,  1616,     0,     0,   516,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   517,   240,   654,   655,   656,
     657,   658,   659,   660,   661,   662,   663,   664,   665,   666,
       0,     0,   667,     0,     0,     0,  1626,     0,     0,     0,
       0,   516,    94,    95,    96,     0,   361,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    49,    50,     0,     0,
       0,     0,     0,     0,   103,     0,     0,     0,     0,     0,
       0,     0,     0,    54,    55,     0,     0,     0,    56,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   115,   116,
     117,   118,   119,   120,     0,     0,     0,     0,     0,   124,
     125,   126,   127,   128,   129,     0,     0,     0,     0,    67,
  -32768,    69,   518,   519,   520,   521,   522,   523,   524,   525,
     526,   527,   528,   529,   530,     0,     0,   531,   133,   134,
     135,   136,   137,   138,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   241,   242,   243,   145,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   146,   244,
       0,     0,     0,     0,   245,   240,     0,   246,     0,     0,
     221,   222,   223,     5,     0,   224,   225,     8,   226,   227,
     228,   229,   230,   231,   232,     0,     0,     0,     0,     0,
       0,    94,    95,    96,     0,     0,     0,     0,     0,     0,
       0,     0,    24,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   103,     0,     0,     0,-32768,     0,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,     0,     0,   550,     0,   516,   115,   116,   117,
     118,   119,   120,     0,     0,     0,     0,     0,   124,   125,
     126,   127,   128,   129,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   133,   134,   135,
     136,   137,   138,    49,    50,     0,     0,     0,     0,     0,
       0,     0,   241,   242,   243,   145,     0,     0,     0,     0,
      54,    55,     0,     0,     0,    56,     0,   146,   244,     0,
       0,     0,     0,   245,     0,     0,   246,   221,   222,   223,
       5,     0,   224,   225,     8,   226,   227,   228,   229,   230,
     231,   232,     0,     0,     0,     0,    67,     0,    69,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   517,    24,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
     664,   665,   666,     0,     0,   667,     0,     0,     0,  1632,
       0,     0,   516,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   517,   240,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
       0,     0,  1638,     0,     0,   516,     0,     0,    94,    95,
      96,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      49,    50,     0,     0,     0,     0,     0,     0,     0,     0,
     103,     0,     0,     0,     0,     0,     0,    54,    55,     0,
       0,     0,    56,     0,  1301,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   115,   116,   117,   118,   119,   120,
       0,     0,     0,     0,     0,   124,   125,   126,   127,   128,
     129,     0,     0,    67,     0,    69,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   133,   134,   135,   136,   137,   138,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   241,
     242,   243,   145,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   146,   244,     0,     0,     0,   240,
     245,     0,     0,   246,   221,   222,   223,     5,     0,   224,
     225,     8,   226,   227,   228,   229,   230,   231,   232,     0,
       0,     0,     0,     0,     0,    94,    95,    96,     0,     0,
       0,     0,     0,     0,     0,     0,    24,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   517,   103,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,  1303,     0,   667,     0,     0,     0,  1646,     0,     0,
     535,   115,   116,   117,   118,   119,   120,     0,     0,     0,
       0,     0,   124,   125,   126,   127,   128,   129,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   133,   134,   135,   136,   137,   138,    49,    50,     0,
       0,     0,     0,     0,     0,     0,   241,   242,   243,   145,
       0,     0,     0,     0,    54,    55,     0,     0,     0,    56,
       0,   146,   244,     0,     0,     0,     0,   245,     0,     0,
     246,   221,   222,   223,     5,     0,   224,   225,     8,   226,
     227,   228,   229,   230,   231,   232,     0,     0,     0,     0,
      67,     0,    69,   516,     0,     0,     0,     0,     0,     0,
       0,     0,   517,    24,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,   535,     0,   667,
       0,     0,     0,  1650,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   535,     0,     0,     0,
       0,     0,     0,     0,     0,   517,   240,   518,   519,   520,
     521,   522,   523,   524,   525,   526,   527,   528,   529,   530,
       0,     0,   531,     0,     0,  1084,     0,     0,     0,   516,
       0,     0,    94,    95,    96,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    49,    50,     0,     0,     0,     0,
       0,     0,     0,     0,   103,     0,     0,     0,     0,   516,
       0,    54,    55,     0,     0,     0,    56,     0,  1334,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   115,   116,
     117,   118,   119,   120,     0,     0,     0,     0,     0,   124,
     125,   126,   127,   128,   129,     0,     0,    67,     0,    69,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   133,   134,
     135,   136,   137,   138,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   241,   242,   243,   145,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   146,   244,
       0,     0,     0,   240,   245,     0,     0,   246,   221,   222,
     223,     5,     0,   224,   225,     8,   226,   227,   228,   229,
     230,   231,   232,     0,     0,     0,     0,     0,     0,    94,
      95,    96,   535,     0,     0,     0,     0,     0,     0,     0,
      24,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     536,   103,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   516,     0,   550,     0,     0,
    1085,     0,     0,     0,     0,   115,   116,   117,   118,   119,
     120,     0,     0,     0,   535,     0,   124,   125,   126,   127,
     128,   129,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   516,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   133,   134,   135,   136,   137,
     138,    49,    50,     0,   535,     0,     0,     0,     0,     0,
     241,   242,   243,   145,     0,     0,     0,     0,    54,    55,
       0,     0,     0,    56,     0,   146,   244,   535,     0,     0,
       0,   245,     0,   517,   246,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,   664,   665,   666,   535,     0,
     667,     0,     0,   834,    67,     0,    69,   536,     0,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,   516,     0,   550,     0,   536,  1181,   537,   538,
     539,   540,   541,   542,   543,   544,   545,   546,   547,   548,
     549,   516,     0,   550,     0,     0,  1342,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   517,
     240,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,   516,     0,   667,     0,     0,  1084,
       0,     0,     0,     0,     0,     0,    94,    95,    96,   517,
       0,   518,   519,   520,   521,   522,   523,   524,   525,   526,
     527,   528,   529,   530,   535,     0,   531,     0,   103,  1444,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   516,     0,     0,     0,     0,     0,     0,
       0,     0,   115,   116,   117,   118,   119,   120,     0,     0,
       0,     0,   535,   124,   125,   126,   127,   128,   129,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   516,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   133,   134,   135,   136,   137,   138,     0,     0,
     516,     0,     0,     0,     0,     0,     0,   241,   242,   243,
     752,     0,     0,     0,     0,     0,     0,     0,     0,   516,
       0,     0,   146,   244,     0,     0,     0,     0,   245,     0,
       0,   246,   536,     0,   537,   538,   539,   540,   541,   542,
     543,   544,   545,   546,   547,   548,   549,   535,     0,   550,
       0,     0,  1445,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   517,   516,   518,   519,   520,
     521,   522,   523,   524,   525,   526,   527,   528,   529,   530,
       0,     0,   531,     0,   536,  1446,   537,   538,   539,   540,
     541,   542,   543,   544,   545,   546,   547,   548,   549,   516,
       0,   550,     0,   517,  1447,   518,   519,   520,   521,   522,
     523,   524,   525,   526,   527,   528,   529,   530,   535,     0,
     531,     0,     0,  1448,   536,     0,   537,   538,   539,   540,
     541,   542,   543,   544,   545,   546,   547,   548,   549,   516,
       0,   550,     0,     0,  1449,     0,     0,   536,     0,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,   516,     0,   550,     0,     0,  1469,   536,     0,
     537,   538,   539,   540,   541,   542,   543,   544,   545,   546,
     547,   548,   549,   516,     0,   550,     0,     0,  1481,     0,
       0,     0,   517,     0,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,   535,     0,   667,
       0,   517,  1444,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,   516,     0,   667,     0,
       0,  1446,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   517,     0,   518,   519,   520,   521,
     522,   523,   524,   525,   526,   527,   528,   529,   530,     0,
       0,   531,     0,     0,  1545,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   536,     0,   537,   538,   539,   540,
     541,   542,   543,   544,   545,   546,   547,   548,   549,     0,
       0,   550,     0,   517,  1546,   518,   519,   520,   521,   522,
     523,   524,   525,   526,   527,   528,   529,   530,     0,     0,
     531,     0,   536,  1547,   537,   538,   539,   540,   541,   542,
     543,   544,   545,   546,   547,   548,   549,     0,     0,   550,
       0,   517,  1548,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,   664,   665,   666,     0,     0,   667,     0,
     517,  1545,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,   664,   665,   666,     0,     0,   667,     0,   517,
    1547,   518,   519,   520,   521,   522,   523,   524,   525,   526,
     527,   528,   529,   530,     0,     0,   531,     0,     0,  1596,
       0,     0,     0,     0,     0,     0,     0,   536,     0,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,     0,     0,   550,     0,   517,  1597,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,     0,     0,   667,     0,     0,  1596,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   517,
       0,   518,   519,   520,   521,   522,   523,   524,   525,   526,
     527,   528,   529,   530,     0,     0,   531,     0,   536,  1624,
     537,   538,   539,   540,   541,   542,   543,   544,   545,   546,
     547,   548,   549,     0,     0,   550,     0,     0,  1625,   517,
       0,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,   664,   665,   666,     0,     0,   667,     0,     0,  1624,
       0,     0,   517,     0,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,     0,     0,   667,
       0,     0,  1641,   517,     0,   518,   519,   520,   521,   522,
     523,   524,   525,   526,   527,   528,   529,   530,     0,     0,
     531,     0,     0,  1642,     0,     0,     0,   536,     0,   537,
     538,   539,   540,   541,   542,   543,   544,   545,   546,   547,
     548,   549,     0,     0,   550,     0,   517,  1643,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,   664,   665,
     666,   562,     0,   667,     0,     0,  1642,   563,   562,     0,
       0,     0,     0,     0,   563,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   199,   564,     0,
       0,     0,     0,     0,   199,   564,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   565,   566,     0,     0,
       0,   567,     0,   565,   566,     0,   568,     0,   567,     0,
       0,     0,     0,   568,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   307,   308,   309,   310,   311,   312,
       0,     0,   569,   313,   314,   315,   316,   317,   318,   569,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   319,     0,     0,   320,     0,     0,   570,   571,   572,
       0,   235,   236,   573,   570,   571,   572,     0,   235,   236,
     573,     0,   321,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   322,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   238,     0,
       0,     0,     0,   239,     0,   238,     0,     0,     0,     0,
     239,     0,     0,     0,     0,     0,     0,     0,     0,   574,
       0,     0,     0,     0,     0,     0,   574,     0,     0,     0,
       0,   323,   324,   325,   326,   327,   328,   329,   330,   331,
     332,   333,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   575,     0,     0,     0,     0,     0,
       0,   575,     0,     0,     0,     0,   334,     0,     0,     0,
       0,     0,     0,   576,     0,     0,     0,     0,     0,     0,
     576,     0,     0,     0,   577,     0,     0,     0,     0,     0,
       0,   577,     0,     0,     0,     0,     0,   335,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   578,     0,     0,     0,     0,     0,     0,
     578,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   579,     0,     0,     0,
       0,     0,     0,  1210,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   336,   337
};

static const short yycheck[] =
{
       0,   288,   165,    49,   579,    80,    78,    19,    20,   176,
     912,    66,   179,    33,   181,   182,    46,   184,    62,   147,
      17,    25,   321,    27,    75,    75,    69,    27,   124,    33,
      45,    69,   166,    46,    62,   110,    40,    75,    58,    39,
      40,    46,    75,    47,    75,   206,   948,   397,    46,    95,
     211,    27,    64,    60,    40,    46,    74,    33,    62,    63,
     206,    75,    62,    63,    40,   211,   157,   101,    47,    62,
     144,    47,   206,    75,   102,   180,   104,   211,   373,   122,
     108,   109,   210,   121,    41,    97,    62,    63,    44,   113,
      52,    22,   391,   391,   103,   107,   166,    97,   102,   123,
     104,   396,   102,   216,   108,   109,    68,   153,   108,   164,
      67,    75,   121,   391,   114,   220,   391,   167,    75,   169,
     170,    51,   122,   143,   289,   145,  1028,   134,   135,   296,
     127,   157,   170,   246,   167,   147,   169,   170,   234,   202,
      96,   141,   394,   395,   164,    75,   146,   147,   148,   149,
      69,    62,    63,   168,   116,   167,   206,    34,   202,   391,
     217,   211,   166,   181,   121,   222,   123,   169,   170,   220,
     391,   202,   263,   206,    62,   137,   176,   177,   211,   179,
     180,   348,   101,   183,   114,   185,   186,   187,   188,   220,
     166,   225,   206,   131,   132,   202,   251,   211,   210,   360,
      69,   366,   298,   277,   213,   223,   220,   216,   101,   229,
     230,   204,   219,    69,   379,   177,   178,   179,   220,    75,
     206,   214,    27,   319,   221,   211,    59,   391,    33,    62,
     234,   251,   101,   271,   308,    40,   236,   263,   202,   169,
     170,    69,    47,   371,   244,   245,   246,   277,   123,   206,
     207,   295,   302,   164,   211,   234,   220,    62,    63,    22,
      69,   254,   224,   278,   277,   121,   228,   330,   280,   302,
      98,    76,   277,   336,   212,   287,   206,   234,   235,   277,
     391,   211,   447,   391,   288,   335,   277,   307,     0,   309,
     220,   116,   101,    75,   301,   358,   253,   102,   298,   104,
     302,   126,   335,   108,   109,   319,   225,    19,   146,   288,
      22,   318,   274,   206,   170,    27,   204,  1219,   211,    31,
     282,   283,   391,   200,   393,   397,   214,   204,    40,   267,
     268,   206,   225,    45,   244,   339,   211,   162,    22,   121,
     251,   391,   327,   206,   417,   302,   419,   420,   211,    61,
     350,    63,   391,   353,   391,   359,   225,    75,    70,   234,
     339,   166,   131,   132,   364,    69,   533,   352,   311,   369,
     370,   204,   302,   335,    86,   391,    75,   320,   211,    69,
     359,   214,   585,   359,   587,   588,    98,    22,   100,   300,
     102,   391,   330,   105,   106,    69,   131,   132,   398,   394,
     395,    69,   397,   391,   404,   175,   176,   232,   391,   121,
      69,   123,   412,   394,   395,   271,   225,   267,   268,    98,
     358,   421,   422,   395,   424,   131,   132,   302,   595,   267,
     268,   392,   393,   433,   204,    71,    69,   392,   393,   302,
     391,   372,   442,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,   456,   391,   389,   391,
     335,   392,   393,   391,   631,    69,   633,    22,   635,   391,
     169,   170,   472,   243,   312,   313,   128,   315,   316,   479,
     480,   481,   482,   391,   120,   323,   324,   325,   326,   299,
     490,   491,   492,   493,   170,   131,   132,    69,   267,   268,
     573,   391,   577,   503,   504,   505,    18,   206,   384,   385,
     386,   246,   211,   389,   397,    69,    69,   517,   518,   519,
     520,   521,   522,   523,   524,   525,   526,   527,   528,   529,
     530,   531,   267,   268,   562,   397,   536,   537,   538,   539,
     540,   541,   542,   543,   544,   545,   546,   547,   548,   549,
     550,   551,   587,   588,   359,   391,   391,   585,   562,   587,
     384,   385,   386,   567,   568,   389,   397,   390,   572,   391,
     206,   283,   576,   391,   574,   211,   391,   391,   578,   391,
     584,   585,    69,   587,   588,     0,   586,   394,   567,   568,
     299,   567,    69,   572,   594,   391,   572,   576,   391,   391,
     576,   391,   391,   391,   391,    52,    53,    54,   584,   372,
     391,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,   391,   391,   389,   299,   628,   394,
     393,   267,   632,   394,   634,  1210,   636,   637,   638,   639,
     352,   271,   354,   355,   384,   385,   386,    69,   271,   389,
     395,    69,    69,    69,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,   664,   665,   666,   667,   668,   262,
     271,   671,    72,   673,   299,   299,    69,   677,   114,    69,
     680,   844,   394,   271,    69,   271,   375,    69,   975,   689,
     302,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,   389,   708,   389,    52,   389,   391,   389,
     166,    22,   397,   425,   714,   302,   139,    69,   430,   431,
      69,   365,   392,   392,   724,   725,   726,   727,   393,   708,
      67,   731,   147,   148,   149,   393,   393,   372,    75,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   393,   393,   389,    69,   756,   757,   393,   393,
     271,   392,   567,   218,   179,   180,   393,   572,   183,   169,
     170,   576,   392,    69,   396,   393,    75,   299,   299,   584,
     585,   392,   587,   588,   121,   393,   498,   393,   370,    69,
     393,   791,   392,    69,    69,   392,   796,   843,   393,   799,
      69,   393,   802,   515,    69,   321,   206,    69,   393,   809,
     271,   211,    69,   393,    69,   161,    69,   372,   818,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   169,   170,   389,    69,   271,   271,   393,    27,
      69,   845,   393,   370,   370,   393,    22,   393,   393,   393,
     393,   393,    40,    69,   391,   396,    69,    45,  1145,    47,
     206,   207,   128,   123,   295,   211,   295,   166,    69,   845,
     169,   170,   392,    64,    62,    63,    22,   877,   393,   393,
     592,   593,   392,   220,   393,   393,   393,   393,   335,   935,
     337,   338,   339,   340,   341,   342,   343,   344,   345,   346,
     347,   348,   349,   350,   351,    75,   392,   206,   620,   393,
     392,   911,   211,   913,   102,   915,   107,    69,    69,  1086,
     108,   220,   393,  1090,   396,   392,   392,   226,   393,   393,
      22,   393,   269,   393,    69,    35,   393,    69,   353,   393,
     131,   132,   392,   392,   114,   393,   392,   293,   294,   949,
     393,   392,   392,   252,   291,   393,   302,    69,   670,     0,
     393,   393,   962,   393,   992,   965,   392,   392,   392,     0,
     560,   392,   271,    22,   393,   515,   167,   165,   166,   393,
     168,   393,   392,    34,    -1,    -1,  1015,   175,   964,   993,
      -1,    -1,    -1,    22,   994,   500,    -1,    -1,    -1,   169,
     170,    -1,   190,   302,    -1,    -1,   194,    -1,    -1,    -1,
     146,    -1,    -1,    -1,   993,    -1,  1016,    -1,   433,    -1,
      -1,   733,    -1,    -1,    -1,    -1,   738,    -1,  1028,    -1,
     166,  1031,    -1,    -1,    -1,    -1,   206,    -1,  1038,  1039,
     845,   211,    -1,    -1,    -1,  1212,    -1,    -1,    -1,    -1,
     220,  1055,    -1,    -1,  1058,  1055,    -1,    -1,  1058,  1059,
    1060,    -1,    -1,  1063,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,   267,   268,   389,  1055,
      -1,    22,  1058,    -1,    -1,    -1,   798,  1087,  1088,  1089,
      -1,  1091,  1092,  1093,  1094,    -1,   287,    -1,    -1,    -1,
     515,    -1,    -1,   518,   519,   520,   521,   522,   523,   524,
     525,   526,   527,   528,   529,   530,   531,    -1,    -1,    -1,
      -1,   536,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   550,   551,    -1,    -1,    -1,
      -1,  1141,  1142,    -1,  1144,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   340,    -1,    -1,    -1,    -1,    -1,    -1,   964,
    1160,    -1,    -1,  1163,    -1,  1165,    -1,  1167,    -1,    -1,
      -1,   359,    -1,    -1,    -1,   363,  1176,  1177,    -1,   594,
    1180,    22,    -1,    -1,    -1,  1185,    -1,    -1,    -1,    -1,
      -1,   327,   328,  1360,    -1,    -1,    -1,    -1,   386,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,  1211,    -1,   389,  1214,  1215,   352,   353,   354,   355,
     356,   357,    -1,    -1,    -1,  1225,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,   327,   328,    -1,   393,    -1,    -1,
    1055,    -1,    -1,  1058,    -1,    -1,    -1,  1257,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1266,  1267,    -1,   352,
     353,   354,   355,   356,   357,    -1,    -1,    -1,  1278,    -1,
     372,  1281,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,
      -1,   393,    -1,    -1,    -1,    -1,    -1,    -1,   496,    -1,
      -1,   499,  1312,    -1,   502,    -1,    -1,    -1,    -1,    -1,
      -1,    22,  1322,   372,    -1,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,  1338,    -1,
     389,    -1,    -1,    -1,   393,    22,    -1,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,  1358,  1359,
     389,  1361,  1362,  1363,  1364,  1365,   554,   555,   556,   557,
      -1,  1371,   560,    -1,   562,   563,  1376,  1377,   566,   567,
      -1,   569,    -1,    -1,    -1,   573,    -1,    -1,    -1,    -1,
      -1,    -1,  1392,  1393,    -1,    -1,   584,    37,    38,   587,
     588,    -1,    -1,  1403,  1404,    -1,  1406,    47,  1408,    -1,
      -1,    -1,    52,  1413,    -1,    -1,  1416,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1426,    -1,    -1,    -1,
    1430,   372,   373,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
    1450,  1451,  1452,  1453,  1454,  1455,    -1,    -1,    -1,    -1,
      -1,    -1,    67,    -1,    69,    -1,    -1,    -1,    -1,    73,
      75,    -1,    -1,    -1,    -1,    -1,    -1,   117,  1478,    -1,
      -1,    -1,  1482,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   681,    -1,    -1,  1208,   101,    -1,    -1,
     140,    -1,    -1,   107,    -1,    -1,    -1,    -1,    -1,   113,
    1510,  1511,  1512,  1513,  1514,  1515,   121,  1517,    -1,    -1,
     708,   161,    -1,  1523,    -1,    -1,    -1,   147,   148,   149,
      -1,    -1,  1532,  1533,    -1,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,  1549,
    1550,  1551,  1552,   741,   159,    -1,    -1,    -1,   163,   179,
     180,    -1,    -1,   183,    -1,   170,   206,  1567,    -1,  1569,
      -1,   211,    -1,    -1,   178,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1582,  1583,  1584,    -1,    -1,    -1,    -1,   193,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1598,  1599,
    1600,    -1,    -1,    -1,    -1,    -1,    -1,  1607,   213,    -1,
      -1,    -1,    -1,    -1,    -1,  1615,  1616,    -1,    -1,    -1,
      -1,   226,    -1,  1623,    -1,    -1,  1626,    -1,    -1,    -1,
      -1,   235,  1632,    -1,    -1,    -1,    -1,    -1,  1638,    -1,
      -1,   281,    -1,    -1,    -1,    -1,  1646,    -1,    -1,    -1,
    1650,    -1,    -1,    -1,    -1,    -1,   844,   845,    22,    -1,
      -1,    -1,   302,    -1,    -1,    -1,   270,   271,    -1,    -1,
      -1,    -1,  1087,  1088,  1089,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
      -1,   331,    -1,    -1,    -1,   372,   300,   374,   375,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
      -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,   359,
      -1,    -1,    -1,    -1,    -1,    -1,  1141,  1142,    -1,  1144,
      -1,    -1,    -1,   353,    -1,    -1,    -1,   341,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1163,    -1,
      -1,    -1,    -1,    -1,   394,    -1,    -1,   361,   362,    -1,
      -1,   365,    -1,   367,   368,  1180,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   377,    -1,    -1,   964,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   389,   390,   391,    -1,    -1,
      -1,    -1,    -1,    -1,   398,    -1,    -1,    -1,   402,  1214,
    1215,   405,    -1,   991,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   415,    -1,   433,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,    -1,   441,    -1,    -1,
      -1,    -1,   446,    -1,   448,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,   465,  1050,    -1,    -1,    -1,  1054,  1055,    -1,    -1,
    1058,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     484,   485,   486,   487,    22,    -1,    -1,  1075,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   518,   519,
     520,   521,   522,   523,   524,   525,   526,   527,   528,   529,
     530,   531,    22,    -1,    -1,    -1,   536,   537,   538,   539,
     540,   541,   542,   543,   544,   545,   546,   547,   548,   549,
     550,   551,    -1,   131,   132,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1132,    -1,    -1,    -1,    -1,    -1,
     148,   149,    -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,
      -1,   565,    -1,    -1,   568,    -1,    -1,   571,    -1,    -1,
      -1,   575,   576,    -1,   594,    -1,    -1,    -1,     0,    -1,
      -1,    -1,    -1,   587,   588,    -1,   184,    -1,   186,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,    -1,    -1,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,    31,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,   628,   389,    -1,    -1,    -1,   393,
      -1,    -1,    -1,    -1,    -1,  1450,  1451,    -1,   642,    61,
      -1,    -1,   240,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,  1239,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    86,    -1,    -1,    -1,   266,   267,
     268,    -1,    -1,    -1,   678,    -1,    98,    -1,   100,    -1,
      -1,    -1,    -1,   105,   106,    -1,    -1,    -1,    -1,    -1,
     288,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   121,
      -1,   123,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      -1,    -1,    -1,  1311,   728,   323,   324,   325,   326,   327,
     328,    -1,    -1,  1321,  1549,    -1,    -1,    -1,    -1,    -1,
      22,    -1,    -1,    -1,  1332,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1598,   382,   383,    -1,    -1,    -1,    -1,
     388,    -1,    -1,   391,    -1,    -1,    -1,    -1,   396,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     372,  1626,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    22,    -1,   389,    -1,    -1,
      -1,   393,    -1,    -1,   372,    -1,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,    -1,    -1,   393,    -1,    -1,    -1,    -1,
      -1,   283,   372,    22,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
    1468,    -1,    -1,   393,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1480,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,
     914,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,
     352,    -1,   354,   355,    -1,    -1,    -1,    -1,    50,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   950,    -1,   952,   953,
      22,    -1,    -1,   957,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    75,    -1,    -1,    -1,    -1,    -1,   973,
     974,    -1,   394,  1561,  1562,    -1,    -1,    -1,   982,    -1,
      -1,    -1,    -1,    -1,    -1,  1573,    -1,    -1,   992,   993,
      -1,   995,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,   425,    -1,    -1,    -1,    -1,   430,   431,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   131,
     132,  1025,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1033,
      -1,    -1,  1036,  1037,    -1,    -1,   148,   149,    -1,    -1,
    1628,   153,    -1,    -1,    -1,    -1,    -1,    -1,  1052,    -1,
      -1,  1055,    -1,    -1,  1058,    -1,  1644,    -1,    -1,    -1,
    1064,  1649,    -1,    -1,    -1,    -1,  1654,  1087,  1088,  1089,
      -1,    -1,   184,    -1,   186,    -1,   498,  1081,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1096,   515,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,   220,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1141,  1142,    -1,  1144,    -1,    -1,    -1,   240,    -1,
      -1,  1135,  1136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1163,   256,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   266,   267,   268,    -1,    -1,  1163,
    1180,    -1,  1166,    -1,    -1,  1169,    -1,    -1,    -1,    -1,
     592,   593,    -1,    -1,    -1,  1179,   288,    -1,    -1,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
     302,    -1,   389,    -1,  1214,  1215,    -1,    -1,   620,    -1,
     312,   313,   314,   315,   316,   317,    -1,   319,    -1,    -1,
      -1,   323,   324,   325,   326,   327,   328,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,  1233,
     389,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     352,   353,   354,   355,   356,   357,    -1,    -1,   670,    -1,
      -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     382,   383,    -1,    -1,    -1,    -1,   388,    -1,   372,   391,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,
     372,    -1,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,   738,   389,    -1,  1323,
      -1,   393,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1340,  1341,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   372,  1357,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,    -1,    -1,   393,  1378,    -1,   798,    -1,     0,     1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,
      -1,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    -1,    -1,    35,    -1,    37,    38,    -1,    -1,    41,
      42,    -1,    -1,    -1,    46,    47,    48,    -1,    50,    51,
    1450,  1451,    -1,    -1,    -1,    -1,    -1,    -1,  1442,    61,
      -1,    -1,    64,    65,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    79,    80,    -1,
      -1,  1465,    -1,    -1,    -1,    -1,    88,    89,    -1,    -1,
      -1,  1475,    -1,  1477,    -1,    97,    98,    99,   100,    -1,
      -1,    -1,    -1,  1487,   106,   107,    -1,    -1,   110,    -1,
     112,    -1,    -1,   115,    -1,    -1,   118,   119,    -1,    -1,
      -1,   123,    -1,   125,    -1,  1509,    -1,    -1,   130,   131,
     132,    -1,    -1,    -1,   136,    -1,   138,    -1,    -1,   141,
    1524,    -1,    -1,    -1,    -1,    -1,   148,   149,    -1,  1549,
      -1,   153,   154,   155,   156,    -1,   158,    -1,   160,    -1,
    1544,    -1,    -1,   165,    -1,   167,    -1,    -1,    -1,   171,
     172,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   183,   184,   185,   186,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   199,  1598,   201,
      -1,   203,    -1,  1587,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1595,    -1,    -1,   216,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1626,    -1,    -1,   231,
      -1,    -1,    -1,    -1,   236,   237,   238,   239,   240,   241,
      -1,    -1,   244,   245,   246,   247,    -1,   249,   250,    -1,
      -1,    -1,    -1,   255,    -1,   257,   258,   259,   260,   261,
     262,    -1,    -1,    -1,   266,   267,   268,    -1,    -1,    -1,
      -1,   273,    -1,   275,   276,    -1,    -1,   279,   280,    -1,
      -1,    -1,    -1,    -1,    -1,   287,   288,   289,   290,    -1,
     292,    -1,    -1,    -1,   296,   297,   298,    -1,    -1,    -1,
     302,    -1,   304,   305,   306,    -1,    -1,    -1,    -1,   311,
     312,   313,   314,   315,   316,   317,    -1,   319,   320,    -1,
     322,   323,   324,   325,   326,   327,   328,    -1,   330,   331,
     332,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     352,   353,   354,   355,   356,   357,   358,   359,    -1,    -1,
      -1,    -1,    -1,    -1,   366,   367,   368,   369,   370,    -1,
      -1,    -1,     0,     1,    -1,    -1,    -1,    -1,    -1,    -1,
     382,   383,    -1,    -1,    -1,    -1,   388,    -1,   390,   391,
      18,    19,    20,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1208,    35,    -1,    37,
      38,    -1,    -1,    41,    42,    -1,    -1,    -1,    46,    47,
      48,    -1,    -1,    51,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    61,    -1,    -1,    64,    65,    -1,    -1,
      -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      22,    79,    80,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      88,    89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    97,
      98,    99,   100,    -1,    -1,    -1,    -1,    -1,   106,   107,
      -1,    -1,   110,    -1,   112,    -1,    -1,   115,    -1,    22,
     118,   119,    -1,    -1,    -1,   123,    -1,   125,    -1,    -1,
      -1,    -1,   130,   131,   132,    -1,    -1,    -1,   136,    -1,
     138,    -1,    -1,   141,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   154,   155,   156,    -1,
     158,    -1,   160,    -1,    -1,    -1,    22,   165,    -1,   167,
      -1,    -1,    -1,   171,   172,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   183,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   199,    -1,   201,    -1,   203,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   216,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   231,    -1,    -1,    -1,    -1,   236,   237,
     238,   239,    -1,   241,    -1,    -1,   244,   245,   246,   247,
      -1,   249,   250,    -1,    -1,    -1,    -1,    -1,    -1,   257,
     258,   259,   260,   261,   262,    -1,    -1,    -1,    -1,   267,
     268,    -1,    -1,    -1,    -1,   273,    -1,   275,   276,    -1,
      -1,   279,   280,    -1,    -1,    -1,    -1,    -1,    -1,   287,
      -1,   289,   290,    -1,   292,    -1,    -1,    22,   296,   297,
     298,    -1,    -1,    -1,   302,    -1,   304,   305,   306,    -1,
      -1,    -1,    -1,   311,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   319,   320,    -1,   322,    -1,    -1,    -1,    -1,   327,
     328,    -1,   330,   331,   332,    18,    19,    20,    21,    -1,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
     358,   359,    -1,    -1,    -1,    -1,    -1,    50,   366,   367,
     368,   369,    -1,   372,    -1,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,    -1,
     389,    -1,   390,    -1,   393,    -1,    -1,    -1,    81,    82,
      83,    84,    85,    86,    -1,    -1,    22,    90,    91,    92,
      93,    94,    95,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   108,    -1,    -1,   111,    -1,
     372,    -1,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,   129,   389,   131,   132,
      -1,   393,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   142,
      22,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,   372,
     153,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,
     393,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   184,    -1,   186,    -1,   188,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     233,    -1,    -1,    -1,    -1,    -1,   372,   240,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      -1,   264,    -1,   266,   267,   268,    -1,    -1,    -1,    18,
      19,    20,    21,    -1,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    -1,   288,    -1,    -1,    -1,    -1,
      39,    -1,    41,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      -1,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,
     313,   314,   315,   316,   317,    -1,    -1,    -1,    67,    22,
     323,   324,   325,   326,   327,   328,    75,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,   352,
     353,   354,   355,   356,   357,    -1,    -1,    -1,    -1,    -1,
     363,   364,    -1,    -1,   367,   368,   369,   370,    -1,    -1,
      -1,    -1,   121,    -1,   123,   124,    -1,    -1,    -1,   382,
     383,    -1,   131,   132,    -1,   388,    -1,    -1,   391,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,
     149,    -1,    22,    -1,   153,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   163,    -1,    -1,    -1,    -1,    -1,
      -1,   170,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   184,   372,   186,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    22,    -1,   389,    -1,    -1,   392,   206,   207,    -1,
      -1,    -1,   211,    -1,   213,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   226,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   234,   235,    -1,    -1,    -1,
     372,   240,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,
      -1,   393,    -1,    -1,    -1,    -1,    -1,   266,   267,   268,
      -1,   270,    -1,   272,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   284,   285,   286,    -1,   288,
      -1,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   302,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   312,   313,   314,   315,   316,   317,    -1,
      -1,    -1,    -1,    -1,   323,   324,   325,   326,   327,   328,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,    -1,    -1,    36,    -1,
      -1,    -1,    -1,   352,   353,   354,   355,   356,   357,    -1,
      -1,    -1,    50,    -1,    -1,    37,    38,    -1,   367,   368,
     369,   370,    -1,    -1,    62,    47,    -1,    -1,    -1,    -1,
      52,    -1,    -1,   382,   383,    -1,    -1,    75,    -1,   388,
      -1,    -1,   391,    -1,    -1,    -1,    -1,    -1,    -1,   372,
      88,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,   372,
     393,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    22,    -1,   389,    -1,    -1,    -1,
     393,    -1,    -1,   131,   132,   117,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,    -1,
     148,   149,   150,    -1,    -1,   153,    -1,    -1,   140,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   170,    -1,    -1,    -1,   174,    -1,    -1,   161,
      -1,    -1,    -1,    -1,   182,    -1,   184,    -1,   186,   187,
      -1,    -1,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,   206,   389,
     208,   209,   392,   211,    -1,   213,    -1,   215,    -1,    -1,
      -1,    -1,    -1,    -1,   206,    -1,    -1,    -1,   226,   211,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,
      -1,   372,   240,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
      -1,    -1,   393,    -1,    -1,    -1,    -1,    -1,   266,   267,
     268,    -1,    -1,   271,    -1,    18,    19,    20,    21,   277,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
     288,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   281,
      -1,    -1,    -1,    -1,   302,    -1,    -1,    50,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
     302,    64,    -1,    -1,    67,   323,   324,   325,   326,   327,
     328,   372,    75,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    22,    -1,   389,   331,
      -1,    -1,   393,    -1,   352,   353,   354,   355,   356,   357,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,    -1,    -1,   359,   121,    -1,
      -1,    -1,    -1,    -1,   382,   383,    -1,    -1,   131,   132,
     388,    -1,    22,   391,    -1,    -1,   139,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,
     153,    -1,   394,    -1,   157,    -1,    -1,    -1,    -1,    -1,
     163,    -1,    -1,   166,    -1,    -1,   169,   170,    -1,    -1,
     173,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   184,    -1,   186,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   206,    -1,    -1,    -1,    -1,   211,    -1,
      -1,    -1,    -1,    -1,   372,    -1,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,    -1,    -1,   393,   372,   240,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      -1,    -1,    -1,   266,   267,   268,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   287,   288,    18,    19,    20,    21,
      -1,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    -1,    -1,    -1,    -1,    -1,    -1,   310,    -1,   312,
     313,   314,   315,   316,   317,    -1,    -1,    -1,    50,    51,
     323,   324,   325,   326,   327,   328,   329,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,   352,
     353,   354,   355,   356,   357,    -1,    -1,    22,    -1,    -1,
      -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,    -1,
     102,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   382,
     383,    -1,    -1,    -1,    -1,   388,    -1,    -1,   391,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,   131,
     132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   148,   149,   150,    -1,
     152,   153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   163,   164,    -1,    -1,    -1,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,   184,   389,   186,    -1,   372,   393,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      -1,    -1,   372,   215,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,    -1,    -1,   393,    -1,    -1,    -1,    -1,   240,    52,
      53,    54,    -1,    56,    -1,    -1,   248,    -1,    61,   251,
      -1,    -1,    -1,    -1,    -1,    -1,    69,    -1,    -1,    -1,
      -1,    -1,    -1,   265,   266,   267,   268,    -1,    -1,   271,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,   288,    -1,    -1,    -1,
      -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   303,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     312,   313,   314,   315,   316,   317,    22,    -1,    -1,    67,
      -1,   323,   324,   325,   326,   327,   328,    75,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     352,   353,   354,   355,   356,   357,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,
      -1,    -1,    -1,   121,    -1,    -1,    -1,    -1,    22,    -1,
     382,   383,    -1,   131,   132,    -1,   388,    -1,    -1,   391,
      -1,    -1,   205,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     148,   149,    -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,
      -1,   159,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,    -1,   170,    -1,    -1,   173,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   184,   372,   186,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,   392,   206,    18,
      19,    20,    21,   211,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    -1,    -1,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    50,   240,   389,    -1,    -1,    -1,   393,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   253,    -1,    66,    67,    22,
      -1,    -1,    -1,    -1,    -1,    -1,    75,    -1,   266,   267,
     268,    -1,   335,    -1,   337,   338,   339,   340,   341,   342,
     343,   344,   345,   346,   347,   348,   349,   350,   351,    -1,
     288,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   114,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      22,    -1,   131,   132,    -1,   323,   324,   325,   326,   327,
     328,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,
     149,    -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
     169,   170,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,   184,    -1,   186,    -1,    -1,
      -1,    -1,    -1,    -1,   382,   383,    -1,    -1,    -1,    -1,
     388,    -1,   372,   391,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,   220,    -1,   393,    -1,    -1,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,   240,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,    -1,   266,   267,   268,
      -1,    -1,   271,   272,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,   372,   288,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    75,    -1,   393,
      -1,    -1,    22,   312,   313,   314,   315,   316,   317,    87,
      -1,    -1,    -1,    -1,   323,   324,   325,   326,   327,   328,
     372,    -1,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,   114,   389,    -1,    -1,
      -1,   393,    -1,   352,   353,   354,   355,   356,   357,    -1,
      22,    -1,    -1,   131,   132,    -1,    -1,    -1,   367,   368,
     369,   370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     148,   149,    -1,   382,   383,   153,    -1,    -1,    -1,   388,
      -1,    -1,   391,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   169,   170,    -1,    -1,   173,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   184,    -1,   186,   372,
     373,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,   206,    18,
      19,    20,    21,   211,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    -1,    -1,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    50,   240,   389,    -1,    -1,    -1,   393,    -1,    -1,
     372,    -1,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    75,   389,   266,   267,
     268,   393,    -1,    -1,    -1,    -1,    -1,    -1,    87,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     288,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   114,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      22,    -1,   131,   132,    -1,   323,   324,   325,   326,   327,
     328,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,
     149,    -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
     169,   170,    -1,    -1,   173,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,   184,    -1,   186,    -1,    -1,
      -1,    -1,    -1,    -1,   382,   383,    -1,    -1,    -1,    -1,
     388,    -1,    -1,   391,    -1,    -1,    -1,   206,    18,    19,
      20,    21,   211,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    43,    -1,    -1,    -1,    -1,    -1,    -1,
      50,   240,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,    -1,    -1,   393,    -1,    75,    -1,   266,   267,   268,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   288,
     372,    -1,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,
      -1,   393,    -1,   312,   313,   314,   315,   316,   317,    22,
      -1,   131,   132,    -1,   323,   324,   325,   326,   327,   328,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,   149,
      -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   352,   353,   354,   355,   356,   357,   169,
     170,    -1,    -1,   173,    -1,    -1,    -1,    -1,   367,   368,
     369,   370,    -1,    -1,   184,    -1,   186,    -1,    -1,    -1,
      -1,    -1,    -1,   382,   383,    -1,    -1,    -1,    -1,   388,
      -1,    -1,   391,    -1,    -1,    -1,   206,    18,    19,    20,
      21,   211,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    50,
     240,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    -1,    -1,    -1,    67,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    75,    -1,   266,   267,   268,    -1,
      -1,    -1,    22,    -1,    -1,    -1,    87,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,
     372,    -1,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,
     121,   393,   312,   313,   314,   315,   316,   317,    -1,    -1,
     131,   132,    22,   323,   324,   325,   326,   327,   328,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,   149,    -1,
      -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   352,   353,   354,   355,   356,   357,    -1,   170,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,
     370,    -1,    -1,   184,    -1,   186,    -1,    -1,    -1,    -1,
      -1,    -1,   382,   383,    -1,    -1,    -1,    -1,   388,    -1,
      -1,   391,    -1,    -1,    -1,   206,    18,    19,    20,    21,
     211,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    50,   240,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   253,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    75,    -1,   266,   267,   268,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,   372,
      -1,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,
     393,   312,   313,   314,   315,   316,   317,    22,    -1,   131,
     132,   133,   323,   324,   325,   326,   327,   328,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,
      -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   352,   353,   354,   355,   356,   357,   169,   170,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,
      -1,    -1,   184,    -1,   186,    -1,    -1,    -1,    -1,    -1,
      -1,   382,   383,    -1,    -1,    -1,    -1,   388,    -1,    -1,
     391,    -1,    -1,    -1,   206,    18,    19,    20,    21,   211,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      -1,    -1,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    50,   240,   389,
      -1,    22,   372,   393,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,    -1,    75,   393,   266,   267,   268,    -1,    -1,   271,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,    -1,    -1,
      -1,    -1,   372,   295,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
     312,   313,   314,   315,   316,   317,    22,    -1,   131,   132,
     133,   323,   324,   325,   326,   327,   328,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,
     153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     352,   353,   354,   355,   356,   357,   169,   170,    22,    -1,
      -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,
      -1,   184,    -1,   186,    -1,    -1,    -1,    -1,    -1,    -1,
     382,   383,    -1,    -1,    -1,    -1,   388,    -1,    -1,   391,
      -1,    -1,    -1,   206,    18,    19,    20,    21,   211,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    46,    -1,    -1,    -1,    50,   240,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    62,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      -1,    -1,    -1,   266,   267,   268,    -1,    -1,   271,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      -1,    -1,    -1,    -1,    -1,   288,    -1,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    22,   389,    -1,    -1,    -1,   393,   312,
     313,   314,   315,   316,   317,    -1,    -1,   131,   132,    -1,
     323,   324,   325,   326,   327,   328,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,   153,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   352,
     353,   354,   355,   356,   357,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,    -1,
     184,    -1,   186,    -1,    -1,    -1,    -1,    -1,    -1,   382,
     383,    -1,    -1,    -1,    -1,   388,    -1,    -1,   391,    -1,
     204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     214,   372,    -1,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
      -1,    -1,   393,    -1,    -1,    -1,   240,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    21,    -1,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    -1,    -1,    -1,
      -1,    -1,   266,   267,   268,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   277,    50,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   288,    -1,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,    -1,   393,   312,   313,
     314,   315,   316,   317,    22,    -1,    -1,    -1,    -1,   323,
     324,   325,   326,   327,   328,    -1,    -1,    -1,   372,   373,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,   352,   353,
     354,   355,   356,   357,    -1,   131,   132,    -1,    -1,    -1,
      -1,    -1,    -1,   367,   368,   369,   370,    -1,    -1,    -1,
      -1,    -1,   148,   149,    -1,    -1,    -1,   153,   382,   383,
      -1,    -1,    -1,    -1,   388,    -1,    -1,   391,    18,    19,
      20,    21,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,    -1,    -1,    -1,   184,    -1,
     186,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,
      50,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    22,    -1,   372,
     393,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    22,    -1,    -1,
     393,    -1,    -1,   372,   240,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,    -1,
     389,    -1,    -1,    -1,   393,    -1,    -1,    -1,    -1,    -1,
     266,   267,   268,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   288,    -1,    -1,    -1,    -1,    -1,   148,   149,
      -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   312,   313,   314,   315,
     316,   317,    -1,    -1,    -1,    -1,    -1,   323,   324,   325,
     326,   327,   328,    -1,   184,    -1,   186,   333,   334,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   352,   353,   354,   355,
     356,   357,    -1,    -1,    -1,   361,   362,    -1,    -1,    -1,
      -1,   367,   368,   369,   370,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   382,   383,    -1,    -1,
     240,    -1,   388,    -1,    -1,   391,    -1,    -1,    -1,    -1,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,   266,   267,   268,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,   288,    -1,
      -1,    -1,    -1,    -1,   372,    -1,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,   312,   313,   314,   315,   316,   317,    -1,    22,
      -1,    -1,    -1,   323,   324,   325,   326,   327,   328,    -1,
      -1,    -1,    -1,   333,   334,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   352,   353,   354,   355,   356,   357,    -1,    -1,
      -1,   361,   362,   131,   132,    -1,    -1,   367,   368,   369,
     370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     148,   149,   382,   383,    -1,   153,    -1,    -1,   388,    -1,
      -1,   391,    -1,    -1,    -1,   163,    -1,    -1,   166,    -1,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,   184,   372,   186,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    50,    -1,   389,    -1,    -1,   372,   393,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   240,   372,    -1,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,    -1,
     389,    -1,    -1,    -1,   393,    -1,    -1,    -1,   266,   267,
     268,    22,    -1,   271,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   131,   132,    -1,    -1,    -1,    -1,    -1,
     288,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     148,   149,    -1,    -1,   302,   153,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      -1,    -1,    -1,    -1,    -1,   323,   324,   325,   326,   327,
     328,    -1,    -1,    -1,    -1,    -1,   184,   185,   186,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   382,   383,    -1,    22,    -1,    -1,
     388,    -1,   240,   391,    -1,    -1,    -1,    -1,   246,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   255,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   266,   267,
     268,    -1,    -1,    18,    19,    20,    21,    -1,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    -1,   372,
     288,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    50,   389,    -1,    -1,    -1,
     393,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      -1,    -1,    -1,    -1,    -1,   323,   324,   325,   326,   327,
     328,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      -1,    -1,    -1,    -1,   382,   383,   131,   132,    -1,    -1,
     388,    -1,    -1,   391,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   148,   149,    -1,    -1,    -1,   153,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    21,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,   184,
     185,   186,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,
      -1,   372,    -1,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
      -1,    -1,   393,    -1,    -1,   240,    -1,    -1,    22,    -1,
      -1,   246,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   294,
     255,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   266,   267,   268,    -1,    22,    -1,    -1,    -1,    -1,
      -1,   131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   288,    -1,    22,    -1,    -1,   148,   149,
      -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,   313,   314,
     315,   316,   317,    -1,    -1,    -1,    -1,    -1,   323,   324,
     325,   326,   327,   328,   184,    -1,   186,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,   352,   353,   354,
     355,   356,   357,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   367,   368,   369,   370,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    22,    -1,    -1,   382,   383,    -1,
     240,    -1,    -1,   388,    -1,    -1,   391,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   266,   267,   268,    -1,
      -1,    -1,    18,    19,    20,    21,   276,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    -1,   288,   372,
      -1,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    50,    -1,   389,    -1,    -1,    -1,
     393,    57,   312,   313,   314,   315,   316,   317,    -1,    -1,
      -1,    -1,    -1,   323,   324,   325,   326,   327,   328,   372,
      -1,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,
     393,    -1,   352,   353,   354,   355,   356,   357,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,
     370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,
      -1,    -1,   382,   383,    -1,   131,   132,    -1,   388,    -1,
      -1,   391,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   148,   149,    -1,   151,    -1,   153,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      21,    -1,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    -1,    -1,    -1,   184,    -1,
     186,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,    50,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,
      -1,    -1,    -1,    -1,    75,   372,    22,   374,   375,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
      -1,    -1,   389,    -1,   240,   372,   393,   374,   375,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
      -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,    22,
     266,   267,   268,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   288,    -1,    -1,    -1,    -1,   148,   149,    -1,
      -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   312,   313,   314,   315,
     316,   317,    -1,    -1,    -1,    -1,    -1,   323,   324,   325,
     326,   327,   328,   184,   372,   186,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,    -1,    -1,   393,   352,   353,   354,   355,
     356,   357,    22,    -1,    -1,    -1,    -1,    -1,    -1,   220,
      -1,   367,   368,   369,   370,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   382,   383,    -1,   240,
      -1,    -1,   388,    -1,    -1,   391,    -1,    -1,    18,    19,
      20,    21,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,   266,   267,   268,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    46,    -1,    -1,    -1,
      50,    -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   312,   313,   314,   315,   316,   317,    -1,    -1,    -1,
      -1,    -1,   323,   324,   325,   326,   327,   328,   372,    -1,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,
      -1,   352,   353,   354,   355,   356,   357,    22,    -1,    -1,
      -1,   131,   132,    -1,    -1,    -1,   367,   368,   369,   370,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,   149,
      -1,   382,   383,   153,    -1,    -1,    -1,   388,    -1,    -1,
     391,    -1,    -1,    -1,    -1,    18,    19,    20,    21,    -1,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      -1,    -1,    -1,    -1,   184,    -1,   186,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   372,    50,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      22,    -1,    -1,    -1,    77,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,
     240,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,
     393,    -1,    -1,    22,    -1,    -1,   266,   267,   268,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   277,   131,   132,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,
      -1,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,
     153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   312,   313,   314,   315,   316,   317,    -1,    -1,
      -1,    -1,    -1,   323,   324,   325,   326,   327,   328,    -1,
      -1,   184,   372,   186,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,    -1,   352,   353,   354,   355,   356,   357,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,
     370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   382,   383,    -1,    -1,    -1,   240,   388,   242,
      -1,   391,    18,    19,    20,    21,    -1,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    -1,    -1,    -1,
      -1,    -1,    -1,   266,   267,   268,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   288,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    69,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,
     313,   314,   315,   316,   317,    -1,    -1,    -1,    -1,    -1,
     323,   324,   325,   326,   327,   328,    -1,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,   352,
     353,   354,   355,   356,   357,   131,   132,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,    -1,
      -1,    -1,   148,   149,    -1,    -1,    -1,   153,    -1,   382,
     383,    -1,    -1,    -1,    -1,   388,    -1,    -1,   391,    18,
      19,    20,    21,    -1,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    -1,    -1,    -1,    -1,   184,    -1,
     186,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     372,    50,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,
      -1,   393,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   372,   240,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,    -1,
     389,    -1,    -1,    -1,   393,    -1,    -1,    22,    -1,    -1,
     266,   267,   268,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   131,   132,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   288,    -1,    -1,    -1,    -1,    -1,    -1,   148,
     149,    -1,    -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   312,   313,   314,   315,
     316,   317,    -1,    -1,    -1,    -1,    -1,   323,   324,   325,
     326,   327,   328,    -1,    -1,   184,    -1,   186,   372,    -1,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,   352,   353,   354,   355,
     356,   357,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   367,   368,   369,   370,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   382,   383,    -1,    -1,
      -1,   240,   388,    -1,    -1,   391,    18,    19,    20,    21,
      -1,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    -1,    -1,    -1,    -1,    -1,    -1,   266,   267,   268,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    50,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   288,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   312,   313,   314,   315,   316,   317,    -1,
      -1,   320,    -1,    -1,   323,   324,   325,   326,   327,   328,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   352,   353,   354,   355,   356,   357,   131,
     132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,   368,
     369,   370,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,
      -1,   153,    -1,   382,   383,    -1,    -1,    -1,    -1,   388,
      -1,    -1,   391,    18,    19,    20,    21,    -1,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    -1,    -1,
      -1,    -1,   184,    -1,   186,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   372,    50,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,    -1,    69,   393,    -1,    -1,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,   240,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,    -1,
      -1,    22,    -1,    -1,   266,   267,   268,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   131,   132,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,    -1,    -1,
      -1,    -1,    -1,   148,   149,    -1,    -1,    -1,   153,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     312,   313,   314,   315,   316,   317,    -1,    -1,    -1,    -1,
      -1,   323,   324,   325,   326,   327,   328,    -1,    -1,   184,
      -1,   186,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
     352,   353,   354,   355,   356,   357,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     382,   383,    -1,    -1,    -1,   240,   388,    -1,    -1,   391,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,    -1,    -1,    -1,    -1,
      -1,   266,   267,   268,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   288,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    69,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,   313,   314,
     315,   316,   317,    -1,    -1,    -1,    -1,    -1,   323,   324,
     325,   326,   327,   328,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   352,   353,   354,
     355,   356,   357,   131,   132,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   367,   368,   369,   370,    -1,    -1,    -1,    -1,
     148,   149,    -1,    -1,    -1,   153,    -1,   382,   383,    -1,
      -1,    -1,    -1,   388,    -1,    -1,   391,    18,    19,    20,
      21,    -1,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    -1,   184,    -1,   186,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,    50,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,    69,   393,
      -1,    -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   372,   240,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
      -1,    -1,   393,    -1,    -1,    22,    -1,    -1,   266,   267,
     268,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     288,    -1,    -1,    -1,    -1,    -1,    -1,   148,   149,    -1,
      -1,    -1,   153,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      -1,    -1,    -1,    -1,    -1,   323,   324,   325,   326,   327,
     328,    -1,    -1,   184,    -1,   186,   372,    -1,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,   352,   353,   354,   355,   356,   357,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   382,   383,    -1,    -1,    -1,   240,
     388,    -1,    -1,   391,    18,    19,    20,    21,    -1,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,   266,   267,   268,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    50,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   288,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    69,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   312,   313,   314,   315,   316,   317,    22,    -1,    -1,
      -1,    -1,   323,   324,   325,   326,   327,   328,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   352,   353,   354,   355,   356,   357,   131,   132,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,
      -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,   153,
      -1,   382,   383,    -1,    -1,    -1,    -1,   388,    -1,    -1,
     391,    -1,    -1,    18,    19,    20,    21,    -1,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    -1,    -1,
     184,    -1,   186,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   372,    50,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,    -1,    -1,   393,    -1,    -1,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   372,   240,   374,   375,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
      -1,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,    -1,
      -1,    22,   266,   267,   268,    -1,   121,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   131,   132,    -1,    -1,
      -1,    -1,    -1,    -1,   288,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   148,   149,    -1,    -1,    -1,   153,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,   313,
     314,   315,   316,   317,    -1,    -1,    -1,    -1,    -1,   323,
     324,   325,   326,   327,   328,    -1,    -1,    -1,    -1,   184,
     372,   186,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,   352,   353,
     354,   355,   356,   357,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   367,   368,   369,   370,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   382,   383,
      -1,    -1,    -1,    -1,   388,   240,    -1,   391,    -1,    -1,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,    -1,    -1,    -1,    -1,
      -1,   266,   267,   268,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   288,    -1,    -1,    -1,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,    22,   312,   313,   314,
     315,   316,   317,    -1,    -1,    -1,    -1,    -1,   323,   324,
     325,   326,   327,   328,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   352,   353,   354,
     355,   356,   357,   131,   132,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   367,   368,   369,   370,    -1,    -1,    -1,    -1,
     148,   149,    -1,    -1,    -1,   153,    -1,   382,   383,    -1,
      -1,    -1,    -1,   388,    -1,    -1,   391,    18,    19,    20,
      21,    -1,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    -1,   184,    -1,   186,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,    50,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,    -1,   393,
      -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   372,   240,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
      -1,    -1,   393,    -1,    -1,    22,    -1,    -1,   266,   267,
     268,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     288,    -1,    -1,    -1,    -1,    -1,    -1,   148,   149,    -1,
      -1,    -1,   153,    -1,   302,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,   317,
      -1,    -1,    -1,    -1,    -1,   323,   324,   325,   326,   327,
     328,    -1,    -1,   184,    -1,   186,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,   357,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   367,
     368,   369,   370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   382,   383,    -1,    -1,    -1,   240,
     388,    -1,    -1,   391,    18,    19,    20,    21,    -1,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,   266,   267,   268,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    50,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   372,   288,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,   302,    -1,   389,    -1,    -1,    -1,   393,    -1,    -1,
      22,   312,   313,   314,   315,   316,   317,    -1,    -1,    -1,
      -1,    -1,   323,   324,   325,   326,   327,   328,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   352,   353,   354,   355,   356,   357,   131,   132,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,   370,
      -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,   153,
      -1,   382,   383,    -1,    -1,    -1,    -1,   388,    -1,    -1,
     391,    18,    19,    20,    21,    -1,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    -1,    -1,    -1,    -1,
     184,    -1,   186,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   372,    50,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    22,    -1,   389,
      -1,    -1,    -1,   393,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   372,   240,   374,   375,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
      -1,    -1,   389,    -1,    -1,   392,    -1,    -1,    -1,    22,
      -1,    -1,   266,   267,   268,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   131,   132,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   288,    -1,    -1,    -1,    -1,    22,
      -1,   148,   149,    -1,    -1,    -1,   153,    -1,   302,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,   313,
     314,   315,   316,   317,    -1,    -1,    -1,    -1,    -1,   323,
     324,   325,   326,   327,   328,    -1,    -1,   184,    -1,   186,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   352,   353,
     354,   355,   356,   357,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   367,   368,   369,   370,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   382,   383,
      -1,    -1,    -1,   240,   388,    -1,    -1,   391,    18,    19,
      20,    21,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,   266,
     267,   268,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     372,   288,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    22,    -1,   389,    -1,    -1,
     392,    -1,    -1,    -1,    -1,   312,   313,   314,   315,   316,
     317,    -1,    -1,    -1,    22,    -1,   323,   324,   325,   326,
     327,   328,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   352,   353,   354,   355,   356,
     357,   131,   132,    -1,    22,    -1,    -1,    -1,    -1,    -1,
     367,   368,   369,   370,    -1,    -1,    -1,    -1,   148,   149,
      -1,    -1,    -1,   153,    -1,   382,   383,    22,    -1,    -1,
      -1,   388,    -1,   372,   391,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    22,    -1,
     389,    -1,    -1,   392,   184,    -1,   186,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    22,    -1,   389,    -1,   372,   392,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    22,    -1,   389,    -1,    -1,   392,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,
     240,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    22,    -1,   389,    -1,    -1,   392,
      -1,    -1,    -1,    -1,    -1,    -1,   266,   267,   268,   372,
      -1,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    22,    -1,   389,    -1,   288,   392,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   312,   313,   314,   315,   316,   317,    -1,    -1,
      -1,    -1,    22,   323,   324,   325,   326,   327,   328,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   352,   353,   354,   355,   356,   357,    -1,    -1,
      22,    -1,    -1,    -1,    -1,    -1,    -1,   367,   368,   369,
     370,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      -1,    -1,   382,   383,    -1,    -1,    -1,    -1,   388,    -1,
      -1,   391,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    22,    -1,   389,
      -1,    -1,   392,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   372,    22,   374,   375,   376,
     377,   378,   379,   380,   381,   382,   383,   384,   385,   386,
      -1,    -1,   389,    -1,   372,   392,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    22,
      -1,   389,    -1,   372,   392,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    22,    -1,
     389,    -1,    -1,   392,   372,    -1,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    22,
      -1,   389,    -1,    -1,   392,    -1,    -1,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    22,    -1,   389,    -1,    -1,   392,   372,    -1,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    22,    -1,   389,    -1,    -1,   392,    -1,
      -1,    -1,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    22,    -1,   389,
      -1,   372,   392,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    22,    -1,   389,    -1,
      -1,   392,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   372,    -1,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,    -1,   392,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   372,    -1,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,   384,   385,   386,    -1,
      -1,   389,    -1,   372,   392,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,    -1,
     389,    -1,   372,   392,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,   372,   392,   374,   375,   376,   377,   378,   379,   380,
     381,   382,   383,   384,   385,   386,    -1,    -1,   389,    -1,
     372,   392,   374,   375,   376,   377,   378,   379,   380,   381,
     382,   383,   384,   385,   386,    -1,    -1,   389,    -1,   372,
     392,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,   392,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,   372,   392,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    -1,    -1,   389,    -1,    -1,   392,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   372,
      -1,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,   372,   392,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
     384,   385,   386,    -1,    -1,   389,    -1,    -1,   392,   372,
      -1,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,   384,   385,   386,    -1,    -1,   389,    -1,    -1,   392,
      -1,    -1,   372,    -1,   374,   375,   376,   377,   378,   379,
     380,   381,   382,   383,   384,   385,   386,    -1,    -1,   389,
      -1,    -1,   392,   372,    -1,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,    -1,    -1,
     389,    -1,    -1,   392,    -1,    -1,    -1,   372,    -1,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,    -1,    -1,   389,    -1,   372,   392,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,   384,   385,
     386,    49,    -1,   389,    -1,    -1,   392,    55,    49,    -1,
      -1,    -1,    -1,    -1,    55,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    75,    76,    -1,
      -1,    -1,    -1,    -1,    75,    76,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   104,   105,    -1,    -1,
      -1,   109,    -1,   104,   105,    -1,   114,    -1,   109,    -1,
      -1,    -1,    -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    84,    85,    86,
      -1,    -1,   140,    90,    91,    92,    93,    94,    95,   140,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   108,    -1,    -1,   111,    -1,    -1,   165,   166,   167,
      -1,   169,   170,   171,   165,   166,   167,    -1,   169,   170,
     171,    -1,   129,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   142,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   206,    -1,
      -1,    -1,    -1,   211,    -1,   206,    -1,    -1,    -1,    -1,
     211,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,
      -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,    -1,    -1,
      -1,   188,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   272,    -1,    -1,    -1,    -1,    -1,
      -1,   272,    -1,    -1,    -1,    -1,   233,    -1,    -1,    -1,
      -1,    -1,    -1,   291,    -1,    -1,    -1,    -1,    -1,    -1,
     291,    -1,    -1,    -1,   302,    -1,    -1,    -1,    -1,    -1,
      -1,   302,    -1,    -1,    -1,    -1,    -1,   264,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   351,    -1,    -1,    -1,    -1,    -1,    -1,
     351,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   394,    -1,    -1,    -1,
      -1,    -1,    -1,   394,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   363,   364
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison/bison.simple"

/* Skeleton output parser for bison,

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser when
   the %semantic_parser declaration is not specified in the grammar.
   It was written by Richard Stallman by simplifying the hairy parser
   used when %semantic_parser is specified.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

#if ! defined (yyoverflow) || defined (YYERROR_VERBOSE)

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || defined (YYERROR_VERBOSE) */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
# if YYLSP_NEEDED
  YYLTYPE yyls;
# endif
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# if YYLSP_NEEDED
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAX)
# else
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)
# endif

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif


#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).

   When YYLLOC_DEFAULT is run, CURRENT is set the location of the
   first token.  By default, to implement support for ranges, extend
   its range to the last symbol.  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)       	\
   Current.last_line   = Rhs[N].last_line;	\
   Current.last_column = Rhs[N].last_column;
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#if YYPURE
# if YYLSP_NEEDED
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, &yylloc, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval, &yylloc)
#  endif
# else /* !YYLSP_NEEDED */
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval)
#  endif
# endif /* !YYLSP_NEEDED */
#else /* !YYPURE */
# define YYLEX			yylex ()
#endif /* !YYPURE */


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

#ifdef YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif
#endif

#line 315 "/usr/share/bison/bison.simple"


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif

/* YY_DECL_VARIABLES -- depending whether we use a pure parser,
   variables are global, or local to YYPARSE.  */

#define YY_DECL_NON_LSP_VARIABLES			\
/* The lookahead symbol.  */				\
int yychar;						\
							\
/* The semantic value of the lookahead symbol. */	\
YYSTYPE yylval;						\
							\
/* Number of parse errors so far.  */			\
int yynerrs;

#if YYLSP_NEEDED
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES			\
						\
/* Location data for the lookahead symbol.  */	\
YYLTYPE yylloc;
#else
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES
#endif


/* If nonreentrant, generate the variables here. */

#if !YYPURE
YY_DECL_VARIABLES
#endif  /* !YYPURE */

int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  /* If reentrant, generate the variables here. */
#if YYPURE
  YY_DECL_VARIABLES
#endif  /* !YYPURE */

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack. */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

#if YYLSP_NEEDED
  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
#endif

#if YYLSP_NEEDED
# define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
# define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  YYSIZE_T yystacksize = YYINITDEPTH;


  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
#if YYLSP_NEEDED
  YYLTYPE yyloc;
#endif

  /* When reducing, the number of symbols on the RHS of the reduced
     rule. */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
#if YYLSP_NEEDED
  yylsp = yyls;
#endif
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  */
# if YYLSP_NEEDED
	YYLTYPE *yyls1 = yyls;
	/* This used to be a conditional around just the two extra args,
	   but that might be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
# else
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);
# endif
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
# if YYLSP_NEEDED
	YYSTACK_RELOCATE (yyls);
# endif
# undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
#if YYLSP_NEEDED
      yylsp = yyls + yysize - 1;
#endif

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

#if YYDEBUG
     /* We have to keep this `#if YYDEBUG', since we use variables
	which are defined only if `YYDEBUG' is set.  */
      if (yydebug)
	{
	  YYFPRINTF (stderr, "Next token is %d (%s",
		     yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise
	     meaning of a token, for further debugging info.  */
# ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
# endif
	  YYFPRINTF (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to the semantic value of
     the lookahead token.  This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

#if YYLSP_NEEDED
  /* Similarly for the default location.  Let the user run additional
     commands if for instance locations are ranges.  */
  yyloc = yylsp[1-yylen];
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
#endif

#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] > 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  switch (yyn) {

case 2:
#line 620 "pars.yacc"
{
            expr_parsed = TRUE;
            s_result = yyvsp[0].dval;
        }
    break;
case 3:
#line 624 "pars.yacc"
{
            vexpr_parsed = TRUE;
            v_result = yyvsp[0].vrbl;
        }
    break;
case 7:
#line 637 "pars.yacc"
{}
    break;
case 8:
#line 638 "pars.yacc"
{}
    break;
case 9:
#line 639 "pars.yacc"
{}
    break;
case 10:
#line 640 "pars.yacc"
{}
    break;
case 11:
#line 641 "pars.yacc"
{}
    break;
case 12:
#line 642 "pars.yacc"
{}
    break;
case 13:
#line 643 "pars.yacc"
{}
    break;
case 14:
#line 644 "pars.yacc"
{}
    break;
case 15:
#line 645 "pars.yacc"
{}
    break;
case 16:
#line 646 "pars.yacc"
{}
    break;
case 17:
#line 647 "pars.yacc"
{
	    return 1;
	}
    break;
case 18:
#line 654 "pars.yacc"
{
	    yyval.dval = yyvsp[0].dval;
	}
    break;
case 19:
#line 657 "pars.yacc"
{
	    yyval.dval = *(yyvsp[0].dptr);
	}
    break;
case 20:
#line 660 "pars.yacc"
{
	    yyval.dval = nonl_parms[yyvsp[0].ival].value;
	}
    break;
case 21:
#line 663 "pars.yacc"
{
	    yyval.dval = nonl_parms[yyvsp[0].ival].max;
	}
    break;
case 22:
#line 666 "pars.yacc"
{
	    yyval.dval = nonl_parms[yyvsp[0].ival].min;
	}
    break;
case 23:
#line 669 "pars.yacc"
{
            if (yyvsp[0].ival >= yyvsp[-1].vrbl->length) {
                errmsg("Access beyond array bounds");
                return 1;
            }
            yyval.dval = yyvsp[-1].vrbl->data[yyvsp[0].ival];
	}
    break;
case 24:
#line 676 "pars.yacc"
{
	    double dummy, dummy2;
            int idummy, ind, length = yyvsp[-1].vrbl->length;
	    if (yyvsp[-1].vrbl->data == NULL) {
		yyerror("NULL variable, check set type");
		return 1;
	    }
	    switch (yyvsp[-3].ival) {
	    case MINP:
		yyval.dval = vmin(yyvsp[-1].vrbl->data, length);
		break;
	    case MAXP:
		yyval.dval = vmax(yyvsp[-1].vrbl->data, length);
		break;
            case AVG:
		stasum(yyvsp[-1].vrbl->data, length, &yyval.dval, &dummy);
                break;
            case SD:
		stasum(yyvsp[-1].vrbl->data, length, &dummy, &yyval.dval);
                break;
            case SUM:
		stasum(yyvsp[-1].vrbl->data, length, &yyval.dval, &dummy);
                yyval.dval *= length;
                break;
            case IMIN:
		minmax(yyvsp[-1].vrbl->data, length, &dummy, &dummy2, &ind, &idummy);
                yyval.dval = (double) ind;
                break;
            case IMAX:
		minmax(yyvsp[-1].vrbl->data, length, &dummy, &dummy2, &idummy, &ind);
                yyval.dval = (double) ind;
                break;
	    }
	}
    break;
case 25:
#line 710 "pars.yacc"
{
	    if (yyvsp[-3].vrbl->length != yyvsp[-1].vrbl->length) {
		yyerror("X and Y are of different length");
		return 1;
            } else {
                yyval.dval = trapint(yyvsp[-3].vrbl->data, yyvsp[-1].vrbl->data, NULL, NULL, yyvsp[-3].vrbl->length);
            }
	}
    break;
case 26:
#line 718 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].vrbl->length;
	}
    break;
case 27:
#line 721 "pars.yacc"
{
	    yyval.dval = getsetlength(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno);
	}
    break;
case 28:
#line 724 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].trgt->setno;
	}
    break;
case 29:
#line 727 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].ival;
	}
    break;
case 30:
#line 731 "pars.yacc"
{
            yyval.dval = ((ParserFnc) (key[yyvsp[0].ival].data)) ();
	}
    break;
case 31:
#line 735 "pars.yacc"
{
	    yyval.dval = yyvsp[-1].dval * ((ParserFnc) (key[yyvsp[0].ival].data)) ();
	}
    break;
case 32:
#line 739 "pars.yacc"
{
	    yyval.dval = drand48();
	}
    break;
case 33:
#line 743 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-3].ival].data)) (yyvsp[-1].ival);
	}
    break;
case 34:
#line 747 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-3].ival].data)) (yyvsp[-1].dval);
	}
    break;
case 35:
#line 751 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].ival, yyvsp[-1].dval);
	}
    break;
case 36:
#line 755 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].ival, yyvsp[-1].ival);
	}
    break;
case 37:
#line 759 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].dval, yyvsp[-1].dval);
	}
    break;
case 38:
#line 763 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-7].ival].data)) (yyvsp[-5].ival, yyvsp[-3].ival, yyvsp[-1].dval);
	}
    break;
case 39:
#line 767 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-7].ival].data)) (yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].dval);
	}
    break;
case 40:
#line 771 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-9].ival].data)) (yyvsp[-7].dval, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].dval);
	}
    break;
case 41:
#line 775 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-11].ival].data)) (yyvsp[-9].dval, yyvsp[-7].dval, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].dval);
	}
    break;
case 42:
#line 779 "pars.yacc"
{
	    yyval.dval = ((ParserFnc) (key[yyvsp[-13].ival].data)) (yyvsp[-11].dval, yyvsp[-9].dval, yyvsp[-7].dval, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].dval);
	}
    break;
case 43:
#line 782 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].v.xv1;
	}
    break;
case 44:
#line 785 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].v.xv2;
	}
    break;
case 45:
#line 788 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].v.yv1;
	}
    break;
case 46:
#line 791 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].v.yv2;
	}
    break;
case 47:
#line 794 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].w.xg1;
	}
    break;
case 48:
#line 797 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].w.xg2;
	}
    break;
case 49:
#line 800 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].w.yg1;
	}
    break;
case 50:
#line 803 "pars.yacc"
{
	    yyval.dval = g[yyvsp[-2].ival].w.yg2;
	}
    break;
case 51:
#line 806 "pars.yacc"
{
            yyval.dval = yyvsp[-1].dval;
	}
    break;
case 52:
#line 809 "pars.yacc"
{ /* yr, mo, day */
	    yyval.dval = cal_and_time_to_jul(yyvsp[-5].ival, yyvsp[-3].ival, yyvsp[-1].ival, 12, 0, 0.0);
	}
    break;
case 53:
#line 813 "pars.yacc"
{ /* yr, mo, day, hr, min, sec */
	    yyval.dval = cal_and_time_to_jul(yyvsp[-11].ival, yyvsp[-9].ival, yyvsp[-7].ival, yyvsp[-5].ival, yyvsp[-3].ival, yyvsp[-1].dval);
	}
    break;
case 54:
#line 816 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
            yyval.dval = g[whichgraph].v.xv1;
	}
    break;
case 55:
#line 823 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].v.xv2;
	}
    break;
case 56:
#line 830 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].v.yv1;
	}
    break;
case 57:
#line 837 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].v.yv2;
	}
    break;
case 58:
#line 844 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].w.xg1;
	}
    break;
case 59:
#line 851 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].w.xg2;
	}
    break;
case 60:
#line 858 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].w.yg1;
	}
    break;
case 61:
#line 865 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    yyval.dval = g[whichgraph].w.yg2;
	}
    break;
case 62:
#line 872 "pars.yacc"
{
	    double vx, vy;
            get_page_viewport(&vx, &vy);
            yyval.dval = vx;
	}
    break;
case 63:
#line 877 "pars.yacc"
{
	    double vx, vy;
            get_page_viewport(&vx, &vy);
            yyval.dval = vy;
	}
    break;
case 64:
#line 882 "pars.yacc"
{
	    yyval.dval = yyvsp[-1].dval;
	}
    break;
case 65:
#line 885 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].dval + yyvsp[0].dval;
	}
    break;
case 66:
#line 888 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].dval - yyvsp[0].dval;
	}
    break;
case 67:
#line 891 "pars.yacc"
{
	    yyval.dval = -yyvsp[0].dval;
	}
    break;
case 68:
#line 894 "pars.yacc"
{
	    yyval.dval = yyvsp[0].dval;
	}
    break;
case 69:
#line 897 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].dval * yyvsp[0].dval;
	}
    break;
case 70:
#line 901 "pars.yacc"
{
	    if (yyvsp[0].dval != 0.0) {
		yyval.dval = yyvsp[-2].dval / yyvsp[0].dval;
	    } else {
		yyerror("Divide by zero");
		return 1;
	    }
	}
    break;
case 71:
#line 909 "pars.yacc"
{
	    if (yyvsp[0].dval != 0.0) {
		yyval.dval = fmod(yyvsp[-2].dval, yyvsp[0].dval);
	    } else {
		yyerror("Divide by zero");
		return 1;
	    }
	}
    break;
case 72:
#line 917 "pars.yacc"
{
	    if (yyvsp[-2].dval < 0 && rint(yyvsp[0].dval) != yyvsp[0].dval) {
		yyerror("Negative value raised to non-integer power");
		return 1;
            } else if (yyvsp[-2].dval == 0.0 && yyvsp[0].dval <= 0.0) {
		yyerror("Zero raised to non-positive power");
		return 1;
            } else {
                yyval.dval = pow(yyvsp[-2].dval, yyvsp[0].dval);
            }
	}
    break;
case 73:
#line 928 "pars.yacc"
{
	    yyval.dval = yyvsp[-4].dval ? yyvsp[-2].dval : yyvsp[0].dval;
	}
    break;
case 74:
#line 931 "pars.yacc"
{
	   yyval.dval = (yyvsp[-2].dval > yyvsp[0].dval);
	}
    break;
case 75:
#line 934 "pars.yacc"
{
	   yyval.dval = (yyvsp[-2].dval < yyvsp[0].dval);
	}
    break;
case 76:
#line 937 "pars.yacc"
{
	   yyval.dval = (yyvsp[-2].dval <= yyvsp[0].dval);
	}
    break;
case 77:
#line 940 "pars.yacc"
{
	   yyval.dval = (yyvsp[-2].dval >= yyvsp[0].dval);
	}
    break;
case 78:
#line 943 "pars.yacc"
{
	   yyval.dval = (yyvsp[-2].dval == yyvsp[0].dval);
	}
    break;
case 79:
#line 946 "pars.yacc"
{
	    yyval.dval = (yyvsp[-2].dval != yyvsp[0].dval);
	}
    break;
case 80:
#line 949 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].dval && yyvsp[0].dval;
	}
    break;
case 81:
#line 952 "pars.yacc"
{
	    yyval.dval = yyvsp[-2].dval || yyvsp[0].dval;
	}
    break;
case 82:
#line 955 "pars.yacc"
{
	    yyval.dval = !(yyvsp[0].dval);
	}
    break;
case 83:
#line 960 "pars.yacc"
{
            yyval.dval = yyvsp[0].dval;
        }
    break;
case 84:
#line 963 "pars.yacc"
{
            double jul;
            Dates_format dummy;
            if (parse_date(yyvsp[0].sval, get_date_hint(), FALSE, &jul, &dummy)
                == RETURN_SUCCESS) {
                xfree(yyvsp[0].sval);
                yyval.dval = jul;
            } else {
                xfree(yyvsp[0].sval);
		yyerror("Invalid date");
		return 1;
            }
        }
    break;
case 85:
#line 978 "pars.yacc"
{
            yyval.dval = yyvsp[0].dval;
        }
    break;
case 86:
#line 981 "pars.yacc"
{
            double jul;
            Dates_format dummy;
            if (parse_date(yyvsp[0].sval, get_date_hint(), TRUE, &jul, &dummy)
                == RETURN_SUCCESS) {
                xfree(yyvsp[0].sval);
                yyval.dval = jul;
            } else {
                xfree(yyvsp[0].sval);
		yyerror("Invalid date");
		return 1;
            }
        }
    break;
case 87:
#line 996 "pars.yacc"
{
	    int itmp = rint(yyvsp[0].dval);
            if (fabs(itmp - yyvsp[0].dval) > 1.e-6) {
		yyerror("Non-integer value supplied for integer");
		return 1;
            }
            yyval.ival = itmp;
        }
    break;
case 88:
#line 1006 "pars.yacc"
{
            if (yyvsp[0].ival < 0) {
		yyerror("Negative value supplied for non-negative");
		return 1;
            }
            yyval.ival = yyvsp[0].ival;
	}
    break;
case 89:
#line 1015 "pars.yacc"
{
	    int itmp = yyvsp[-1].ival - index_shift;
            if (itmp < 0) {
		yyerror("Negative index");
		return 1;
            }
            yyval.ival = itmp;
	}
    break;
case 90:
#line 1027 "pars.yacc"
{
            yyval.vrbl = yyvsp[0].vrbl;
	}
    break;
case 91:
#line 1031 "pars.yacc"
{
	    double *ptr = getcol(vasgn_gno, vasgn_setno, yyvsp[0].ival);
            yyval.vrbl = &freelist[fcnt++];
            yyval.vrbl->type = GRARR_SET;
            yyval.vrbl->data = ptr;
            if (ptr == NULL) {
                errmsg("NULL variable - check set type");
                return 1;
            } else {
                yyval.vrbl->length = getsetlength(vasgn_gno, vasgn_setno);
            }
	}
    break;
case 92:
#line 1044 "pars.yacc"
{
	    double *ptr = getcol(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].ival);
            yyval.vrbl = &freelist[fcnt++];
            yyval.vrbl->type = GRARR_SET;
            yyval.vrbl->data = ptr;
            if (ptr == NULL) {
                errmsg("NULL variable - check set type");
                return 1;
            } else {
                yyval.vrbl->length = getsetlength(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno);
            }
	}
    break;
case 93:
#line 1060 "pars.yacc"
{
            yyval.vrbl = yyvsp[0].vrbl;
	}
    break;
case 94:
#line 1064 "pars.yacc"
{
            int start = yyvsp[-3].ival - index_shift, stop = yyvsp[-1].ival - index_shift;
            if (start < 0 || stop < start || stop >= yyvsp[-5].vrbl->length) {
		yyerror("Invalid index range");
            } else {
                int len = stop - start + 1;
	        double *ptr = xmalloc(len*SIZEOF_DOUBLE);
                if (yyval.vrbl->data == NULL) {
                    yyerror("Not enough memory");
                } else {
                    int i;
                    yyval.vrbl = &freelist[fcnt++];
	            yyval.vrbl->data = ptr;
                    yyval.vrbl->length = len;
                    yyval.vrbl->type = GRARR_TMP;
                    for (i = 0; i < len; i++) {
                        yyval.vrbl->data[i] = yyvsp[-5].vrbl->data[i + yyvsp[-3].ival];
                    }
                }
            }
	}
    break;
case 95:
#line 1086 "pars.yacc"
{
            int len = yyvsp[-1].ival;
            if (len < 1) {
                yyerror("npoints must be > 0");
            } else {
                double *ptr = allocate_index_data(len);
                if (ptr == NULL) {
                    errmsg("Malloc failed");
                    return 1;
                } else {
                    yyval.vrbl = &freelist[fcnt++];
                    yyval.vrbl->type = GRARR_TMP;
                    yyval.vrbl->data = ptr;
                    yyval.vrbl->length = len;
                }
            }
	}
    break;
case 96:
#line 1104 "pars.yacc"
{
            int len = yyvsp[-1].ival;
            if (len < 2) {
                yyerror("npoints must be > 1");
            } else {
                double *ptr = allocate_mesh(yyvsp[-5].dval, yyvsp[-3].dval, len);
                if (ptr == NULL) {
                    errmsg("Malloc failed");
                    return 1;
                } else {
                    yyval.vrbl = &freelist[fcnt++];
                    yyval.vrbl->type = GRARR_TMP;
                    yyval.vrbl->data = ptr;
                    yyval.vrbl->length = len;
                }
            }
	}
    break;
case 97:
#line 1122 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    yyval.vrbl->data = xmalloc(yyvsp[-1].ival*SIZEOF_DOUBLE);
            if (yyval.vrbl->data == NULL) {
                errmsg("Not enough memory");
                return 1;
            } else {
                yyval.vrbl->length = yyvsp[-1].ival;
                yyval.vrbl->type = GRARR_TMP;
            }
            for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = drand48();
	    }
	}
    break;
case 98:
#line 1138 "pars.yacc"
{
	    int rtype, i, len;
            char *rarray;
            
            rtype = RESTRICT_REG0 + yyvsp[-3].ival;
            
	    if (get_restriction_array(yyvsp[-1].trgt->gno, yyvsp[-1].trgt->setno,
                rtype, FALSE, &rarray) != RETURN_SUCCESS) {
                errmsg("Error in region evaluation");
                return 1;
	    }

            len = getsetlength(yyvsp[-1].trgt->gno, yyvsp[-1].trgt->setno);
            yyval.vrbl = &freelist[fcnt++];
	    yyval.vrbl->data = xmalloc(len*SIZEOF_DOUBLE);
            if (yyval.vrbl->data == NULL) {
                errmsg("Not enough memory");
                return 1;
            } else {
                yyval.vrbl->length = len;
                yyval.vrbl->type = GRARR_TMP;
            }
            for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = rarray[i];
	    }
            
            xfree(rarray);
	}
    break;
case 99:
#line 1167 "pars.yacc"
{
            int i;
            yyval.vrbl = &freelist[fcnt++];
            copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 1; i < yyval.vrbl->length; i++) {
                yyval.vrbl->data[i] += yyval.vrbl->data[i - 1];
            }
	}
    break;
case 100:
#line 1177 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;
	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-3].ival].data)) ((int) (yyvsp[-1].vrbl->data[i]));
	    }
	}
    break;
case 101:
#line 1187 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;
	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-3].ival].data)) ((yyvsp[-1].vrbl->data[i]));
	    }
	}
    break;
case 102:
#line 1197 "pars.yacc"
{
	    int i;
	    if (yyvsp[-3].vrbl->length != yyvsp[-1].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-3].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            
	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].vrbl->data[i], yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 103:
#line 1212 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            
	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].dval, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 104:
#line 1223 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-3].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            
	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].vrbl->data[i], yyvsp[-1].dval);
	    }
	}
    break;
case 105:
#line 1234 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-5].ival].data)) (yyvsp[-3].ival, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 106:
#line 1245 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-7].ival].data)) (yyvsp[-5].ival, yyvsp[-3].ival, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 107:
#line 1256 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-7].ival].data)) (yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 108:
#line 1267 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-9].ival].data)) (yyvsp[-7].dval, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 109:
#line 1278 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-11].ival].data)) (yyvsp[-9].dval, yyvsp[-7].dval, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 110:
#line 1289 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = ((ParserFnc) (key[yyvsp[-13].ival].data)) (yyvsp[-11].dval, yyvsp[-9].dval, yyvsp[-7].dval, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].vrbl->data[i]);
	    }
	}
    break;
case 111:
#line 1300 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] + yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 112:
#line 1315 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] + yyvsp[0].dval;
	    }
	}
    break;
case 113:
#line 1326 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].dval + yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 114:
#line 1337 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] - yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 115:
#line 1352 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] - yyvsp[0].dval;
	    }
	}
    break;
case 116:
#line 1363 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].dval - yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 117:
#line 1374 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] * yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 118:
#line 1389 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] * yyvsp[0].dval;
	    }
	}
    break;
case 119:
#line 1400 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].dval * yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 120:
#line 1411 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		if (yyvsp[0].vrbl->data[i] == 0.0) {
                    errmsg("Divide by zero");
                    return 1;
                }
                yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] / yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 121:
#line 1430 "pars.yacc"
{
	    int i;
	    if (yyvsp[0].dval == 0.0) {
                errmsg("Divide by zero");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] / yyvsp[0].dval;
	    }
	}
    break;
case 122:
#line 1445 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		if (yyvsp[0].vrbl->data[i] == 0.0) {
                    errmsg("Divide by zero");
                    return 1;
                }
		yyval.vrbl->data[i] = yyvsp[-2].dval / yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 123:
#line 1460 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		if (yyvsp[0].vrbl->data[i] == 0.0) {
                    errmsg("Divide by zero");
                    return 1;
                } else {
                    yyval.vrbl->data[i] = fmod(yyvsp[-2].vrbl->data[i], yyvsp[0].vrbl->data[i]);
                }
	    }
	}
    break;
case 124:
#line 1480 "pars.yacc"
{
	    int i;
	    if (yyvsp[0].dval == 0.0) {
                errmsg("Divide by zero");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = fmod(yyvsp[-2].vrbl->data[i], yyvsp[0].dval);
	    }
	}
    break;
case 125:
#line 1495 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		if (yyvsp[0].vrbl->data[i] == 0.0) {
                    errmsg("Divide by zero");
                    return 1;
                } else {
		    yyval.vrbl->data[i] = fmod(yyvsp[-2].dval, yyvsp[0].vrbl->data[i]);
                }
	    }
	}
    break;
case 126:
#line 1511 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
	        if (yyvsp[-2].vrbl->data[i] < 0 && rint(yyvsp[0].vrbl->data[i]) != yyvsp[0].vrbl->data[i]) {
	            yyerror("Negative value raised to non-integer power");
	            return 1;
                } else if (yyvsp[-2].vrbl->data[i] == 0.0 && yyvsp[0].vrbl->data[i] <= 0.0) {
	            yyerror("Zero raised to non-positive power");
	            return 1;
                } else {
                    yyval.vrbl->data[i] = pow(yyvsp[-2].vrbl->data[i], yyvsp[0].vrbl->data[i]);
                }
	    }
	}
    break;
case 127:
#line 1534 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
	        if (yyvsp[-2].vrbl->data[i] < 0 && rint(yyvsp[0].dval) != yyvsp[0].dval) {
	            yyerror("Negative value raised to non-integer power");
	            return 1;
                } else if (yyvsp[-2].vrbl->data[i] == 0.0 && yyvsp[0].dval <= 0.0) {
	            yyerror("Zero raised to non-positive power");
	            return 1;
                } else {
                    yyval.vrbl->data[i] = pow(yyvsp[-2].vrbl->data[i], yyvsp[0].dval);
                }
	    }
	}
    break;
case 128:
#line 1553 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
	        if (yyvsp[-2].dval < 0 && rint(yyvsp[0].vrbl->data[i]) != yyvsp[0].vrbl->data[i]) {
	            yyerror("Negative value raised to non-integer power");
	            return 1;
                } else if (yyvsp[-2].dval == 0.0 && yyvsp[0].vrbl->data[i] <= 0.0) {
	            yyerror("Zero raised to non-positive power");
	            return 1;
                } else {
                    yyval.vrbl->data[i] = pow(yyvsp[-2].dval, yyvsp[0].vrbl->data[i]);
                }
	    }
	}
    break;
case 129:
#line 1572 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;
	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-1].vrbl->data[i] * ((ParserFnc) (key[yyvsp[0].ival].data)) ();
	    }
	}
    break;
case 130:
#line 1581 "pars.yacc"
{
            int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-4].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = CAST_DBL_TO_BOOL(yyvsp[-4].vrbl->data[i]) ? yyvsp[-2].dval : yyvsp[0].dval;
            }
	}
    break;
case 131:
#line 1590 "pars.yacc"
{
            int i;
	    if (yyvsp[-4].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-4].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = CAST_DBL_TO_BOOL(yyvsp[-4].vrbl->data[i]) ? yyvsp[-2].dval : yyvsp[0].vrbl->data[i];
            }
	}
    break;
case 132:
#line 1603 "pars.yacc"
{
            int i;
	    if (yyvsp[-4].vrbl->length != yyvsp[-2].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-4].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = CAST_DBL_TO_BOOL(yyvsp[-4].vrbl->data[i]) ? yyvsp[-2].vrbl->data[i] : yyvsp[0].dval;
            }
	}
    break;
case 133:
#line 1616 "pars.yacc"
{
            int i;
	    if (yyvsp[-4].vrbl->length != yyvsp[0].vrbl->length || yyvsp[-4].vrbl->length != yyvsp[-2].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-4].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = CAST_DBL_TO_BOOL(yyvsp[-4].vrbl->data[i]) ? yyvsp[-2].vrbl->data[i] : yyvsp[0].vrbl->data[i];
            }
	}
    break;
case 134:
#line 1630 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] || yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 135:
#line 1645 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] || yyvsp[0].dval;
	    }
	}
    break;
case 136:
#line 1656 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].dval || yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 137:
#line 1667 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] && yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 138:
#line 1682 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].vrbl->data[i] && yyvsp[0].dval;
	    }
	}
    break;
case 139:
#line 1693 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = yyvsp[-2].dval && yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 140:
#line 1704 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] > yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 141:
#line 1719 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] > yyvsp[0].dval);
	    }
	}
    break;
case 142:
#line 1730 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].dval > yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 143:
#line 1741 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] < yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 144:
#line 1756 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] < yyvsp[0].dval);
	    }
	}
    break;
case 145:
#line 1767 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].dval < yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 146:
#line 1778 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] >= yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 147:
#line 1793 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] >= yyvsp[0].dval);
	    }
	}
    break;
case 148:
#line 1804 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].dval >= yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 149:
#line 1815 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] <= yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 150:
#line 1830 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] <= yyvsp[0].dval);
	    }
	}
    break;
case 151:
#line 1841 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].dval <= yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 152:
#line 1852 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] == yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 153:
#line 1867 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] == yyvsp[0].dval);
	    }
	}
    break;
case 154:
#line 1878 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].dval == yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 155:
#line 1889 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Can't operate on vectors of different lengths");
                return 1;
            }
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] != yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 156:
#line 1904 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-2].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].vrbl->data[i] != yyvsp[0].dval);
	    }
	}
    break;
case 157:
#line 1915 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;

	    for (i = 0; i < yyval.vrbl->length; i++) {
		yyval.vrbl->data[i] = (yyvsp[-2].dval != yyvsp[0].vrbl->data[i]);
	    }
	}
    break;
case 158:
#line 1926 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = !yyvsp[0].vrbl->data[i];
            }
	}
    break;
case 159:
#line 1936 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[-1].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = yyvsp[-1].vrbl->data[i];
            }
	}
    break;
case 160:
#line 1945 "pars.yacc"
{
	    int i;
            yyval.vrbl = &freelist[fcnt++];
	    copy_vrbl(yyval.vrbl, yyvsp[0].vrbl);
            yyval.vrbl->type = GRARR_TMP;
            for (i = 0; i < yyval.vrbl->length; i++) { 
                yyval.vrbl->data[i] = - yyvsp[0].vrbl->data[i];
            }
	}
    break;
case 161:
#line 1959 "pars.yacc"
{
	    *(yyvsp[-2].dptr) = yyvsp[0].dval;
	}
    break;
case 162:
#line 1963 "pars.yacc"
{
	    nonl_parms[yyvsp[-2].ival].value = yyvsp[0].dval;
	}
    break;
case 163:
#line 1967 "pars.yacc"
{
	    nonl_parms[yyvsp[-2].ival].max = yyvsp[0].dval;
	}
    break;
case 164:
#line 1971 "pars.yacc"
{
	    nonl_parms[yyvsp[-2].ival].min = yyvsp[0].dval;
	}
    break;
case 165:
#line 1975 "pars.yacc"
{
	    if (yyvsp[-2].ival >= yyvsp[-3].vrbl->length) {
		yyerror("Access beyond array bounds");
		return 1;
            }
            yyvsp[-3].vrbl->data[yyvsp[-2].ival] = yyvsp[0].dval;
	}
    break;
case 166:
#line 1986 "pars.yacc"
{
            target tgt;
            switch (yyvsp[0].vrbl->type) {
            case GRARR_SET:
                if (find_set_bydata(yyvsp[0].vrbl->data, &tgt) == RETURN_SUCCESS) {
                    vasgn_gno   = tgt.gno;
                    vasgn_setno = tgt.setno;
                } else {
                    errmsg("Internal error");
		    return 1;
                }
                break;
            case GRARR_VEC:
                vasgn_gno   = -1;
                vasgn_setno = -1;
                break;
            default:
                /* It can NOT be a tmp array on the left side! */
                errmsg("Internal error");
	        return 1;
            }
            yyval.vrbl = yyvsp[0].vrbl;
        }
    break;
case 167:
#line 2013 "pars.yacc"
{
	    int i;
	    if (yyvsp[-2].vrbl->length != yyvsp[0].vrbl->length) {
                errmsg("Left and right vectors are of different lengths");
                return 1;
            }
	    for (i = 0; i < yyvsp[-2].vrbl->length; i++) {
	        yyvsp[-2].vrbl->data[i] = yyvsp[0].vrbl->data[i];
	    }
	}
    break;
case 168:
#line 2024 "pars.yacc"
{
	    int i;
	    for (i = 0; i < yyvsp[-2].vrbl->length; i++) {
	        yyvsp[-2].vrbl->data[i] = yyvsp[0].dval;
	    }
	}
    break;
case 169:
#line 2034 "pars.yacc"
{
	    symtab_entry tmpkey;
            double *var;
            
            var = xmalloc(SIZEOF_DOUBLE);
            *var = 0.0;
            
	    tmpkey.s = yyvsp[0].sval;
	    tmpkey.type = KEY_VAR;
	    tmpkey.data = (void *) var;
	    if (addto_symtab(tmpkey) != RETURN_SUCCESS) {
	        yyerror("Keyword already exists");
	    }

            xfree(yyvsp[0].sval);
        }
    break;
case 170:
#line 2051 "pars.yacc"
{
	    if (define_parser_arr(yyvsp[-2].sval) == NULL) {
	        yyerror("Keyword already exists");
	    }

            xfree(yyvsp[-2].sval);
        }
    break;
case 171:
#line 2059 "pars.yacc"
{
	    grarr *var;
            if ((var = define_parser_arr(yyvsp[-3].sval)) == NULL) {
	        yyerror("Keyword already exists");
	    } else {
                realloc_vrbl(var, yyvsp[-1].ival);
            }

            xfree(yyvsp[-3].sval);
        }
    break;
case 172:
#line 2070 "pars.yacc"
{
            undefine_parser_var((void *) yyvsp[0].dptr);
            xfree(yyvsp[0].dptr);
        }
    break;
case 173:
#line 2075 "pars.yacc"
{
            realloc_vrbl(yyvsp[0].vrbl, 0);
            undefine_parser_var((void *) yyvsp[0].vrbl);
            xfree(yyvsp[0].vrbl);
        }
    break;
case 174:
#line 2080 "pars.yacc"
{
	    int position;

	    lowtoupper(yyvsp[0].sval);
	    if ((position = findf(key, yyvsp[0].sval)) >= 0) {
	        symtab_entry tmpkey;
		tmpkey.s = yyvsp[-1].sval;
		tmpkey.type = key[position].type;
		tmpkey.data = key[position].data;
		if (addto_symtab(tmpkey) != RETURN_SUCCESS) {
		    yyerror("Keyword already exists");
		}
	    } else {
	        yyerror("Aliased keyword not found");
	    }
	    xfree(yyvsp[-1].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 175:
#line 2098 "pars.yacc"
{
	    alias_force = yyvsp[0].ival;
	}
    break;
case 176:
#line 2101 "pars.yacc"
{
	    if (load_module(yyvsp[0].sval, yyvsp[-4].sval, yyvsp[-4].sval, yyvsp[-2].ival) != 0) {
	        yyerror("DL module load failed");
	    }
	    xfree(yyvsp[-4].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 177:
#line 2108 "pars.yacc"
{
	    if (load_module(yyvsp[-2].sval, yyvsp[-6].sval, yyvsp[0].sval, yyvsp[-4].ival) != 0) {
	        yyerror("DL module load failed");
	    }
	    xfree(yyvsp[-6].sval);
	    xfree(yyvsp[-2].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 178:
#line 2119 "pars.yacc"
{
	    rg[yyvsp[-1].ival].active = yyvsp[0].ival;
	}
    break;
case 179:
#line 2122 "pars.yacc"
{
	    rg[yyvsp[-2].ival].type = yyvsp[0].ival;
	}
    break;
case 180:
#line 2125 "pars.yacc"
{
	    rg[yyvsp[-1].ival].color = yyvsp[0].ival;
	}
    break;
case 181:
#line 2128 "pars.yacc"
{
	    rg[yyvsp[-1].ival].lines = yyvsp[0].ival;
	}
    break;
case 182:
#line 2131 "pars.yacc"
{
	    rg[yyvsp[-1].ival].linew = yyvsp[0].dval;
	}
    break;
case 183:
#line 2135 "pars.yacc"
{
	    rg[yyvsp[-8].ival].x1 = yyvsp[-6].dval;
	    rg[yyvsp[-8].ival].y1 = yyvsp[-4].dval;
	    rg[yyvsp[-8].ival].x2 = yyvsp[-2].dval;
	    rg[yyvsp[-8].ival].y2 = yyvsp[0].dval;
	}
    break;
case 184:
#line 2142 "pars.yacc"
{
	    rg[yyvsp[-4].ival].x = xrealloc(rg[yyvsp[-4].ival].x, (rg[yyvsp[-4].ival].n + 1) * SIZEOF_DOUBLE);
	    rg[yyvsp[-4].ival].y = xrealloc(rg[yyvsp[-4].ival].y, (rg[yyvsp[-4].ival].n + 1) * SIZEOF_DOUBLE);
	    rg[yyvsp[-4].ival].x[rg[yyvsp[-4].ival].n] = yyvsp[-2].dval;
	    rg[yyvsp[-4].ival].y[rg[yyvsp[-4].ival].n] = yyvsp[0].dval;
	    rg[yyvsp[-4].ival].n++;
	}
    break;
case 185:
#line 2149 "pars.yacc"
{
	    rg[yyvsp[-2].ival].linkto = yyvsp[0].ival;
	}
    break;
case 186:
#line 2156 "pars.yacc"
{
            if (set_project_version(yyvsp[0].ival) != RETURN_SUCCESS) {
                errmsg("Project version is newer than software!");
            }
            if (get_project_version() < 50001) {
                map_fonts(FONT_MAP_ACEGR);
            } else {
                map_fonts(FONT_MAP_DEFAULT);
            }
        }
    break;
case 187:
#line 2166 "pars.yacc"
{
            set_page_dimensions(yyvsp[-2].ival, yyvsp[0].ival, TRUE);
        }
    break;
case 188:
#line 2169 "pars.yacc"
{
            set_page_dimensions(yyvsp[-2].ival, yyvsp[0].ival, FALSE);
        }
    break;
case 189:
#line 2172 "pars.yacc"
{
            int device_id;
            Device_entry dev;
            
            device_id = get_device_by_name(yyvsp[-5].sval);
            xfree(yyvsp[-5].sval);
            if (device_id < 0) {
                yyerror("Unknown device");
            } else {
                dev = get_device_props(device_id);
                dev.pg.width =  (long) (yyvsp[-2].ival*dev.pg.dpi/72);
                dev.pg.height = (long) (yyvsp[0].ival*dev.pg.dpi/72);
                set_device_props(device_id, dev);
            }
        }
    break;
case 190:
#line 2187 "pars.yacc"
{
            int device_id;
            Device_entry dev;
            
            device_id = get_device_by_name(yyvsp[-2].sval);
            if (device_id < 0) {
                yyerror("Unknown device");
            } else {
                dev = get_device_props(device_id);
                dev.pg.dpi = yyvsp[0].dval;
                set_device_props(device_id, dev);
            }
            xfree(yyvsp[-2].sval);
        }
    break;
case 191:
#line 2201 "pars.yacc"
{
            int device_id;
            Device_entry dev;
            
            device_id = get_device_by_name(yyvsp[-3].sval);
            if (device_id < 0) {
                yyerror("Unknown device");
            } else {
                dev = get_device_props(device_id);
                dev.fontaa = yyvsp[0].ival;
                set_device_props(device_id, dev);
            }
            xfree(yyvsp[-3].sval);
        }
    break;
case 192:
#line 2215 "pars.yacc"
{
            int device_id;
            Device_entry dev;
            
            device_id = get_device_by_name(yyvsp[-2].sval);
            if (device_id < 0) {
                yyerror("Unknown device");
            } else {
                dev = get_device_props(device_id);
                dev.devfonts = yyvsp[0].ival;
                set_device_props(device_id, dev);
            }
            xfree(yyvsp[-2].sval);
        }
    break;
case 193:
#line 2229 "pars.yacc"
{
            int device_id;
            
            device_id = get_device_by_name(yyvsp[-2].sval);
            if (device_id < 0) {
                yyerror("Unknown device");
            } else {
                if (parse_device_options(device_id, yyvsp[0].sval) != 
                                                        RETURN_SUCCESS) {
                    yyerror("Incorrect device option string");
                }
            }
            xfree(yyvsp[-2].sval);
            xfree(yyvsp[0].sval);
        }
    break;
case 194:
#line 2244 "pars.yacc"
{
            set_printer_by_name(yyvsp[0].sval);
            xfree(yyvsp[0].sval);
        }
    break;
case 195:
#line 2248 "pars.yacc"
{
            set_ref_date(yyvsp[0].dval);
	}
    break;
case 196:
#line 2251 "pars.yacc"
{
            allow_two_digits_years(yyvsp[0].ival);
	}
    break;
case 197:
#line 2254 "pars.yacc"
{
            set_wrap_year(yyvsp[0].ival);
	}
    break;
case 198:
#line 2257 "pars.yacc"
{
	    setbgcolor(yyvsp[0].ival);
	}
    break;
case 199:
#line 2260 "pars.yacc"
{
	    setbgfill(yyvsp[0].ival);
	}
    break;
case 200:
#line 2263 "pars.yacc"
{
	    scroll_proc((int) yyvsp[-1].dval);
	}
    break;
case 201:
#line 2266 "pars.yacc"
{
	    scrollinout_proc((int) yyvsp[-1].dval);
	}
    break;
case 202:
#line 2269 "pars.yacc"
{
	    scrolling_islinked = yyvsp[0].ival;
	}
    break;
case 203:
#line 2274 "pars.yacc"
{
	    add_world(whichgraph, yyvsp[-6].dval, yyvsp[-4].dval, yyvsp[-2].dval, yyvsp[0].dval);
	}
    break;
case 204:
#line 2278 "pars.yacc"
{
            timer_delay = yyvsp[0].ival;
	}
    break;
case 205:
#line 2282 "pars.yacc"
{
	    target_set = *(yyvsp[0].trgt);
	    set_parser_setno(target_set.gno, target_set.setno);
	}
    break;
case 206:
#line 2286 "pars.yacc"
{
	    set_parser_gno(yyvsp[0].ival);
	}
    break;
case 207:
#line 2289 "pars.yacc"
{
	    set_parser_setno(yyvsp[0].trgt->gno, yyvsp[0].trgt->setno);
	}
    break;
case 208:
#line 2294 "pars.yacc"
{
	    set_hotlink(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno, 1, yyvsp[0].sval, yyvsp[-1].ival);
	    xfree(yyvsp[0].sval);
	}
    break;
case 209:
#line 2298 "pars.yacc"
{
	    set_hotlink(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].ival, NULL, 0);
	}
    break;
case 210:
#line 2303 "pars.yacc"
{
	    curbox = next_box();
	}
    break;
case 211:
#line 2306 "pars.yacc"
{
            int no = yyvsp[0].ival;
            if (is_valid_box(no) ||
                realloc_boxes(no + 1) == RETURN_SUCCESS) {
                curbox = no;
            }
	}
    break;
case 212:
#line 2313 "pars.yacc"
{
	    if (!is_valid_box(curbox)) {
                yyerror("Box not active");
	    } else {
	        boxes[curbox].active = yyvsp[0].ival;
            }
	}
    break;
case 213:
#line 2320 "pars.yacc"
{
	    if (!is_valid_box(curbox)) {
                yyerror("Box not active");
	    } else {
	        boxes[curbox].gno = yyvsp[0].ival;
            }
	}
    break;
case 214:
#line 2327 "pars.yacc"
{
	    if (!is_valid_box(curbox)) {
                yyerror("Box not active");
	    } else {
		boxes[curbox].x1 = yyvsp[-6].dval;
		boxes[curbox].y1 = yyvsp[-4].dval;
		boxes[curbox].x2 = yyvsp[-2].dval;
		boxes[curbox].y2 = yyvsp[0].dval;
	    }
	}
    break;
case 215:
#line 2337 "pars.yacc"
{
	    box_loctype = yyvsp[0].ival;
	}
    break;
case 216:
#line 2340 "pars.yacc"
{
	    box_lines = yyvsp[0].ival;
	}
    break;
case 217:
#line 2343 "pars.yacc"
{
	    box_linew = yyvsp[0].dval;
	}
    break;
case 218:
#line 2346 "pars.yacc"
{
	    box_color = yyvsp[0].ival;
	}
    break;
case 219:
#line 2349 "pars.yacc"
{
	    box_fillcolor = yyvsp[0].ival;
	}
    break;
case 220:
#line 2352 "pars.yacc"
{
	    box_fillpat = yyvsp[0].ival;
	}
    break;
case 221:
#line 2355 "pars.yacc"
{
	    if (!is_valid_box(curbox)) {
                yyerror("Box not active");
	    } else {
		boxes[curbox].lines = box_lines;
		boxes[curbox].linew = box_linew;
		boxes[curbox].color = box_color;
		if (get_project_version() <= 40102) {
                    switch (filltype_obs) {
                    case COLOR:
                        boxes[curbox].fillcolor = box_fillcolor;
		        boxes[curbox].fillpattern = 1;
                        break;
                    case PATTERN:
                        boxes[curbox].fillcolor = 1;
		        boxes[curbox].fillpattern = box_fillpat;
                        break;
                    default: /* NONE */
                        boxes[curbox].fillcolor = box_fillcolor;
		        boxes[curbox].fillpattern = 0;
                        break;
                    }
		} else {
                    boxes[curbox].fillcolor = box_fillcolor;
		    boxes[curbox].fillpattern = box_fillpat;
                }
                boxes[curbox].loctype = box_loctype;
	    }
	}
    break;
case 222:
#line 2386 "pars.yacc"
{
		curellipse = next_ellipse();
	}
    break;
case 223:
#line 2389 "pars.yacc"
{
            int no = yyvsp[0].ival;
            if (is_valid_ellipse(no) ||
                realloc_ellipses(no + 1) == RETURN_SUCCESS) {
                curellipse = no;
            }
	}
    break;
case 224:
#line 2396 "pars.yacc"
{
	    if (!is_valid_ellipse(curellipse)) {
                yyerror("Ellipse not active");
	    } else {
	        ellip[curellipse].active = yyvsp[0].ival;
            }
	}
    break;
case 225:
#line 2403 "pars.yacc"
{
	    if (!is_valid_ellipse(curellipse)) {
                yyerror("Ellipse not active");
	    } else {
	        ellip[curellipse].gno = yyvsp[0].ival;
            }
	}
    break;
case 226:
#line 2410 "pars.yacc"
{
	    if (!is_valid_ellipse(curellipse)) {
                yyerror("Ellipse not active");
	    } else {
		ellip[curellipse].x1 = yyvsp[-6].dval;
		ellip[curellipse].y1 = yyvsp[-4].dval;
		ellip[curellipse].x2 = yyvsp[-2].dval;
		ellip[curellipse].y2 = yyvsp[0].dval;
	    }
	}
    break;
case 227:
#line 2420 "pars.yacc"
{
	    ellipse_loctype = yyvsp[0].ival;
	}
    break;
case 228:
#line 2423 "pars.yacc"
{
	    ellipse_lines = yyvsp[0].ival;
	}
    break;
case 229:
#line 2426 "pars.yacc"
{
	    ellipse_linew = yyvsp[0].dval;
	}
    break;
case 230:
#line 2429 "pars.yacc"
{
	    ellipse_color = yyvsp[0].ival;
	}
    break;
case 231:
#line 2432 "pars.yacc"
{
	    ellipse_fillcolor = yyvsp[0].ival;
	}
    break;
case 232:
#line 2435 "pars.yacc"
{
	    ellipse_fillpat = yyvsp[0].ival;
	}
    break;
case 233:
#line 2438 "pars.yacc"
{
	    if (!is_valid_ellipse(curellipse)) {
                yyerror("Ellipse not active");
	    } else {
		ellip[curellipse].lines = ellipse_lines;
		ellip[curellipse].linew = ellipse_linew;
		ellip[curellipse].color = ellipse_color;
		if (get_project_version() <= 40102) {
                    switch (filltype_obs) {
                    case COLOR:
                        ellip[curellipse].fillcolor = ellipse_fillcolor;
		        ellip[curellipse].fillpattern = 1;
                        break;
                    case PATTERN:
                        ellip[curellipse].fillcolor = 1;
		        ellip[curellipse].fillpattern = ellipse_fillpat;
                        break;
                    default: /* NONE */
                        ellip[curellipse].fillcolor = ellipse_fillcolor;
		        ellip[curellipse].fillpattern = 0;
                        break;
                    }
		} else {
                    ellip[curellipse].fillcolor = ellipse_fillcolor;
		    ellip[curellipse].fillpattern = ellipse_fillpat;
                }
		ellip[curellipse].loctype = ellipse_loctype;
	    }
	}
    break;
case 234:
#line 2469 "pars.yacc"
{
	    curline = next_line();
	}
    break;
case 235:
#line 2472 "pars.yacc"
{
            int no = yyvsp[0].ival;
            if (is_valid_line(no) ||
                realloc_lines(no + 1) == RETURN_SUCCESS) {
                curline = no;
            }
	}
    break;
case 236:
#line 2479 "pars.yacc"
{
	    if (!is_valid_line(curline)) {
                yyerror("Line not active");
	    } else {
	        lines[curline].active = yyvsp[0].ival;
            }
	}
    break;
case 237:
#line 2486 "pars.yacc"
{
	    if (!is_valid_line(curline)) {
                yyerror("Line not active");
	    } else {
	        lines[curline].gno = yyvsp[0].ival;
            }
	}
    break;
case 238:
#line 2493 "pars.yacc"
{
	    if (!is_valid_line(curline)) {
                yyerror("Line not active");
	    } else {
	        lines[curline].x1 = yyvsp[-6].dval;
	        lines[curline].y1 = yyvsp[-4].dval;
	        lines[curline].x2 = yyvsp[-2].dval;
	        lines[curline].y2 = yyvsp[0].dval;
            }
	}
    break;
case 239:
#line 2503 "pars.yacc"
{
	    line_loctype = yyvsp[0].ival;
	}
    break;
case 240:
#line 2506 "pars.yacc"
{
	    line_linew = yyvsp[0].dval;
	}
    break;
case 241:
#line 2509 "pars.yacc"
{
	    line_lines = yyvsp[0].ival;
	}
    break;
case 242:
#line 2512 "pars.yacc"
{
	    line_color = yyvsp[0].ival;
	}
    break;
case 243:
#line 2515 "pars.yacc"
{
	    line_arrow_end = yyvsp[0].ival;
	}
    break;
case 244:
#line 2518 "pars.yacc"
{
	    line_asize = yyvsp[0].dval;
	}
    break;
case 245:
#line 2521 "pars.yacc"
{
	    line_atype = yyvsp[0].ival;
	}
    break;
case 246:
#line 2524 "pars.yacc"
{
	    line_a_dL_ff = yyvsp[-2].dval;
	    line_a_lL_ff = yyvsp[0].dval;
	}
    break;
case 247:
#line 2528 "pars.yacc"
{
	    if (!is_valid_line(curline)) {
                yyerror("Line not active");
	    } else {
	        lines[curline].lines = line_lines;
	        lines[curline].linew = line_linew;
	        lines[curline].color = line_color;
	        lines[curline].arrow_end = line_arrow_end;
	        lines[curline].arrow.length = line_asize;
	        lines[curline].arrow.type = line_atype;
	        lines[curline].arrow.dL_ff = line_a_dL_ff;
	        lines[curline].arrow.lL_ff = line_a_lL_ff;
	        lines[curline].loctype = line_loctype;
            }
	}
    break;
case 248:
#line 2545 "pars.yacc"
{
            curstring = next_string();
        }
    break;
case 249:
#line 2548 "pars.yacc"
{
            int no = yyvsp[0].ival;
            if (is_valid_string(no) ||
                realloc_strings(no + 1) == RETURN_SUCCESS) {
                curstring = no;
            }
        }
    break;
case 250:
#line 2555 "pars.yacc"
{
	    if (!is_valid_string(curstring)) {
                yyerror("String not active");
	    } else {
                pstr[curstring].active = yyvsp[0].ival;
            }
        }
    break;
case 251:
#line 2562 "pars.yacc"
{
	    if (!is_valid_string(curstring)) {
                yyerror("String not active");
	    } else {
                pstr[curstring].gno = yyvsp[0].ival;
            }
        }
    break;
case 252:
#line 2569 "pars.yacc"
{
	    if (!is_valid_string(curstring)) {
                yyerror("String not active");
	    } else {
	        pstr[curstring].x = yyvsp[-2].dval;
	        pstr[curstring].y = yyvsp[0].dval;
            }
	}
    break;
case 253:
#line 2577 "pars.yacc"
{
            string_loctype = yyvsp[0].ival;
        }
    break;
case 254:
#line 2580 "pars.yacc"
{
            string_color = yyvsp[0].ival;
        }
    break;
case 255:
#line 2583 "pars.yacc"
{
            string_rot = yyvsp[0].ival;
        }
    break;
case 256:
#line 2586 "pars.yacc"
{
            string_font = yyvsp[0].ival;
        }
    break;
case 257:
#line 2589 "pars.yacc"
{
            string_just = yyvsp[0].ival;
        }
    break;
case 258:
#line 2592 "pars.yacc"
{
            string_size = yyvsp[0].dval;
        }
    break;
case 259:
#line 2595 "pars.yacc"
{
	    if (!is_valid_string(curstring)) {
                yyerror("String not active");
	    } else {
	        set_plotstr_string(&pstr[curstring], yyvsp[0].sval);
	        pstr[curstring].color = string_color;
	        pstr[curstring].font = string_font;
	        pstr[curstring].just = string_just;
	        pstr[curstring].loctype = string_loctype;
	        pstr[curstring].rot = string_rot;
	        pstr[curstring].charsize = string_size;
            }
	    xfree(yyvsp[0].sval);
	}
    break;
case 260:
#line 2611 "pars.yacc"
{
            timestamp.active = yyvsp[0].ival;
        }
    break;
case 261:
#line 2614 "pars.yacc"
{
            timestamp.font = yyvsp[0].ival;
        }
    break;
case 262:
#line 2617 "pars.yacc"
{
            timestamp.charsize = yyvsp[0].dval;
        }
    break;
case 263:
#line 2620 "pars.yacc"
{
            timestamp.rot = yyvsp[0].ival;
        }
    break;
case 264:
#line 2623 "pars.yacc"
{
            timestamp.color = yyvsp[0].ival;
        }
    break;
case 265:
#line 2626 "pars.yacc"
{
	    timestamp.x = yyvsp[-2].dval;
	    timestamp.y = yyvsp[0].dval;
	}
    break;
case 266:
#line 2630 "pars.yacc"
{
	  set_plotstr_string(&timestamp, yyvsp[0].sval);
	  xfree(yyvsp[0].sval);
	}
    break;
case 267:
#line 2636 "pars.yacc"
{
	    grdefaults.lines = yyvsp[0].ival;
	}
    break;
case 268:
#line 2639 "pars.yacc"
{
	    grdefaults.linew = yyvsp[0].dval;
	}
    break;
case 269:
#line 2642 "pars.yacc"
{
	    grdefaults.color = yyvsp[0].ival;
	}
    break;
case 270:
#line 2645 "pars.yacc"
{
	    grdefaults.pattern = yyvsp[0].ival;
	}
    break;
case 271:
#line 2648 "pars.yacc"
{
	    grdefaults.charsize = yyvsp[0].dval;
	}
    break;
case 272:
#line 2651 "pars.yacc"
{
	    grdefaults.font = yyvsp[0].ival;
	}
    break;
case 273:
#line 2654 "pars.yacc"
{
	    grdefaults.symsize = yyvsp[0].dval;
	}
    break;
case 274:
#line 2657 "pars.yacc"
{
	    strcpy(sformat, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 275:
#line 2661 "pars.yacc"
{
	    if ((map_font_by_name(yyvsp[-2].sval, yyvsp[-4].ival) != RETURN_SUCCESS) && 
                (map_font_by_name(yyvsp[0].sval, yyvsp[-4].ival) != RETURN_SUCCESS)) {
                errmsg("Failed mapping a font");
            }
            xfree(yyvsp[-2].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 276:
#line 2669 "pars.yacc"
{
	    CMap_entry cmap;
            cmap.rgb.red   = yyvsp[-7].ival;
            cmap.rgb.green = yyvsp[-5].ival;
            cmap.rgb.blue  = yyvsp[-3].ival;
            cmap.ctype = COLOR_MAIN;
            cmap.cname = yyvsp[0].sval;
            if (store_color(yyvsp[-10].ival, cmap) == RETURN_FAILURE) {
                errmsg("Failed mapping a color");
            }
	    xfree(yyvsp[0].sval);
        }
    break;
case 277:
#line 2682 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].w.xg1 = yyvsp[-6].dval;
	    g[whichgraph].w.yg1 = yyvsp[-4].dval;
	    g[whichgraph].w.xg2 = yyvsp[-2].dval;
	    g[whichgraph].w.yg2 = yyvsp[0].dval;
	}
    break;
case 278:
#line 2692 "pars.yacc"
{
	    set_graph_znorm(whichgraph, yyvsp[0].dval);
	}
    break;
case 279:
#line 2695 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].v.xv1 = yyvsp[-6].dval;
	    g[whichgraph].v.yv1 = yyvsp[-4].dval;
	    g[whichgraph].v.xv2 = yyvsp[-2].dval;
	    g[whichgraph].v.yv2 = yyvsp[0].dval;
	}
    break;
case 280:
#line 2705 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    set_plotstr_string(&g[whichgraph].labs.title, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 281:
#line 2713 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].labs.title.font = yyvsp[0].ival;
	}
    break;
case 282:
#line 2720 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].labs.title.charsize = yyvsp[0].dval;
	}
    break;
case 283:
#line 2727 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].labs.title.color = yyvsp[0].ival;
	}
    break;
case 284:
#line 2734 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    set_plotstr_string(&g[whichgraph].labs.stitle, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 285:
#line 2742 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].labs.stitle.font = yyvsp[0].ival;
	}
    break;
case 286:
#line 2749 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].labs.stitle.charsize = yyvsp[0].dval;
	}
    break;
case 287:
#line 2756 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].labs.stitle.color = yyvsp[0].ival;
	}
    break;
case 288:
#line 2764 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].xscale = yyvsp[0].ival;
	}
    break;
case 289:
#line 2771 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].yscale = yyvsp[0].ival;
	}
    break;
case 290:
#line 2778 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].xinvert = yyvsp[0].ival;
	}
    break;
case 291:
#line 2785 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].yinvert = yyvsp[0].ival;
	}
    break;
case 292:
#line 2792 "pars.yacc"
{
            autoscale_onread = AUTOSCALE_NONE;
        }
    break;
case 293:
#line 2795 "pars.yacc"
{
            autoscale_onread = AUTOSCALE_X;
        }
    break;
case 294:
#line 2798 "pars.yacc"
{
            autoscale_onread = AUTOSCALE_Y;
        }
    break;
case 295:
#line 2801 "pars.yacc"
{
            autoscale_onread = AUTOSCALE_XY;
        }
    break;
case 296:
#line 2805 "pars.yacc"
{
            char *s;
            s = copy_string(NULL, get_project_description());
            s = concat_strings(s, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
            s = concat_strings(s, "\n");
            set_project_description(s);
            xfree(s);
	}
    break;
case 297:
#line 2814 "pars.yacc"
{
            set_project_description(NULL);
        }
    break;
case 298:
#line 2818 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.active = yyvsp[0].ival;
	}
    break;
case 299:
#line 2825 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.loctype = yyvsp[0].ival;
	}
    break;
case 300:
#line 2832 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
            g[whichgraph].l.vgap = yyvsp[0].ival;
	}
    break;
case 301:
#line 2839 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.hgap = yyvsp[0].ival;
	}
    break;
case 302:
#line 2846 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.len = yyvsp[0].ival;
	}
    break;
case 303:
#line 2853 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.invert = yyvsp[0].ival;
        }
    break;
case 304:
#line 2860 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.boxfillpen.color = yyvsp[0].ival;
        }
    break;
case 305:
#line 2867 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.boxfillpen.pattern = yyvsp[0].ival;
        }
    break;
case 306:
#line 2874 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.boxpen.color = yyvsp[0].ival;
	}
    break;
case 307:
#line 2881 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.boxpen.pattern = yyvsp[0].ival;
	}
    break;
case 308:
#line 2888 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.boxlines = yyvsp[0].ival;
	}
    break;
case 309:
#line 2895 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.boxlinew = yyvsp[0].dval;
	}
    break;
case 310:
#line 2902 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.legx = yyvsp[-2].dval;
	    g[whichgraph].l.legy = yyvsp[0].dval;
	}
    break;
case 311:
#line 2910 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.charsize = yyvsp[0].dval;
	}
    break;
case 312:
#line 2917 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.font = yyvsp[0].ival;
	}
    break;
case 313:
#line 2924 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.color = yyvsp[0].ival;
	}
    break;
case 314:
#line 2932 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
            g[whichgraph].f.pen.pattern = yyvsp[0].ival;
	}
    break;
case 315:
#line 2939 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].f.type = yyvsp[0].ival;
	}
    break;
case 316:
#line 2946 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].f.lines = yyvsp[0].ival;
	}
    break;
case 317:
#line 2953 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].f.linew = yyvsp[0].dval;
	}
    break;
case 318:
#line 2960 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].f.pen.color = yyvsp[0].ival;
	}
    break;
case 319:
#line 2967 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].f.pen.pattern = yyvsp[0].ival;
	}
    break;
case 320:
#line 2975 "pars.yacc"
{ 
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
            g[whichgraph].f.fillpen.color = yyvsp[0].ival;
        }
    break;
case 321:
#line 2983 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
            g[whichgraph].f.fillpen.pattern = yyvsp[0].ival;
        }
    break;
case 322:
#line 2991 "pars.yacc"
{
            set_graph_hidden(yyvsp[-1].ival, !yyvsp[0].ival);
        }
    break;
case 323:
#line 2994 "pars.yacc"
{
            set_graph_hidden(yyvsp[-2].ival, yyvsp[0].ival);
        }
    break;
case 324:
#line 2997 "pars.yacc"
{
            set_graph_type(yyvsp[-2].ival, yyvsp[0].ival);
        }
    break;
case 325:
#line 3000 "pars.yacc"
{
            set_graph_stacked(yyvsp[-2].ival, yyvsp[0].ival);
        }
    break;
case 326:
#line 3004 "pars.yacc"
{
	    set_graph_bargap(yyvsp[-3].ival, yyvsp[0].dval);
	}
    break;
case 327:
#line 3008 "pars.yacc"
{
            g[yyvsp[-2].ival].locator.pointset = yyvsp[0].ival;
        }
    break;
case 328:
#line 3011 "pars.yacc"
{
	    g[yyvsp[-4].ival].locator.fx = yyvsp[-1].ival;
	    g[yyvsp[-4].ival].locator.fy = yyvsp[0].ival;
	}
    break;
case 329:
#line 3015 "pars.yacc"
{
	    g[yyvsp[-5].ival].locator.px = yyvsp[-2].dval;
	    g[yyvsp[-5].ival].locator.py = yyvsp[0].dval;
	}
    break;
case 330:
#line 3019 "pars.yacc"
{
	    g[yyvsp[-5].ival].locator.dsx = yyvsp[-2].dval;
	    g[yyvsp[-5].ival].locator.dsy = yyvsp[0].dval;
	}
    break;
case 331:
#line 3023 "pars.yacc"
{
            g[yyvsp[-3].ival].locator.pt_type = yyvsp[0].ival;
        }
    break;
case 332:
#line 3027 "pars.yacc"
{
	    curtype = yyvsp[0].ival;
	}
    break;
case 333:
#line 3032 "pars.yacc"
{
	    if (add_io_filter(yyvsp[-3].ival, yyvsp[-1].ival, yyvsp[0].sval, yyvsp[-2].sval) != 0) {
	        yyerror("Failed adding i/o filter");
	    }
	    xfree(yyvsp[-2].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 334:
#line 3039 "pars.yacc"
{
	    clear_io_filters(yyvsp[0].ival);
	}
    break;
case 335:
#line 3043 "pars.yacc"
{
	    cursource = yyvsp[0].ival;
	}
    break;
case 336:
#line 3046 "pars.yacc"
{
	    readxformat = yyvsp[0].ival;
	}
    break;
case 337:
#line 3049 "pars.yacc"
{ }
    break;
case 338:
#line 3050 "pars.yacc"
{
	    nonl_parms[yyvsp[-2].ival].constr = yyvsp[0].ival;
	}
    break;
case 339:
#line 3056 "pars.yacc"
{
	    drawgraph();
	}
    break;
case 340:
#line 3059 "pars.yacc"
{
#ifndef NONE_GUI
            if (inwin) {
                update_all();
            }
#endif
        }
    break;
case 341:
#line 3066 "pars.yacc"
{
	    set_workingdir(yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 342:
#line 3070 "pars.yacc"
{
	    echomsg(yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 343:
#line 3074 "pars.yacc"
{
	    char buf[32];
            sprintf(buf, "%g", yyvsp[0].dval);
            echomsg(buf);
	}
    break;
case 344:
#line 3079 "pars.yacc"
{
	    close_input = copy_string(close_input, "");
	}
    break;
case 345:
#line 3082 "pars.yacc"
{
	    close_input = copy_string(close_input, yyvsp[0].sval);
	}
    break;
case 346:
#line 3085 "pars.yacc"
{
	    exit(0);
	}
    break;
case 347:
#line 3088 "pars.yacc"
{
	    exit(yyvsp[-1].ival);
	}
    break;
case 348:
#line 3091 "pars.yacc"
{
	    if (!safe_mode) {
                do_hardcopy();
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
	}
    break;
case 349:
#line 3098 "pars.yacc"
{
            set_ptofile(FALSE);
	}
    break;
case 350:
#line 3101 "pars.yacc"
{
            set_ptofile(TRUE);
	    strcpy(print_file, yyvsp[0].sval);
            xfree(yyvsp[0].sval);
	}
    break;
case 351:
#line 3106 "pars.yacc"
{
	    switch (yyvsp[0].ival) {
	    case UP:
		graph_scroll(GSCROLL_UP);
		break;
	    case DOWN:
		graph_scroll(GSCROLL_DOWN);
		break;
	    case RIGHT:
		graph_scroll(GSCROLL_RIGHT);
		break;
	    case LEFT:
		graph_scroll(GSCROLL_LEFT);
		break;
	    case IN:
		graph_zoom(GZOOM_SHRINK);
		break;
	    case OUT:
		graph_zoom(GZOOM_EXPAND);
		break;
	    }
	}
    break;
case 352:
#line 3128 "pars.yacc"
{
	    if (yyvsp[0].dval > 0) {
	        msleep_wrap((unsigned int) (1000 * yyvsp[0].dval));
	    }
	}
    break;
case 353:
#line 3133 "pars.yacc"
{
#ifndef NONE_GUI
            if (inwin) {
                HelpCB(yyvsp[0].sval);
            }
            xfree(yyvsp[0].sval);
#endif
	}
    break;
case 354:
#line 3141 "pars.yacc"
{
#ifndef NONE_GUI
            if (inwin) {
                HelpCB("doc/UsersGuide.html");
            }
#endif
	}
    break;
case 355:
#line 3148 "pars.yacc"
{
	    gotparams = TRUE;
	    strcpy(paramfile, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 356:
#line 3153 "pars.yacc"
{
	    if (!safe_mode) {
                FILE *pp = grace_openw(yyvsp[0].sval);
	        if (pp != NULL) {
	            putparms(whichgraph, pp, 0);
	            grace_close(pp);
	        }
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
	    xfree(yyvsp[0].sval);
	}
    break;
case 357:
#line 3165 "pars.yacc"
{
	    set_set_hidden(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].ival);
	}
    break;
case 358:
#line 3168 "pars.yacc"
{
	    setlength(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].ival);
	}
    break;
case 359:
#line 3171 "pars.yacc"
{
	    realloc_vrbl(yyvsp[-2].vrbl, yyvsp[0].ival);
	}
    break;
case 360:
#line 3174 "pars.yacc"
{
	    add_point(yyvsp[-4].trgt->gno, yyvsp[-4].trgt->setno, yyvsp[-2].dval, yyvsp[0].dval);
	}
    break;
case 361:
#line 3178 "pars.yacc"
{
	    int start = yyvsp[-2].ival - index_shift;
	    int stop = yyvsp[0].ival - index_shift;
	    droppoints(yyvsp[-4].trgt->gno, yyvsp[-4].trgt->setno, start, stop);
	}
    break;
case 362:
#line 3183 "pars.yacc"
{
	    if (is_set_active(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno)) {
	        sortset(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[-1].ival, yyvsp[0].ival == ASCENDING ? 0 : 1);
	    }
	}
    break;
case 363:
#line 3188 "pars.yacc"
{
	    do_copyset(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].trgt->gno, yyvsp[0].trgt->setno);
	}
    break;
case 364:
#line 3191 "pars.yacc"
{
	    if (yyvsp[-2].trgt->gno != yyvsp[0].trgt->gno) {
                errmsg("Can't append sets from different graphs");
            } else {
                int sets[2];
	        sets[0] = yyvsp[0].trgt->setno;
	        sets[1] = yyvsp[-2].trgt->setno;
	        join_sets(yyvsp[-2].trgt->gno, sets, 2);
            }
	}
    break;
case 365:
#line 3201 "pars.yacc"
{
            reverse_set(yyvsp[0].trgt->gno, yyvsp[0].trgt->setno);
	}
    break;
case 366:
#line 3204 "pars.yacc"
{
            do_splitsets(yyvsp[-1].trgt->gno, yyvsp[-1].trgt->setno, yyvsp[0].ival);
	}
    break;
case 367:
#line 3207 "pars.yacc"
{
	    do_moveset(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].trgt->gno, yyvsp[0].trgt->setno);
	}
    break;
case 368:
#line 3210 "pars.yacc"
{
	    do_swapset(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].trgt->gno, yyvsp[0].trgt->setno);
	}
    break;
case 369:
#line 3213 "pars.yacc"
{
	    killset(yyvsp[0].trgt->gno, yyvsp[0].trgt->setno);
	}
    break;
case 370:
#line 3216 "pars.yacc"
{
            killsetdata(yyvsp[-1].trgt->gno, yyvsp[-1].trgt->setno);
        }
    break;
case 371:
#line 3219 "pars.yacc"
{
            kill_graph(yyvsp[0].ival);
        }
    break;
case 372:
#line 3222 "pars.yacc"
{
            kill_region(yyvsp[0].ival);
        }
    break;
case 373:
#line 3225 "pars.yacc"
{
            wipeout();
        }
    break;
case 374:
#line 3228 "pars.yacc"
{
            arrange_graphs_simple(yyvsp[-9].ival, yyvsp[-7].ival, 0, FALSE, yyvsp[-5].dval, yyvsp[-3].dval, yyvsp[-1].dval);
        }
    break;
case 375:
#line 3231 "pars.yacc"
{
            int order = (yyvsp[-5].ival * GA_ORDER_HV_INV) |
                        (yyvsp[-3].ival * GA_ORDER_H_INV ) |
                        (yyvsp[-1].ival * GA_ORDER_V_INV );
            arrange_graphs_simple(yyvsp[-15].ival, yyvsp[-13].ival, order, FALSE, yyvsp[-11].dval, yyvsp[-9].dval, yyvsp[-7].dval);
        }
    break;
case 376:
#line 3237 "pars.yacc"
{
            int order = (yyvsp[-7].ival * GA_ORDER_HV_INV) |
                        (yyvsp[-5].ival * GA_ORDER_H_INV ) |
                        (yyvsp[-3].ival * GA_ORDER_V_INV );
            arrange_graphs_simple(yyvsp[-17].ival, yyvsp[-15].ival, order, yyvsp[-1].ival, yyvsp[-13].dval, yyvsp[-11].dval, yyvsp[-9].dval);
        }
    break;
case 377:
#line 3243 "pars.yacc"
{
	    gotnlfit = TRUE;
	    nlfit_gno = yyvsp[-3].trgt->gno;
	    nlfit_setno = yyvsp[-3].trgt->setno;
	    nlfit_nsteps = yyvsp[-1].ival;
	    nlfit_warray = NULL;
	}
    break;
case 378:
#line 3250 "pars.yacc"
{
	    if (getsetlength(yyvsp[-5].trgt->gno, yyvsp[-5].trgt->setno) != yyvsp[-3].vrbl->length) {
                errmsg("Data and weight arrays are of different lengths");
                return 1;
            } else {
	        gotnlfit = TRUE;
	        nlfit_gno = yyvsp[-5].trgt->gno;
	        nlfit_setno = yyvsp[-5].trgt->setno;
	        nlfit_nsteps = yyvsp[-1].ival;
	        nlfit_warray = copy_data_column(yyvsp[-3].vrbl->data, yyvsp[-3].vrbl->length);
            }
	}
    break;
case 379:
#line 3262 "pars.yacc"
{
	    do_regress(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno, yyvsp[-1].ival, 0, -1, 0, -1);
	}
    break;
case 380:
#line 3265 "pars.yacc"
{
	    do_runavg(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno, yyvsp[-1].ival, yyvsp[-5].ival, -1, 0);
	}
    break;
case 381:
#line 3268 "pars.yacc"
{
	    do_fourier_command(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno, yyvsp[-5].ival, yyvsp[-1].ival);
	}
    break;
case 382:
#line 3272 "pars.yacc"
{
	    switch (yyvsp[-11].ival) {
	    case FFT_DFT:
                do_fourier(yyvsp[-9].trgt->gno, yyvsp[-9].trgt->setno, 0, yyvsp[-1].ival, yyvsp[-3].ival, 0, yyvsp[-7].ival, yyvsp[-5].ival);
	        break;
	    case FFT_INVDFT    :
                do_fourier(yyvsp[-9].trgt->gno, yyvsp[-9].trgt->setno, 0, yyvsp[-1].ival, yyvsp[-3].ival, 1, yyvsp[-7].ival, yyvsp[-5].ival);
	        break;
	    case FFT_FFT:
                do_fourier(yyvsp[-9].trgt->gno, yyvsp[-9].trgt->setno, 1, yyvsp[-1].ival, yyvsp[-3].ival, 0, yyvsp[-7].ival, yyvsp[-5].ival);
	        break;
	    case FFT_INVFFT    :
                do_fourier(yyvsp[-9].trgt->gno, yyvsp[-9].trgt->setno, 1, yyvsp[-1].ival, yyvsp[-3].ival, 1, yyvsp[-7].ival, yyvsp[-5].ival);
	        break;
	    default:
                errmsg("Internal error");
	        break;
	    }
        }
    break;
case 383:
#line 3291 "pars.yacc"
{
            do_interp(yyvsp[-7].trgt->gno, yyvsp[-7].trgt->setno, get_cg(), SET_SELECT_NEXT,
                yyvsp[-5].vrbl->data, yyvsp[-5].vrbl->length, yyvsp[-3].ival, yyvsp[-1].ival);
	}
    break;
case 384:
#line 3295 "pars.yacc"
{
            do_histo(yyvsp[-7].trgt->gno, yyvsp[-7].trgt->setno, get_cg(), SET_SELECT_NEXT,
                yyvsp[-5].vrbl->data, yyvsp[-5].vrbl->length - 1, yyvsp[-3].ival, yyvsp[-1].ival);
	}
    break;
case 385:
#line 3299 "pars.yacc"
{
	    do_differ(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno, yyvsp[-1].ival);
	}
    break;
case 386:
#line 3302 "pars.yacc"
{
	    do_int(yyvsp[-1].trgt->gno, yyvsp[-1].trgt->setno, 0);
	}
    break;
case 387:
#line 3305 "pars.yacc"
{
	    do_xcor(yyvsp[-7].trgt->gno, yyvsp[-7].trgt->setno, yyvsp[-5].trgt->gno, yyvsp[-5].trgt->setno, yyvsp[-3].ival, yyvsp[-1].ival);
	}
    break;
case 388:
#line 3308 "pars.yacc"
{
            int len = getsetlength(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno);
            if (len != yyvsp[-1].vrbl->length) {
		errmsg("Filter expression is of a wrong length");
            } else {
                char *rarray;
                rarray = xmalloc(len*SIZEOF_CHAR);
                if (rarray) {
                    int i;
                    for (i = 0; i < len; i++) {
                        rarray[i] = CAST_DBL_TO_BOOL(yyvsp[-1].vrbl->data[i]);
                    }
                    filter_set(yyvsp[-3].trgt->gno, yyvsp[-3].trgt->setno, rarray);
                    xfree(rarray);
                }
            }
	}
    break;
case 389:
#line 3325 "pars.yacc"
{
            int rtype;
            char *rarray;
            
            rtype = RESTRICT_REG0 + yyvsp[-3].ival;

	    if (get_restriction_array(yyvsp[-5].trgt->gno, yyvsp[-5].trgt->setno,
                rtype, yyvsp[-1].ival, &rarray) != RETURN_SUCCESS) {
                errmsg("Error in region evaluation");
                return 1;
	    } else {
                filter_set(yyvsp[-5].trgt->gno, yyvsp[-5].trgt->setno, rarray);
                xfree(rarray);
            }
	}
    break;
case 390:
#line 3340 "pars.yacc"
{
	    if (autoscale_graph(whichgraph, AUTOSCALE_XY) != RETURN_SUCCESS) {
		errmsg("Can't autoscale (no active sets?)");
	    }
	}
    break;
case 391:
#line 3345 "pars.yacc"
{
	    if (autoscale_graph(whichgraph, AUTOSCALE_X) != RETURN_SUCCESS) {
		errmsg("Can't autoscale (no active sets?)");
	    }
	}
    break;
case 392:
#line 3350 "pars.yacc"
{
	    if (autoscale_graph(whichgraph, AUTOSCALE_Y) != RETURN_SUCCESS) {
		errmsg("Can't autoscale (no active sets?)");
	    }
	}
    break;
case 393:
#line 3355 "pars.yacc"
{
	    autoscale_byset(yyvsp[0].trgt->gno, yyvsp[0].trgt->setno, AUTOSCALE_XY);
	}
    break;
case 394:
#line 3358 "pars.yacc"
{
            autotick_axis(whichgraph, ALL_AXES);
        }
    break;
case 395:
#line 3361 "pars.yacc"
{
	    int gno = yyvsp[0].ival;
            if (is_graph_hidden(gno) == FALSE) {
                select_graph(gno);
            } else {
		errmsg("Graph is not active");
            }
	}
    break;
case 396:
#line 3369 "pars.yacc"
{
	    gotread = TRUE;
	    strcpy(readfile, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 397:
#line 3374 "pars.yacc"
{
	    strcpy(batchfile, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 398:
#line 3378 "pars.yacc"
{
	    getdata(whichgraph, yyvsp[0].sval, SOURCE_DISK, LOAD_BLOCK);
	    xfree(yyvsp[0].sval);
	}
    break;
case 399:
#line 3382 "pars.yacc"
{
	    getdata(whichgraph, yyvsp[0].sval, yyvsp[-1].ival, LOAD_BLOCK);
	    xfree(yyvsp[0].sval);
	}
    break;
case 400:
#line 3386 "pars.yacc"
{
            int nc, *cols, scol;
            if (field_string_to_cols(yyvsp[0].sval, &nc, &cols, &scol) != RETURN_SUCCESS) {
                errmsg("Erroneous field specifications");
	        xfree(yyvsp[0].sval);
                return 1;
            } else {
	        xfree(yyvsp[0].sval);
	        create_set_fromblock(whichgraph, NEW_SET,
                    yyvsp[-1].ival, nc, cols, scol, autoscale_onread);
                xfree(cols);
            }
	}
    break;
case 401:
#line 3399 "pars.yacc"
{
	    gotread = TRUE;
	    curtype = yyvsp[-1].ival;
	    strcpy(readfile, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 402:
#line 3405 "pars.yacc"
{
	    gotread = TRUE;
	    strcpy(readfile, yyvsp[0].sval);
	    curtype = yyvsp[-2].ival;
	    cursource = yyvsp[-1].ival;
	    xfree(yyvsp[0].sval);
	}
    break;
case 403:
#line 3412 "pars.yacc"
{
	    getdata(whichgraph, yyvsp[0].sval, SOURCE_DISK, LOAD_NXY);
	    xfree(yyvsp[0].sval);
	}
    break;
case 404:
#line 3416 "pars.yacc"
{
	    getdata(whichgraph, yyvsp[0].sval, yyvsp[-1].ival, LOAD_NXY);
	    xfree(yyvsp[0].sval);
	}
    break;
case 405:
#line 3420 "pars.yacc"
{
	    if (!safe_mode) {
                outputset(yyvsp[0].trgt->gno, yyvsp[0].trgt->setno, "stdout", NULL);
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
	}
    break;
case 406:
#line 3427 "pars.yacc"
{
	    if (!safe_mode) {
	        outputset(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, "stdout", yyvsp[0].sval);
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
	    xfree(yyvsp[0].sval);
	}
    break;
case 407:
#line 3435 "pars.yacc"
{
	    if (!safe_mode) {
	        outputset(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].sval, NULL);
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
	    xfree(yyvsp[0].sval);
	}
    break;
case 408:
#line 3443 "pars.yacc"
{
	    if (!safe_mode) {
	        outputset(yyvsp[-4].trgt->gno, yyvsp[-4].trgt->setno, yyvsp[-2].sval, yyvsp[0].sval);
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
	    xfree(yyvsp[-2].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 409:
#line 3452 "pars.yacc"
{
            if (!safe_mode) {
                save_project(yyvsp[0].sval);
            } else {
                yyerror("File modifications are disabled in safe mode");
            }
            xfree(yyvsp[0].sval);
        }
    break;
case 410:
#line 3460 "pars.yacc"
{
            load_project(yyvsp[0].sval);
            xfree(yyvsp[0].sval);
        }
    break;
case 411:
#line 3464 "pars.yacc"
{
            new_project(NULL);
        }
    break;
case 412:
#line 3467 "pars.yacc"
{
            new_project(yyvsp[0].sval);
            xfree(yyvsp[0].sval);
        }
    break;
case 413:
#line 3471 "pars.yacc"
{
	    push_world();
	}
    break;
case 414:
#line 3474 "pars.yacc"
{
	    pop_world();
	}
    break;
case 415:
#line 3477 "pars.yacc"
{
	    cycle_world_stack();
	}
    break;
case 416:
#line 3480 "pars.yacc"
{
	    if (yyvsp[0].ival > 0)
		show_world_stack(yyvsp[0].ival - 1);
	}
    break;
case 417:
#line 3484 "pars.yacc"
{
	    clear_world_stack();
	}
    break;
case 418:
#line 3487 "pars.yacc"
{
	    do_clear_boxes();
	}
    break;
case 419:
#line 3490 "pars.yacc"
{
	    do_clear_ellipses();
	}
    break;
case 420:
#line 3493 "pars.yacc"
{
	    do_clear_lines();
	}
    break;
case 421:
#line 3496 "pars.yacc"
{
	    do_clear_text();
	}
    break;
case 422:
#line 3503 "pars.yacc"
{
#ifndef NONE_GUI
            set_pagelayout(yyvsp[0].ival);
#endif
        }
    break;
case 423:
#line 3508 "pars.yacc"
{
	    auto_redraw = yyvsp[0].ival;
	}
    break;
case 424:
#line 3511 "pars.yacc"
{
	    draw_focus_flag = yyvsp[0].ival;
	}
    break;
case 425:
#line 3514 "pars.yacc"
{
	    focus_policy = FOCUS_SET;
	}
    break;
case 426:
#line 3517 "pars.yacc"
{
	    focus_policy = FOCUS_FOLLOWS;
	}
    break;
case 427:
#line 3520 "pars.yacc"
{
	    focus_policy = FOCUS_CLICK;
	}
    break;
case 428:
#line 3527 "pars.yacc"
{}
    break;
case 429:
#line 3528 "pars.yacc"
{}
    break;
case 430:
#line 3532 "pars.yacc"
{
	    set_set_hidden(yyvsp[-1].trgt->gno, yyvsp[-1].trgt->setno, !yyvsp[0].ival);
	}
    break;
case 431:
#line 3535 "pars.yacc"
{
	    set_dataset_type(yyvsp[-2].trgt->gno, yyvsp[-2].trgt->setno, yyvsp[0].ival);
	}
    break;
case 432:
#line 3539 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].sym = yyvsp[0].ival;
	}
    break;
case 433:
#line 3542 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].sympen.color = yyvsp[0].ival;
	}
    break;
case 434:
#line 3545 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].sympen.pattern = yyvsp[0].ival;
	}
    break;
case 435:
#line 3548 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].symlinew = yyvsp[0].dval;
	}
    break;
case 436:
#line 3551 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].symlines = yyvsp[0].ival;
	}
    break;
case 437:
#line 3554 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symfillpen.color = yyvsp[0].ival;
	}
    break;
case 438:
#line 3557 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symfillpen.pattern = yyvsp[0].ival;
	}
    break;
case 439:
#line 3560 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symsize = yyvsp[0].dval;
	}
    break;
case 440:
#line 3563 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symchar = yyvsp[0].ival;
	}
    break;
case 441:
#line 3566 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].charfont = yyvsp[0].ival;
	}
    break;
case 442:
#line 3569 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symskip = yyvsp[0].ival;
	}
    break;
case 443:
#line 3574 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].linet = yyvsp[0].ival;
	}
    break;
case 444:
#line 3578 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].lines = yyvsp[0].ival;
	}
    break;
case 445:
#line 3582 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].linew = yyvsp[0].dval;
	}
    break;
case 446:
#line 3586 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].linepen.color = yyvsp[0].ival;
	}
    break;
case 447:
#line 3590 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].linepen.pattern = yyvsp[0].ival;
	}
    break;
case 448:
#line 3595 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].filltype = yyvsp[0].ival;
	}
    break;
case 449:
#line 3599 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].fillrule = yyvsp[0].ival;
	}
    break;
case 450:
#line 3603 "pars.yacc"
{
	    int prop = yyvsp[0].ival;

	    if (get_project_version() <= 40102 && get_project_version() >= 30000) {
                switch (filltype_obs) {
                case COLOR:
                    break;
                case PATTERN:
                    prop = 1;
                    break;
                default: /* NONE */
	            prop = 0;
                    break;
                }
	    }
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].setfillpen.color = prop;
	}
    break;
case 451:
#line 3621 "pars.yacc"
{
	    int prop = yyvsp[0].ival;

	    if (get_project_version() <= 40102) {
                switch (filltype_obs) {
                case COLOR:
                    prop = 1;
                    break;
                case PATTERN:
                    break;
                default: /* NONE */
	            prop = 0;
                    break;
                }
	    }
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].setfillpen.pattern = prop;
	}
    break;
case 452:
#line 3641 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].baseline = yyvsp[0].ival;
	}
    break;
case 453:
#line 3645 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].baseline_type = yyvsp[0].ival;
	}
    break;
case 454:
#line 3650 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].dropline = yyvsp[0].ival;
	}
    break;
case 455:
#line 3655 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].avalue.active = yyvsp[0].ival;
	}
    break;
case 456:
#line 3659 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].avalue.type = yyvsp[0].ival;
	}
    break;
case 457:
#line 3663 "pars.yacc"
{
	    g[yyvsp[-4].trgt->gno].p[yyvsp[-4].trgt->setno].avalue.size = yyvsp[0].dval;
	}
    break;
case 458:
#line 3667 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].avalue.font = yyvsp[0].ival;
	}
    break;
case 459:
#line 3671 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].avalue.color = yyvsp[0].ival;
	}
    break;
case 460:
#line 3675 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].avalue.angle = yyvsp[0].ival;
	}
    break;
case 461:
#line 3679 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].avalue.format = yyvsp[0].ival;
	}
    break;
case 462:
#line 3683 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].avalue.prec = yyvsp[0].ival;
	}
    break;
case 463:
#line 3686 "pars.yacc"
{
	    g[yyvsp[-5].trgt->gno].p[yyvsp[-5].trgt->setno].avalue.offset.x = yyvsp[-2].dval;
	    g[yyvsp[-5].trgt->gno].p[yyvsp[-5].trgt->setno].avalue.offset.y = yyvsp[0].dval;
	}
    break;
case 464:
#line 3691 "pars.yacc"
{
	    strcpy(g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].avalue.prestr, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 465:
#line 3696 "pars.yacc"
{
	    strcpy(g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].avalue.appstr, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 466:
#line 3701 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].errbar.active = yyvsp[0].ival;
	}
    break;
case 467:
#line 3704 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].errbar.ptype = yyvsp[0].ival;
	}
    break;
case 468:
#line 3707 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].errbar.pen.color = yyvsp[0].ival;
	}
    break;
case 469:
#line 3710 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].errbar.pen.pattern = yyvsp[0].ival;
	}
    break;
case 470:
#line 3713 "pars.yacc"
{
            g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].errbar.barsize = yyvsp[0].dval;
	}
    break;
case 471:
#line 3716 "pars.yacc"
{
            g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].errbar.linew = yyvsp[0].dval;
	}
    break;
case 472:
#line 3719 "pars.yacc"
{
            g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].errbar.lines = yyvsp[0].ival;
	}
    break;
case 473:
#line 3722 "pars.yacc"
{
            g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].errbar.riser_linew = yyvsp[0].dval;
	}
    break;
case 474:
#line 3725 "pars.yacc"
{
            g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].errbar.riser_lines = yyvsp[0].ival;
	}
    break;
case 475:
#line 3728 "pars.yacc"
{
            g[yyvsp[-4].trgt->gno].p[yyvsp[-4].trgt->setno].errbar.arrow_clip = yyvsp[0].ival;
	}
    break;
case 476:
#line 3731 "pars.yacc"
{
            g[yyvsp[-5].trgt->gno].p[yyvsp[-5].trgt->setno].errbar.cliplen = yyvsp[0].dval;
	}
    break;
case 477:
#line 3735 "pars.yacc"
{
	    strncpy(g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].comments, yyvsp[0].sval, MAX_STRING_LENGTH - 1);
	    xfree(yyvsp[0].sval);
	}
    break;
case 478:
#line 3740 "pars.yacc"
{
	    strncpy(g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].lstr, yyvsp[0].sval, MAX_STRING_LENGTH - 1);
	    xfree(yyvsp[0].sval);
	}
    break;
case 479:
#line 3748 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->active = yyvsp[0].ival;
	}
    break;
case 480:
#line 3755 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->zero = yyvsp[0].ival;
	}
    break;
case 481:
#line 3762 "pars.yacc"
{}
    break;
case 482:
#line 3763 "pars.yacc"
{}
    break;
case 483:
#line 3764 "pars.yacc"
{}
    break;
case 484:
#line 3765 "pars.yacc"
{}
    break;
case 485:
#line 3766 "pars.yacc"
{}
    break;
case 486:
#line 3767 "pars.yacc"
{}
    break;
case 487:
#line 3768 "pars.yacc"
{}
    break;
case 488:
#line 3769 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
            g[whichgraph].t[naxis]->offsx = yyvsp[-2].dval;
	    g[whichgraph].t[naxis]->offsy = yyvsp[0].dval;
	}
    break;
case 489:
#line 3780 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_flag = yyvsp[0].ival;
	}
    break;
case 490:
#line 3787 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
            g[whichgraph].t[naxis]->tmajor = yyvsp[0].dval;
	}
    break;
case 491:
#line 3794 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->nminor = yyvsp[0].ival;
	}
    break;
case 492:
#line 3801 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_round = yyvsp[0].ival;
	}
    break;
case 493:
#line 3809 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
            g[whichgraph].t[naxis]->offsx = yyvsp[0].dval;
	}
    break;
case 494:
#line 3816 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
            g[whichgraph].t[naxis]->offsy = yyvsp[0].dval;
	}
    break;
case 495:
#line 3823 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_autonum = yyvsp[0].ival;
	}
    break;
case 496:
#line 3830 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_inout = yyvsp[0].ival;
	}
    break;
case 497:
#line 3837 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.size = yyvsp[0].dval;
	}
    break;
case 498:
#line 3844 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->mprops.size = yyvsp[0].dval;
	}
    break;
case 499:
#line 3851 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.color = g[whichgraph].t[naxis]->mprops.color = yyvsp[0].ival;
	}
    break;
case 500:
#line 3858 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.color = yyvsp[0].ival;
	}
    break;
case 501:
#line 3865 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->mprops.color = yyvsp[0].ival;
	}
    break;
case 502:
#line 3872 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.linew = g[whichgraph].t[naxis]->mprops.linew = yyvsp[0].dval;
	}
    break;
case 503:
#line 3879 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.linew = yyvsp[0].dval;
	}
    break;
case 504:
#line 3886 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->mprops.linew = yyvsp[0].dval;
	}
    break;
case 505:
#line 3893 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.lines = yyvsp[0].ival;
	}
    break;
case 506:
#line 3900 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->mprops.lines = yyvsp[0].ival;
	}
    break;
case 507:
#line 3907 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.gridflag = yyvsp[0].ival;
	}
    break;
case 508:
#line 3914 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->mprops.gridflag = yyvsp[0].ival;
	}
    break;
case 509:
#line 3921 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_op = yyvsp[0].ival;
	}
    break;
case 510:
#line 3928 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_spec = yyvsp[0].ival;
	}
    break;
case 511:
#line 3935 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->nticks = yyvsp[0].ival;
	}
    break;
case 512:
#line 3942 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].wtpos = yyvsp[0].dval;
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].type = TICK_TYPE_MAJOR;
	}
    break;
case 513:
#line 3950 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].wtpos = yyvsp[0].dval;
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].type = TICK_TYPE_MINOR;
	}
    break;
case 514:
#line 3961 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_flag = yyvsp[0].ival;
	}
    break;
case 515:
#line 3968 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_prec = yyvsp[0].ival;
	}
    break;
case 516:
#line 3975 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_format = yyvsp[0].ival;
	}
    break;
case 517:
#line 3982 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_format = yyvsp[0].dval;
	}
    break;
case 518:
#line 3989 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    strcpy(g[whichgraph].t[naxis]->tl_appstr, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 519:
#line 3997 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    strcpy(g[whichgraph].t[naxis]->tl_prestr, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 520:
#line 4005 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_angle = yyvsp[0].ival;
	}
    break;
case 521:
#line 4012 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_skip = yyvsp[0].ival;
	}
    break;
case 522:
#line 4019 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_staggered = yyvsp[0].ival;
	}
    break;
case 523:
#line 4026 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_op = yyvsp[0].ival;
	}
    break;
case 524:
#line 4033 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
            g[whichgraph].t[naxis]->tl_formula =
                copy_string(g[whichgraph].t[naxis]->tl_formula, yyvsp[0].sval);
            xfree(yyvsp[0].sval);
	}
    break;
case 525:
#line 4042 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_start = yyvsp[0].dval;
	}
    break;
case 526:
#line 4049 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_stop = yyvsp[0].dval;
	}
    break;
case 527:
#line 4056 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_starttype = TYPE_SPEC;
	}
    break;
case 528:
#line 4063 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_starttype = TYPE_AUTO;
	}
    break;
case 529:
#line 4070 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_stoptype = TYPE_SPEC;
	}
    break;
case 530:
#line 4077 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_stoptype = TYPE_AUTO;
	}
    break;
case 531:
#line 4084 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_charsize = yyvsp[0].dval;
	}
    break;
case 532:
#line 4091 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_font = yyvsp[0].ival;
	}
    break;
case 533:
#line 4098 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_color = yyvsp[0].ival;
	}
    break;
case 534:
#line 4105 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                xfree(yyvsp[0].sval);
                return 1;
            }
	    if (yyvsp[-2].ival >= MAX_TICKS) {
	         yyerror("Number of ticks exceeds maximum");
	         xfree(yyvsp[0].sval);
	         return 1;
	    }
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].label = 
                copy_string(g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].label, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 535:
#line 4120 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_gaptype = TYPE_AUTO;
	}
    break;
case 536:
#line 4127 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_gaptype = TYPE_SPEC;
	}
    break;
case 537:
#line 4134 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_gap.x = yyvsp[-2].dval;
	    g[whichgraph].t[naxis]->tl_gap.y = yyvsp[0].dval;
	}
    break;
case 538:
#line 4145 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    set_plotstr_string(&g[whichgraph].t[naxis]->label, yyvsp[0].sval);
	    xfree(yyvsp[0].sval);
	}
    break;
case 539:
#line 4153 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label_layout = LAYOUT_PERPENDICULAR;
	}
    break;
case 540:
#line 4160 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label_layout = LAYOUT_PARALLEL;
	}
    break;
case 541:
#line 4167 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label_place = TYPE_AUTO;
	}
    break;
case 542:
#line 4174 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label_place = TYPE_SPEC;
	}
    break;
case 543:
#line 4181 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label.x = yyvsp[-2].dval;
	    g[whichgraph].t[naxis]->label.y = yyvsp[0].dval;
	}
    break;
case 544:
#line 4189 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label.just = yyvsp[0].ival;
	}
    break;
case 545:
#line 4196 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label.charsize = yyvsp[0].dval;
	}
    break;
case 546:
#line 4203 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label.font = yyvsp[0].ival;
	}
    break;
case 547:
#line 4210 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label.color = yyvsp[0].ival;
	}
    break;
case 548:
#line 4217 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label_op = yyvsp[0].ival;
	}
    break;
case 549:
#line 4227 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_drawbar = yyvsp[0].ival;
	}
    break;
case 550:
#line 4234 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_drawbarcolor = yyvsp[0].ival;
	}
    break;
case 551:
#line 4241 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_drawbarlines = yyvsp[0].ival;
	}
    break;
case 552:
#line 4248 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_drawbarlinew = yyvsp[0].dval;
	}
    break;
case 553:
#line 4258 "pars.yacc"
{ 
          nonl_opts.title = copy_string(nonl_opts.title, yyvsp[0].sval);
	  xfree(yyvsp[0].sval);
        }
    break;
case 554:
#line 4262 "pars.yacc"
{ 
          nonl_opts.formula = copy_string(nonl_opts.formula, yyvsp[0].sval);
	  xfree(yyvsp[0].sval);
        }
    break;
case 555:
#line 4266 "pars.yacc"
{ 
            nonl_opts.parnum = yyvsp[-1].ival; 
        }
    break;
case 556:
#line 4269 "pars.yacc"
{ 
            nonl_opts.tolerance = yyvsp[0].dval; 
        }
    break;
case 557:
#line 4276 "pars.yacc"
{
            yyval.ival = yyvsp[0].ival;
        }
    break;
case 558:
#line 4280 "pars.yacc"
{
            yyval.ival = yyvsp[0].ival;
        }
    break;
case 559:
#line 4287 "pars.yacc"
{
	    int gno = yyvsp[-2].ival, setno = yyvsp[0].ival;
            if (allocate_set(gno, setno) == RETURN_SUCCESS) {
                yyval.trgt = &trgt_pool[tgtn];
                yyval.trgt->gno   = gno;
                yyval.trgt->setno = setno;
                tgtn++;
            } else {
                errmsg("Can't allocate referred set");
                return 1;
            }
	}
    break;
case 560:
#line 4300 "pars.yacc"
{
	    int gno = yyvsp[-3].ival, setno = yyvsp[0].ival;
            if (allocate_set(gno, setno) == RETURN_SUCCESS) {
                yyval.trgt = &trgt_pool[tgtn];
                yyval.trgt->gno   = gno;
                yyval.trgt->setno = setno;
                tgtn++;
            } else {
                errmsg("Can't allocate referred set");
                return 1;
            }
	}
    break;
case 561:
#line 4313 "pars.yacc"
{
	    int gno = whichgraph, setno = yyvsp[0].ival;
            if (allocate_set(gno, setno) == RETURN_SUCCESS) {
                yyval.trgt = &trgt_pool[tgtn];
                yyval.trgt->gno   = gno;
                yyval.trgt->setno = setno;
                tgtn++;
            } else {
                errmsg("Can't allocate referred set");
                return 1;
            }
	}
    break;
case 562:
#line 4326 "pars.yacc"
{
	    int gno = whichgraph, setno = yyvsp[0].ival;
            if (allocate_set(gno, setno) == RETURN_SUCCESS) {
                yyval.trgt = &trgt_pool[tgtn];
                yyval.trgt->gno   = gno;
                yyval.trgt->setno = setno;
                tgtn++;
            } else {
                errmsg("Can't allocate referred set");
                return 1;
            }
	}
    break;
case 563:
#line 4341 "pars.yacc"
{}
    break;
case 564:
#line 4342 "pars.yacc"
{}
    break;
case 565:
#line 4346 "pars.yacc"
{ naxis =  X_AXIS; }
    break;
case 566:
#line 4347 "pars.yacc"
{ naxis = Y_AXIS; }
    break;
case 567:
#line 4348 "pars.yacc"
{ naxis = ZX_AXIS; }
    break;
case 568:
#line 4349 "pars.yacc"
{ naxis = ZY_AXIS; }
    break;
case 569:
#line 4353 "pars.yacc"
{ yyval.ival = CONSTANT;  }
    break;
case 570:
#line 4354 "pars.yacc"
{ yyval.ival = UCONSTANT; }
    break;
case 571:
#line 4355 "pars.yacc"
{ yyval.ival = FUNC_I;    }
    break;
case 572:
#line 4356 "pars.yacc"
{ yyval.ival = FUNC_D;    }
    break;
case 573:
#line 4357 "pars.yacc"
{ yyval.ival = FUNC_ND;   }
    break;
case 574:
#line 4358 "pars.yacc"
{ yyval.ival = FUNC_NN;   }
    break;
case 575:
#line 4359 "pars.yacc"
{ yyval.ival = FUNC_DD;   }
    break;
case 576:
#line 4360 "pars.yacc"
{ yyval.ival = FUNC_NND;  }
    break;
case 577:
#line 4361 "pars.yacc"
{ yyval.ival = FUNC_PPD;  }
    break;
case 578:
#line 4362 "pars.yacc"
{ yyval.ival = FUNC_PPPD; }
    break;
case 579:
#line 4363 "pars.yacc"
{ yyval.ival = FUNC_PPPPD; }
    break;
case 580:
#line 4364 "pars.yacc"
{ yyval.ival = FUNC_PPPPPD; }
    break;
case 581:
#line 4368 "pars.yacc"
{ yyval.ival =  TICKS_SPEC_NONE; }
    break;
case 582:
#line 4369 "pars.yacc"
{ yyval.ival = TICKS_SPEC_MARKS; }
    break;
case 583:
#line 4370 "pars.yacc"
{ yyval.ival = TICKS_SPEC_BOTH; }
    break;
case 584:
#line 4374 "pars.yacc"
{ yyval.ival = FILTER_INPUT; }
    break;
case 585:
#line 4375 "pars.yacc"
{ yyval.ival = FILTER_OUTPUT; }
    break;
case 586:
#line 4379 "pars.yacc"
{ yyval.ival = FILTER_MAGIC; }
    break;
case 587:
#line 4380 "pars.yacc"
{ yyval.ival = FILTER_PATTERN; }
    break;
case 588:
#line 4384 "pars.yacc"
{ yyval.ival = SET_XY; }
    break;
case 589:
#line 4385 "pars.yacc"
{ yyval.ival = SET_BAR; }
    break;
case 590:
#line 4386 "pars.yacc"
{ yyval.ival = SET_BARDY; }
    break;
case 591:
#line 4387 "pars.yacc"
{ yyval.ival = SET_BARDYDY; }
    break;
case 592:
#line 4388 "pars.yacc"
{ yyval.ival = SET_XYZ; }
    break;
case 593:
#line 4389 "pars.yacc"
{ yyval.ival = SET_XYDX; }
    break;
case 594:
#line 4390 "pars.yacc"
{ yyval.ival = SET_XYDY; }
    break;
case 595:
#line 4391 "pars.yacc"
{ yyval.ival = SET_XYDXDX; }
    break;
case 596:
#line 4392 "pars.yacc"
{ yyval.ival = SET_XYDYDY; }
    break;
case 597:
#line 4393 "pars.yacc"
{ yyval.ival = SET_XYDXDY; }
    break;
case 598:
#line 4394 "pars.yacc"
{ yyval.ival = SET_XYDXDXDYDY; }
    break;
case 599:
#line 4395 "pars.yacc"
{ yyval.ival = SET_XYHILO; }
    break;
case 600:
#line 4396 "pars.yacc"
{ yyval.ival = SET_XYR; }
    break;
case 601:
#line 4397 "pars.yacc"
{ yyval.ival = SET_XYSIZE; }
    break;
case 602:
#line 4398 "pars.yacc"
{ yyval.ival = SET_XYCOLOR; }
    break;
case 603:
#line 4399 "pars.yacc"
{ yyval.ival = SET_XYCOLPAT; }
    break;
case 604:
#line 4400 "pars.yacc"
{ yyval.ival = SET_XYVMAP; }
    break;
case 605:
#line 4401 "pars.yacc"
{ yyval.ival = SET_BOXPLOT; }
    break;
case 606:
#line 4402 "pars.yacc"
{ yyval.ival = SET_XY; }
    break;
case 607:
#line 4406 "pars.yacc"
{ yyval.ival = GRAPH_XY; }
    break;
case 608:
#line 4407 "pars.yacc"
{ yyval.ival = GRAPH_CHART; }
    break;
case 609:
#line 4408 "pars.yacc"
{ yyval.ival = GRAPH_POLAR; }
    break;
case 610:
#line 4409 "pars.yacc"
{ yyval.ival = GRAPH_SMITH; }
    break;
case 611:
#line 4410 "pars.yacc"
{ yyval.ival = GRAPH_FIXED; }
    break;
case 612:
#line 4411 "pars.yacc"
{ yyval.ival = GRAPH_PIE;   }
    break;
case 613:
#line 4415 "pars.yacc"
{ yyval.ival = PAGE_FREE; }
    break;
case 614:
#line 4416 "pars.yacc"
{ yyval.ival = PAGE_FIXED; }
    break;
case 615:
#line 4420 "pars.yacc"
{ yyval.ival = PAGE_ORIENT_LANDSCAPE; }
    break;
case 616:
#line 4421 "pars.yacc"
{ yyval.ival = PAGE_ORIENT_PORTRAIT;  }
    break;
case 617:
#line 4425 "pars.yacc"
{ yyval.ival = REGION_ABOVE; }
    break;
case 618:
#line 4426 "pars.yacc"
{ yyval.ival = REGION_BELOW; }
    break;
case 619:
#line 4427 "pars.yacc"
{ yyval.ival = REGION_TOLEFT; }
    break;
case 620:
#line 4428 "pars.yacc"
{ yyval.ival = REGION_TORIGHT; }
    break;
case 621:
#line 4429 "pars.yacc"
{ yyval.ival = REGION_POLYI; }
    break;
case 622:
#line 4430 "pars.yacc"
{ yyval.ival = REGION_POLYO; }
    break;
case 623:
#line 4431 "pars.yacc"
{ yyval.ival = REGION_HORIZI; }
    break;
case 624:
#line 4432 "pars.yacc"
{ yyval.ival = REGION_VERTI; }
    break;
case 625:
#line 4433 "pars.yacc"
{ yyval.ival = REGION_HORIZO; }
    break;
case 626:
#line 4434 "pars.yacc"
{ yyval.ival = REGION_VERTO; }
    break;
case 627:
#line 4437 "pars.yacc"
{ yyval.ival = SCALE_NORMAL; }
    break;
case 628:
#line 4438 "pars.yacc"
{ yyval.ival = SCALE_LOG; }
    break;
case 629:
#line 4439 "pars.yacc"
{ yyval.ival = SCALE_REC; }
    break;
case 630:
#line 4440 "pars.yacc"
{ yyval.ival = SCALE_LOGIT; }
    break;
case 631:
#line 4443 "pars.yacc"
{ yyval.ival = TRUE; }
    break;
case 632:
#line 4444 "pars.yacc"
{ yyval.ival = FALSE; }
    break;
case 633:
#line 4447 "pars.yacc"
{ yyval.ival = RUN_AVG; }
    break;
case 634:
#line 4448 "pars.yacc"
{ yyval.ival = RUN_STD; }
    break;
case 635:
#line 4449 "pars.yacc"
{ yyval.ival = RUN_MED; }
    break;
case 636:
#line 4450 "pars.yacc"
{ yyval.ival = RUN_MAX; }
    break;
case 637:
#line 4451 "pars.yacc"
{ yyval.ival = RUN_MIN; }
    break;
case 638:
#line 4455 "pars.yacc"
{ yyval.ival = SOURCE_DISK; }
    break;
case 639:
#line 4456 "pars.yacc"
{
            if (!safe_mode) {
                yyval.ival = SOURCE_PIPE;
            } else {
                yyerror("Pipe inputs are disabled in safe mode");
                yyval.ival = SOURCE_DISK;
            }
        }
    break;
case 640:
#line 4466 "pars.yacc"
{ yyval.ival = JUST_RIGHT; }
    break;
case 641:
#line 4467 "pars.yacc"
{ yyval.ival = JUST_LEFT; }
    break;
case 642:
#line 4468 "pars.yacc"
{ yyval.ival = JUST_CENTER; }
    break;
case 643:
#line 4471 "pars.yacc"
{ yyval.ival = TICKS_IN; }
    break;
case 644:
#line 4472 "pars.yacc"
{ yyval.ival = TICKS_OUT; }
    break;
case 645:
#line 4473 "pars.yacc"
{ yyval.ival = TICKS_BOTH; }
    break;
case 646:
#line 4476 "pars.yacc"
{ yyval.ival = FORMAT_DECIMAL; }
    break;
case 647:
#line 4477 "pars.yacc"
{ yyval.ival = FORMAT_EXPONENTIAL; }
    break;
case 648:
#line 4478 "pars.yacc"
{ yyval.ival = FORMAT_GENERAL; }
    break;
case 649:
#line 4479 "pars.yacc"
{ yyval.ival = FORMAT_SCIENTIFIC; }
    break;
case 650:
#line 4480 "pars.yacc"
{ yyval.ival = FORMAT_ENGINEERING; }
    break;
case 651:
#line 4481 "pars.yacc"
{ yyval.ival = FORMAT_POWER; }
    break;
case 652:
#line 4482 "pars.yacc"
{ yyval.ival = FORMAT_DDMMYY; }
    break;
case 653:
#line 4483 "pars.yacc"
{ yyval.ival = FORMAT_MMDDYY; }
    break;
case 654:
#line 4484 "pars.yacc"
{ yyval.ival = FORMAT_YYMMDD; }
    break;
case 655:
#line 4485 "pars.yacc"
{ yyval.ival = FORMAT_MMYY; }
    break;
case 656:
#line 4486 "pars.yacc"
{ yyval.ival = FORMAT_MMDD; }
    break;
case 657:
#line 4487 "pars.yacc"
{ yyval.ival = FORMAT_MONTHDAY; }
    break;
case 658:
#line 4488 "pars.yacc"
{ yyval.ival = FORMAT_DAYMONTH; }
    break;
case 659:
#line 4489 "pars.yacc"
{ yyval.ival = FORMAT_MONTHS; }
    break;
case 660:
#line 4490 "pars.yacc"
{ yyval.ival = FORMAT_MONTHSY; }
    break;
case 661:
#line 4491 "pars.yacc"
{ yyval.ival = FORMAT_MONTHL; }
    break;
case 662:
#line 4492 "pars.yacc"
{ yyval.ival = FORMAT_DAYOFWEEKS; }
    break;
case 663:
#line 4493 "pars.yacc"
{ yyval.ival = FORMAT_DAYOFWEEKL; }
    break;
case 664:
#line 4494 "pars.yacc"
{ yyval.ival = FORMAT_DAYOFYEAR; }
    break;
case 665:
#line 4495 "pars.yacc"
{ yyval.ival = FORMAT_HMS; }
    break;
case 666:
#line 4496 "pars.yacc"
{ yyval.ival = FORMAT_MMDDHMS; }
    break;
case 667:
#line 4497 "pars.yacc"
{ yyval.ival = FORMAT_MMDDYYHMS; }
    break;
case 668:
#line 4498 "pars.yacc"
{ yyval.ival = FORMAT_YYMMDDHMS; }
    break;
case 669:
#line 4499 "pars.yacc"
{ yyval.ival = FORMAT_DEGREESLON; }
    break;
case 670:
#line 4500 "pars.yacc"
{ yyval.ival = FORMAT_DEGREESMMLON; }
    break;
case 671:
#line 4501 "pars.yacc"
{ yyval.ival = FORMAT_DEGREESMMSSLON; }
    break;
case 672:
#line 4502 "pars.yacc"
{ yyval.ival = FORMAT_MMSSLON; }
    break;
case 673:
#line 4503 "pars.yacc"
{ yyval.ival = FORMAT_DEGREESLAT; }
    break;
case 674:
#line 4504 "pars.yacc"
{ yyval.ival = FORMAT_DEGREESMMLAT; }
    break;
case 675:
#line 4505 "pars.yacc"
{ yyval.ival = FORMAT_DEGREESMMSSLAT; }
    break;
case 676:
#line 4506 "pars.yacc"
{ yyval.ival = FORMAT_MMSSLAT; }
    break;
case 677:
#line 4509 "pars.yacc"
{ yyval.ival = SIGN_NORMAL; }
    break;
case 678:
#line 4510 "pars.yacc"
{ yyval.ival = SIGN_ABSOLUTE; }
    break;
case 679:
#line 4511 "pars.yacc"
{ yyval.ival = SIGN_NEGATE; }
    break;
case 680:
#line 4514 "pars.yacc"
{ yyval.ival = UP; }
    break;
case 681:
#line 4515 "pars.yacc"
{ yyval.ival = DOWN; }
    break;
case 682:
#line 4516 "pars.yacc"
{ yyval.ival = RIGHT; }
    break;
case 683:
#line 4517 "pars.yacc"
{ yyval.ival = LEFT; }
    break;
case 684:
#line 4518 "pars.yacc"
{ yyval.ival = IN; }
    break;
case 685:
#line 4519 "pars.yacc"
{ yyval.ival = OUT; }
    break;
case 686:
#line 4522 "pars.yacc"
{ yyval.ival = COORD_WORLD; }
    break;
case 687:
#line 4523 "pars.yacc"
{ yyval.ival = COORD_VIEW; }
    break;
case 688:
#line 4526 "pars.yacc"
{ yyval.ival = DATA_X; }
    break;
case 689:
#line 4527 "pars.yacc"
{ yyval.ival = DATA_Y; }
    break;
case 690:
#line 4528 "pars.yacc"
{ yyval.ival = DATA_X; }
    break;
case 691:
#line 4529 "pars.yacc"
{ yyval.ival = DATA_Y; }
    break;
case 692:
#line 4530 "pars.yacc"
{ yyval.ival = DATA_Y1; }
    break;
case 693:
#line 4531 "pars.yacc"
{ yyval.ival = DATA_Y2; }
    break;
case 694:
#line 4532 "pars.yacc"
{ yyval.ival = DATA_Y3; }
    break;
case 695:
#line 4533 "pars.yacc"
{ yyval.ival = DATA_Y4; }
    break;
case 696:
#line 4536 "pars.yacc"
{ yyval.ival = ASCENDING; }
    break;
case 697:
#line 4537 "pars.yacc"
{ yyval.ival = DESCENDING; }
    break;
case 698:
#line 4540 "pars.yacc"
{ yyval.ival = DATA_X; }
    break;
case 699:
#line 4541 "pars.yacc"
{ yyval.ival = DATA_Y; }
    break;
case 700:
#line 4544 "pars.yacc"
{ yyval.ival = FFT_DFT; }
    break;
case 701:
#line 4545 "pars.yacc"
{ yyval.ival = FFT_FFT; }
    break;
case 702:
#line 4546 "pars.yacc"
{ yyval.ival = FFT_INVDFT; }
    break;
case 703:
#line 4547 "pars.yacc"
{ yyval.ival = FFT_INVFFT; }
    break;
case 704:
#line 4551 "pars.yacc"
{yyval.ival=0;}
    break;
case 705:
#line 4552 "pars.yacc"
{yyval.ival=1;}
    break;
case 706:
#line 4556 "pars.yacc"
{yyval.ival=0;}
    break;
case 707:
#line 4557 "pars.yacc"
{yyval.ival=1;}
    break;
case 708:
#line 4558 "pars.yacc"
{yyval.ival=2;}
    break;
case 709:
#line 4562 "pars.yacc"
{yyval.ival=0;}
    break;
case 710:
#line 4563 "pars.yacc"
{yyval.ival=1;}
    break;
case 711:
#line 4564 "pars.yacc"
{yyval.ival=2;}
    break;
case 712:
#line 4568 "pars.yacc"
{yyval.ival=0;}
    break;
case 713:
#line 4569 "pars.yacc"
{yyval.ival=1;}
    break;
case 714:
#line 4570 "pars.yacc"
{yyval.ival=2;}
    break;
case 715:
#line 4571 "pars.yacc"
{yyval.ival=3;}
    break;
case 716:
#line 4572 "pars.yacc"
{yyval.ival=4;}
    break;
case 717:
#line 4573 "pars.yacc"
{yyval.ival=5;}
    break;
case 718:
#line 4574 "pars.yacc"
{yyval.ival=6;}
    break;
case 719:
#line 4578 "pars.yacc"
{ yyval.ival = INTERP_LINEAR; }
    break;
case 720:
#line 4579 "pars.yacc"
{ yyval.ival = INTERP_SPLINE; }
    break;
case 721:
#line 4580 "pars.yacc"
{ yyval.ival = INTERP_ASPLINE; }
    break;
case 722:
#line 4583 "pars.yacc"
{ yyval.ival = MINP; }
    break;
case 723:
#line 4584 "pars.yacc"
{ yyval.ival = MAXP; }
    break;
case 724:
#line 4585 "pars.yacc"
{ yyval.ival = AVG; }
    break;
case 725:
#line 4586 "pars.yacc"
{ yyval.ival = SD; }
    break;
case 726:
#line 4587 "pars.yacc"
{ yyval.ival = SUM; }
    break;
case 727:
#line 4588 "pars.yacc"
{ yyval.ival = IMIN; }
    break;
case 728:
#line 4589 "pars.yacc"
{ yyval.ival = IMAX; }
    break;
case 729:
#line 4594 "pars.yacc"
{
            yyval.ival = get_mapped_font(yyvsp[0].ival);
        }
    break;
case 730:
#line 4598 "pars.yacc"
{
            yyval.ival = get_font_by_name(yyvsp[0].sval);
            xfree(yyvsp[0].sval);
        }
    break;
case 731:
#line 4606 "pars.yacc"
{
	    int lines = yyvsp[0].ival;
            if (lines >= 0 && lines < number_of_linestyles()) {
	        yyval.ival = lines;
	    } else {
	        errmsg("invalid linestyle");
	        yyval.ival = 1;
	    }
        }
    break;
case 732:
#line 4619 "pars.yacc"
{
	    int patno = yyvsp[0].ival;
            if (patno >= 0 && patno < number_of_patterns()) {
	        yyval.ival = patno;
	    } else {
	        errmsg("invalid pattern number");
	        yyval.ival = 1;
	    }
        }
    break;
case 733:
#line 4632 "pars.yacc"
{
            int c = yyvsp[0].ival;
            if (c >= 0 && c < number_of_colors()) {
                yyval.ival = c;
            } else {
                errmsg("Invalid color ID");
                yyval.ival = 1;
            }
        }
    break;
case 734:
#line 4642 "pars.yacc"
{
            int c = get_color_by_name(yyvsp[0].sval);
            if (c == BAD_COLOR) {
                errmsg("Invalid color name");
                c = 1;
            }
            xfree(yyvsp[0].sval);
            yyval.ival = c;
        }
    break;
case 735:
#line 4652 "pars.yacc"
{
            int c;
            CMap_entry cmap;
            cmap.rgb.red = yyvsp[-5].ival;
            cmap.rgb.green = yyvsp[-3].ival;
            cmap.rgb.blue = yyvsp[-1].ival;
            cmap.ctype = COLOR_MAIN;
            cmap.cname = NULL;
            c = add_color(cmap);
            if (c == BAD_COLOR) {
                errmsg("Can't allocate requested color");
                c = 1;
            }
            yyval.ival = c;
        }
    break;
case 736:
#line 4671 "pars.yacc"
{
            double linew;
            linew = yyvsp[0].dval;
            if (linew < 0.0) {
                yyerror("Negative linewidth");
                linew = 0.0;
            } else if (linew > MAX_LINEWIDTH) {
                yyerror("Linewidth too large");
                linew = MAX_LINEWIDTH;
            }
            yyval.dval = linew;
        }
    break;
case 737:
#line 4686 "pars.yacc"
{
            yyval.ival = yyvsp[0].ival;
        }
    break;
case 738:
#line 4691 "pars.yacc"
{ yyval.ival = PLACEMENT_NORMAL; }
    break;
case 739:
#line 4692 "pars.yacc"
{ yyval.ival = PLACEMENT_OPPOSITE; }
    break;
case 740:
#line 4693 "pars.yacc"
{ yyval.ival = PLACEMENT_BOTH; }
    break;
case 741:
#line 4699 "pars.yacc"
{
            int wpp, hpp;
            if (yyvsp[0].ival == PAGE_ORIENT_LANDSCAPE) {
                wpp = 792;
                hpp = 612;
            } else {
                wpp = 612;
                hpp = 792;
            }
            set_page_dimensions(wpp, hpp, FALSE);
        }
    break;
case 742:
#line 4710 "pars.yacc"
{
            set_page_dimensions((int) yyvsp[-1].dval, (int) yyvsp[0].dval, FALSE);
        }
    break;
case 743:
#line 4713 "pars.yacc"
{
	    scroll_proc(yyvsp[0].ival);
	}
    break;
case 744:
#line 4716 "pars.yacc"
{
	    scrollinout_proc(yyvsp[0].ival);
	}
    break;
case 745:
#line 4720 "pars.yacc"
{
	}
    break;
case 746:
#line 4724 "pars.yacc"
{
	    add_world(whichgraph, yyvsp[-14].dval, yyvsp[-12].dval, yyvsp[-10].dval, yyvsp[-8].dval);
	}
    break;
case 747:
#line 4728 "pars.yacc"
{filltype_obs = yyvsp[0].ival;}
    break;
case 748:
#line 4730 "pars.yacc"
{filltype_obs = yyvsp[0].ival;}
    break;
case 749:
#line 4732 "pars.yacc"
{ }
    break;
case 750:
#line 4734 "pars.yacc"
{ }
    break;
case 751:
#line 4736 "pars.yacc"
{ }
    break;
case 752:
#line 4737 "pars.yacc"
{ }
    break;
case 753:
#line 4739 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    if (yyvsp[0].ival == FALSE && get_project_version() <= 40102) {
                g[whichgraph].l.boxpen.pattern = 0;
            }
	}
    break;
case 754:
#line 4748 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.legx = yyvsp[0].dval;
	}
    break;
case 755:
#line 4755 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].l.legy = yyvsp[0].dval;
	}
    break;
case 756:
#line 4762 "pars.yacc"
{
	    if (is_valid_setno(whichgraph, yyvsp[-1].ival)) {
                strncpy(g[whichgraph].p[yyvsp[-1].ival].lstr, yyvsp[0].sval, MAX_STRING_LENGTH - 1);
	    } else {
                yyerror("Unallocated set");
            }
            xfree(yyvsp[0].sval);
	}
    break;
case 757:
#line 4770 "pars.yacc"
{ }
    break;
case 758:
#line 4771 "pars.yacc"
{filltype_obs = yyvsp[0].ival;}
    break;
case 759:
#line 4772 "pars.yacc"
{ }
    break;
case 760:
#line 4773 "pars.yacc"
{ }
    break;
case 761:
#line 4775 "pars.yacc"
{ }
    break;
case 762:
#line 4777 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_XY;
	    g[yyvsp[-2].ival].xscale = SCALE_LOG;
	}
    break;
case 763:
#line 4781 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_XY;
	    g[yyvsp[-2].ival].yscale = SCALE_LOG;
	}
    break;
case 764:
#line 4786 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_XY;
	    g[yyvsp[-2].ival].xscale = SCALE_LOG;
	    g[yyvsp[-2].ival].yscale = SCALE_LOG;
	}
    break;
case 765:
#line 4792 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_CHART;
	    g[yyvsp[-2].ival].xyflip = FALSE;
	    g[yyvsp[-2].ival].stacked = FALSE;
	}
    break;
case 766:
#line 4798 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_CHART;
	    g[yyvsp[-2].ival].xyflip = TRUE;
	}
    break;
case 767:
#line 4803 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_CHART;
	    g[yyvsp[-2].ival].stacked = TRUE;
	}
    break;
case 768:
#line 4808 "pars.yacc"
{ 
	    g[yyvsp[-2].ival].type = GRAPH_CHART;
	    g[yyvsp[-2].ival].stacked = TRUE;
	    g[yyvsp[-2].ival].xyflip = TRUE;
	}
    break;
case 769:
#line 4814 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].w.xg1 = yyvsp[0].dval;
	}
    break;
case 770:
#line 4821 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].w.xg2 = yyvsp[0].dval;
	}
    break;
case 771:
#line 4828 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].w.yg1 = yyvsp[0].dval;
	}
    break;
case 772:
#line 4835 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].w.yg2 = yyvsp[0].dval;
	}
    break;
case 773:
#line 4843 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].v.xv1 = yyvsp[0].dval;
	}
    break;
case 774:
#line 4850 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].v.xv2 = yyvsp[0].dval;
	}
    break;
case 775:
#line 4857 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].v.yv1 = yyvsp[0].dval;
	}
    break;
case 776:
#line 4864 "pars.yacc"
{
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
	    g[whichgraph].v.yv2 = yyvsp[0].dval;
	}
    break;
case 777:
#line 4872 "pars.yacc"
{
	}
    break;
case 778:
#line 4875 "pars.yacc"
{ 
	    if (!is_valid_gno(whichgraph)) {
                yyerror("No valid graph selected");
                return 1;
            }
            g[whichgraph].f.fillpen.pattern = yyvsp[0].ival;
        }
    break;
case 779:
#line 4883 "pars.yacc"
{
        }
    break;
case 780:
#line 4885 "pars.yacc"
{
        }
    break;
case 781:
#line 4888 "pars.yacc"
{
	    line_asize = 2.0*yyvsp[0].dval;
	}
    break;
case 782:
#line 4892 "pars.yacc"
{ }
    break;
case 783:
#line 4893 "pars.yacc"
{ }
    break;
case 784:
#line 4894 "pars.yacc"
{ }
    break;
case 785:
#line 4895 "pars.yacc"
{ }
    break;
case 786:
#line 4900 "pars.yacc"
{ }
    break;
case 787:
#line 4901 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->label_op = yyvsp[0].ival;
	}
    break;
case 788:
#line 4911 "pars.yacc"
{
	    switch (yyvsp[0].ival){
	    case 0:
	        g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symfillpen.pattern = 0;
	        break;
	    case 1:
	        g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symfillpen.pattern = 1;
	        break;
	    case 2:
	        g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symfillpen.pattern = 1;
	        g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].symfillpen.color = getbgcolor();
	        break;
	    }
	}
    break;
case 789:
#line 4926 "pars.yacc"
{
	    g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].symskip = yyvsp[0].ival;
	}
    break;
case 790:
#line 4930 "pars.yacc"
{
	    switch (yyvsp[0].ival) {
            case 0:
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].filltype = SETFILL_NONE;
                break;
            case 1:
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].filltype = SETFILL_POLYGON;
                break;
            case 2:
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].filltype = SETFILL_BASELINE;
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].baseline_type = BASELINE_TYPE_0;
                break;
            case 6:
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].filltype = SETFILL_BASELINE;
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].baseline_type = BASELINE_TYPE_GMIN;
                break;
            case 7:
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].filltype = SETFILL_BASELINE;
                g[yyvsp[-2].trgt->gno].p[yyvsp[-2].trgt->setno].baseline_type = BASELINE_TYPE_GMAX;
                break;
            }
	}
    break;
case 791:
#line 4952 "pars.yacc"
{
	    g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].errbar.ptype = yyvsp[0].ival;
	}
    break;
case 792:
#line 4960 "pars.yacc"
{ }
    break;
case 793:
#line 4961 "pars.yacc"
{
	    g[yyvsp[-1].trgt->gno].p[yyvsp[-1].trgt->setno].lines = yyvsp[0].ival;
	}
    break;
case 794:
#line 4964 "pars.yacc"
{
	    g[yyvsp[-1].trgt->gno].p[yyvsp[-1].trgt->setno].linew = yyvsp[0].dval;
	}
    break;
case 795:
#line 4967 "pars.yacc"
{
	    g[yyvsp[-1].trgt->gno].p[yyvsp[-1].trgt->setno].linepen.color = yyvsp[0].ival;
	}
    break;
case 796:
#line 4970 "pars.yacc"
{filltype_obs = yyvsp[0].ival;}
    break;
case 797:
#line 4971 "pars.yacc"
{ }
    break;
case 798:
#line 4972 "pars.yacc"
{
            g[yyvsp[-3].trgt->gno].p[yyvsp[-3].trgt->setno].errbar.barsize = yyvsp[0].dval;
	}
    break;
case 799:
#line 4975 "pars.yacc"
{ }
    break;
case 800:
#line 4980 "pars.yacc"
{
	    /* <= xmgr-4.1 */
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->active = yyvsp[0].ival;
	}
    break;
case 801:
#line 4988 "pars.yacc"
{ }
    break;
case 802:
#line 4989 "pars.yacc"
{ }
    break;
case 803:
#line 4990 "pars.yacc"
{ }
    break;
case 804:
#line 4991 "pars.yacc"
{ }
    break;
case 805:
#line 4992 "pars.yacc"
{ }
    break;
case 806:
#line 4993 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_spec = TICKS_SPEC_NONE;
	}
    break;
case 807:
#line 5000 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    if (g[whichgraph].t[naxis]->t_spec != TICKS_SPEC_BOTH) {
                g[whichgraph].t[naxis]->t_spec = TICKS_SPEC_MARKS;
            }
	}
    break;
case 808:
#line 5009 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    if (yyvsp[0].dval != 0.0) {
                g[whichgraph].t[naxis]->nminor = 
                            (int) rint(g[whichgraph].t[naxis]->tmajor / yyvsp[0].dval - 1);
            } else {
                g[whichgraph].t[naxis]->nminor = 0;
            }
	}
    break;
case 809:
#line 5021 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->props.size = yyvsp[0].dval;
	}
    break;
case 810:
#line 5028 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].wtpos = yyvsp[0].dval;
	    g[whichgraph].t[naxis]->tloc[yyvsp[-2].ival].type = TICK_TYPE_MAJOR;
	}
    break;
case 811:
#line 5036 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_op = yyvsp[0].ival;
	}
    break;
case 812:
#line 5046 "pars.yacc"
{ }
    break;
case 813:
#line 5047 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    if (g[whichgraph].t[naxis]->t_spec == TICKS_SPEC_BOTH) {
                g[whichgraph].t[naxis]->t_spec = TICKS_SPEC_MARKS;
            }
	}
    break;
case 814:
#line 5056 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->t_spec = TICKS_SPEC_BOTH;
	}
    break;
case 815:
#line 5063 "pars.yacc"
{ }
    break;
case 816:
#line 5065 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_angle = 0;
	}
    break;
case 817:
#line 5072 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_angle = 90;
	}
    break;
case 818:
#line 5079 "pars.yacc"
{ }
    break;
case 819:
#line 5080 "pars.yacc"
{ }
    break;
case 820:
#line 5081 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    g[whichgraph].t[naxis]->tl_op = yyvsp[0].ival;
	}
    break;
case 821:
#line 5088 "pars.yacc"
{
	    if (!is_valid_axis(whichgraph, naxis)) {
                yyerror("No valid axis selected");
                return 1;
            }
	    switch(yyvsp[0].ival) {
            case SIGN_NEGATE:
                g[whichgraph].t[naxis]->tl_formula =
                    copy_string(g[whichgraph].t[naxis]->tl_formula, "-$t");
                break;
            case SIGN_ABSOLUTE:
                g[whichgraph].t[naxis]->tl_formula =
                    copy_string(g[whichgraph].t[naxis]->tl_formula, "abs($t)");
                break;
            default:
                g[whichgraph].t[naxis]->tl_formula =
                    copy_string(g[whichgraph].t[naxis]->tl_formula, NULL);
                break;
            }
	}
    break;
case 825:
#line 5116 "pars.yacc"
{
            yyval.ival = yyvsp[0].ival;
        }
    break;
case 826:
#line 5121 "pars.yacc"
{ yyval.ival = PLACEMENT_OPPOSITE; }
    break;
case 827:
#line 5122 "pars.yacc"
{ yyval.ival = PLACEMENT_NORMAL; }
    break;
case 828:
#line 5123 "pars.yacc"
{ yyval.ival = PLACEMENT_NORMAL; }
    break;
case 829:
#line 5124 "pars.yacc"
{ yyval.ival = PLACEMENT_OPPOSITE; }
    break;
case 830:
#line 5125 "pars.yacc"
{ yyval.ival = PLACEMENT_BOTH; }
    break;
}

#line 705 "/usr/share/bison/bison.simple"


  yyvsp -= yylen;
  yyssp -= yylen;
#if YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;
#if YYLSP_NEEDED
  *++yylsp = yyloc;
#endif

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[YYTRANSLATE (yychar)]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[YYTRANSLATE (yychar)]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* defined (YYERROR_VERBOSE) */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*--------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action |
`--------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;
      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;


/*-------------------------------------------------------------------.
| yyerrdefault -- current state does not do anything special for the |
| error token.                                                       |
`-------------------------------------------------------------------*/
yyerrdefault:
#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */

  /* If its default is to accept any token, ok.  Otherwise pop it.  */
  yyn = yydefact[yystate];
  if (yyn)
    goto yydefault;
#endif


/*---------------------------------------------------------------.
| yyerrpop -- pop the current state because it cannot handle the |
| error token                                                    |
`---------------------------------------------------------------*/
yyerrpop:
  if (yyssp == yyss)
    YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#if YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "Error: state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

/*--------------.
| yyerrhandle.  |
`--------------*/
yyerrhandle:
  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

/*---------------------------------------------.
| yyoverflowab -- parser overflow comes here.  |
`---------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}
#line 5128 "pars.yacc"


/* list of intrinsic functions and keywords */
symtab_entry ikey[] = {
	{"A0", FITPARM, NULL},
	{"A0MAX", FITPMAX, NULL},
	{"A0MIN", FITPMIN, NULL},
	{"A1", FITPARM, NULL},
	{"A1MAX", FITPMAX, NULL},
	{"A1MIN", FITPMIN, NULL},
	{"A2", FITPARM, NULL},
	{"A2MAX", FITPMAX, NULL},
	{"A2MIN", FITPMIN, NULL},
	{"A3", FITPARM, NULL},
	{"A3MAX", FITPMAX, NULL},
	{"A3MIN", FITPMIN, NULL},
	{"A4", FITPARM, NULL},
	{"A4MAX", FITPMAX, NULL},
	{"A4MIN", FITPMIN, NULL},
	{"A5", FITPARM, NULL},
	{"A5MAX", FITPMAX, NULL},
	{"A5MIN", FITPMIN, NULL},
	{"A6", FITPARM, NULL},
	{"A6MAX", FITPMAX, NULL},
	{"A6MIN", FITPMIN, NULL},
	{"A7", FITPARM, NULL},
	{"A7MAX", FITPMAX, NULL},
	{"A7MIN", FITPMIN, NULL},
	{"A8", FITPARM, NULL},
	{"A8MAX", FITPMAX, NULL},
	{"A8MIN", FITPMIN, NULL},
	{"A9", FITPARM, NULL},
	{"A9MAX", FITPMAX, NULL},
	{"A9MIN", FITPMIN, NULL},
	{"ABOVE", ABOVE, NULL},
	{"ABS", FUNC_D, (void *) fabs},
	{"ABSOLUTE", ABSOLUTE, NULL},
	{"ACOS", FUNC_D, (void *) acos},
	{"ACOSH", FUNC_D, (void *) acosh},
	{"AI", FUNC_D, (void *) ai_wrap},
	{"ALIAS", ALIAS, NULL},
	{"ALT", ALT, NULL},
	{"ALTXAXIS", ALTXAXIS, NULL},
	{"ALTYAXIS", ALTYAXIS, NULL},
	{"AND", AND, NULL},
	{"ANGLE", ANGLE, NULL},
	{"ANTIALIASING", ANTIALIASING, NULL},
	{"APPEND", APPEND, NULL},
	{"ARRANGE", ARRANGE, NULL},
	{"ARROW", ARROW, NULL},
	{"ASCENDING", ASCENDING, NULL},
	{"ASIN", FUNC_D, (void *) asin},
	{"ASINH", FUNC_D, (void *) asinh},
	{"ASPLINE", ASPLINE, NULL},
	{"ATAN", FUNC_D, (void *) atan},
	{"ATAN2", FUNC_DD, (void *) atan2},
	{"ATANH", FUNC_D, (void *) atanh},
	{"AUTO", AUTO, NULL},
	{"AUTOSCALE", AUTOSCALE, NULL},
	{"AUTOTICKS", AUTOTICKS, NULL},
	{"AVALUE", AVALUE, NULL},
	{"AVG", AVG, NULL},
	{"BACKGROUND", BACKGROUND, NULL},
	{"BAR", BAR, NULL},
	{"BARDY", BARDY, NULL},
	{"BARDYDY", BARDYDY, NULL},
	{"BASELINE", BASELINE, NULL},
	{"BATCH", BATCH, NULL},
        {"BEGIN", BEGIN, NULL},
	{"BELOW", BELOW, NULL},
	{"BETA", FUNC_DD, (void *) beta},
	{"BETWEEN", BETWEEN, NULL},
	{"BI", FUNC_D, (void *) bi_wrap},
	{"BLACKMAN", BLACKMAN, NULL},
	{"BLOCK", BLOCK, NULL},
	{"BOTH", BOTH, NULL},
	{"BOTTOM", BOTTOM, NULL},
	{"BOX", BOX, NULL},
	{"CD", CD, NULL},
	{"CEIL", FUNC_D, (void *) ceil},
	{"CENTER", CENTER, NULL},
	{"CHAR", CHAR, NULL},
	{"CHART", CHART, NULL},
	{"CHDTR", FUNC_DD, (void *) chdtr},
	{"CHDTRC", FUNC_DD, (void *) chdtrc},
	{"CHDTRI", FUNC_DD, (void *) chdtri},
	{"CHI", FUNC_D, (void *) chi_wrap},
	{"CHRSTR", CHRSTR, NULL},
	{"CI", FUNC_D, (void *) ci_wrap},
	{"CLEAR", CLEAR, NULL},
	{"CLICK", CLICK, NULL},
	{"CLIP", CLIP, NULL},
	{"CLOSE", CLOSE, NULL},
	{"COEFFICIENTS", COEFFICIENTS, NULL},
	{"COLOR", COLOR, NULL},
	{"COMMENT", COMMENT, NULL},
	{"COMPLEX", COMPLEX, NULL},
	{"CONST", KEY_CONST, NULL},
	{"CONSTRAINTS", CONSTRAINTS, NULL},
	{"COPY", COPY, NULL},
	{"COS", FUNC_D, (void *) cos},
	{"COSH", FUNC_D, (void *) cosh},
	{"CYCLE", CYCLE, NULL},
	{"DATE", DATE, NULL},
	{"DAWSN", FUNC_D, (void *) dawsn},
	{"DAYMONTH", DAYMONTH, NULL},
	{"DAYOFWEEKL", DAYOFWEEKL, NULL},
	{"DAYOFWEEKS", DAYOFWEEKS, NULL},
	{"DAYOFYEAR", DAYOFYEAR, NULL},
	{"DDMMYY", DDMMYY, NULL},
	{"DECIMAL", DECIMAL, NULL},
	{"DEF", DEF, NULL},
	{"DEFAULT", DEFAULT, NULL},
	{"DEFINE", DEFINE, NULL},
	{"DEG", UCONSTANT, (void *) deg_uconst},
	{"DEGREESLAT", DEGREESLAT, NULL},
	{"DEGREESLON", DEGREESLON, NULL},
	{"DEGREESMMLAT", DEGREESMMLAT, NULL},
	{"DEGREESMMLON", DEGREESMMLON, NULL},
	{"DEGREESMMSSLAT", DEGREESMMSSLAT, NULL},
	{"DEGREESMMSSLON", DEGREESMMSSLON, NULL},
	{"DESCENDING", DESCENDING, NULL},
	{"DESCRIPTION", DESCRIPTION, NULL},
	{"DEVICE", DEVICE, NULL},
	{"DFT", DFT, NULL},
	{"DIFF", DIFFERENCE, NULL},
	{"DIFFERENCE", DIFFERENCE, NULL},
	{"DISK", DISK, NULL},
	{"DOWN", DOWN, NULL},
	{"DPI", DPI, NULL},
	{"DROP", DROP, NULL},
	{"DROPLINE", DROPLINE, NULL},
	{"ECHO", ECHO, NULL},
	{"ELLIE", FUNC_DD, (void *) ellie},
	{"ELLIK", FUNC_DD, (void *) ellik},
	{"ELLIPSE", ELLIPSE, NULL},
	{"ELLPE", FUNC_D, (void *) ellpe_wrap},
	{"ELLPK", FUNC_D, (void *) ellpk_wrap},
	{"ENGINEERING", ENGINEERING, NULL},
	{"EQ", EQ, NULL},
	{"ER", ERRORBAR, NULL},
	{"ERF", FUNC_D, (void *) erf},
	{"ERFC", FUNC_D, (void *) erfc},
	{"ERRORBAR", ERRORBAR, NULL},
	{"EXIT", EXIT, NULL},
	{"EXP", FUNC_D, (void *) exp},
	{"EXPN", FUNC_ND, (void *) expn},
	{"EXPONENTIAL", EXPONENTIAL, NULL},
	{"FAC", FUNC_I, (void *) fac},
	{"FALSE", OFF, NULL},
	{"FDTR", FUNC_NND, (void *) fdtr},
	{"FDTRC", FUNC_NND, (void *) fdtrc},
	{"FDTRI", FUNC_NND, (void *) fdtri},
	{"FFT", FFT, NULL},
	{"FILE", FILEP, NULL},
	{"FILL", FILL, NULL},
	{"FIT", FIT, NULL},
	{"FIXED", FIXED, NULL},
	{"FIXEDPOINT", FIXEDPOINT, NULL},
	{"FLOOR", FUNC_D, (void *) floor},
	{"FLUSH", FLUSH, NULL},
	{"FOCUS", FOCUS, NULL},
	{"FOLLOWS", FOLLOWS, NULL},
	{"FONT", FONTP, NULL},
	{"FORCE", FORCE, NULL},
	{"FORMAT", FORMAT, NULL},
	{"FORMULA", FORMULA, NULL},
	{"FRAME", FRAMEP, NULL},
	{"FREE", FREE, NULL},
	{"FREQUENCY", FREQUENCY, NULL},
	{"FRESNLC", FUNC_D, (void *) fresnlc_wrap},
	{"FRESNLS", FUNC_D, (void *) fresnls_wrap},
	{"FROM", FROM, NULL},
	{"F_OF_D", KEY_FUNC_D, NULL},
	{"F_OF_DD", KEY_FUNC_DD, NULL},
        {"F_OF_I", KEY_FUNC_I, NULL},
	{"F_OF_ND", KEY_FUNC_ND, NULL},
	{"F_OF_NN", KEY_FUNC_NN, NULL},
	{"F_OF_NND", KEY_FUNC_NND, NULL},
	{"F_OF_PPD", KEY_FUNC_PPD, NULL},
	{"F_OF_PPPD", KEY_FUNC_PPPD, NULL},
	{"F_OF_PPPPD", KEY_FUNC_PPPPD, NULL},
	{"F_OF_PPPPPD", KEY_FUNC_PPPPPD, NULL},
	{"GAMMA", FUNC_D, (void *) true_gamma},
	{"GDTR", FUNC_PPD, (void *) gdtr},
	{"GDTRC", FUNC_PPD, (void *) gdtrc},
	{"GE", GE, NULL},
	{"GENERAL", GENERAL, NULL},
	{"GETP", GETP, NULL},
	{"GRAPH", GRAPH, NULL},
	{"GRID", GRID, NULL},
	{"GT", GT, NULL},
	{"HAMMING", HAMMING, NULL},
	{"HANNING", HANNING, NULL},
	{"HARDCOPY", HARDCOPY, NULL},
	{"HBAR", HBAR, NULL},
	{"HELP", HELP, NULL},
	{"HGAP", HGAP, NULL},
	{"HIDDEN", HIDDEN, NULL},
	{"HISTOGRAM", HISTOGRAM, NULL},
	{"HMS", HMS, NULL},
	{"HORIZI", HORIZI, NULL},
	{"HORIZO", HORIZO, NULL},
	{"HORIZONTAL", HORIZONTAL, NULL},
	{"HYP2F1", FUNC_PPPD, (void *) hyp2f1},
	{"HYPERG", FUNC_PPD, (void *) hyperg},
	{"HYPOT", FUNC_DD, (void *) hypot},
	{"I0E", FUNC_D, (void *) i0e},
	{"I1E", FUNC_D, (void *) i1e},
	{"ID", ID, NULL},
	{"IFILTER", IFILTER, NULL},
	{"IGAM", FUNC_DD, (void *) igam},
	{"IGAMC", FUNC_DD, (void *) igamc},
	{"IGAMI", FUNC_DD, (void *) igami},
	{"IMAX", IMAX, NULL},
	{"IMIN", IMIN, NULL},
	{"IN", IN, NULL},
	{"INCBET", FUNC_PPD, (void *) incbet},
	{"INCBI", FUNC_PPD, (void *) incbi},
	{"INCREMENT", INCREMENT, NULL},
	{"INDEX", INDEX, NULL},
	{"INOUT", INOUT, NULL},
	{"INT", INT, NULL},
	{"INTEGRATE", INTEGRATE, NULL},
	{"INTERPOLATE", INTERPOLATE, NULL},
	{"INVDFT", INVDFT, NULL},
	{"INVERT", INVERT, NULL},
	{"INVFFT", INVFFT, NULL},
	{"IRAND", FUNC_I, (void *) irand_wrap},
	{"IV", FUNC_DD, (void *) iv_wrap},
	{"JUST", JUST, NULL},
	{"JV", FUNC_DD, (void *) jv_wrap},
	{"K0E", FUNC_D, (void *) k0e},
	{"K1E", FUNC_D, (void *) k1e},
	{"KILL", KILL, NULL},
	{"KN", FUNC_ND, (void *) kn_wrap},
	{"LABEL", LABEL, NULL},
	{"LANDSCAPE", LANDSCAPE, NULL},
	{"LAYOUT", LAYOUT, NULL},
	{"LBETA", FUNC_DD, (void *) lbeta},
	{"LE", LE, NULL},
	{"LEFT", LEFT, NULL},
	{"LEGEND", LEGEND, NULL},
	{"LENGTH", LENGTH, NULL},
	{"LGAMMA", FUNC_D, (void *) lgamma},
	{"LINE", LINE, NULL},
	{"LINEAR", LINEAR, NULL},
	{"LINESTYLE", LINESTYLE, NULL},
	{"LINEWIDTH", LINEWIDTH, NULL},
	{"LINK", LINK, NULL},
	{"LN", FUNC_D, (void *) log},
	{"LOAD", LOAD, NULL},
	{"LOCTYPE", LOCTYPE, NULL},
	{"LOG", LOG, NULL},
	{"LOG10", FUNC_D, (void *) log10},
	{"LOG2", FUNC_D, (void *) log2},
	{"LOGARITHMIC", LOGARITHMIC, NULL},
	{"LOGX", LOGX, NULL},
	{"LOGXY", LOGXY, NULL},
	{"LOGY", LOGY, NULL},
	{"LOGIT", LOGIT, NULL},
	{"LT", LT, NULL},
	{"MAGIC", MAGIC, NULL},
	{"MAGNITUDE", MAGNITUDE, NULL},
	{"MAJOR", MAJOR, NULL},
	{"MAP", MAP, NULL},
	{"MAX", MAXP, NULL},
	{"MAXOF", FUNC_DD, (void *) max_wrap},
	{"MESH", MESH, NULL},
	{"MIN", MINP, NULL},
	{"MINOF", FUNC_DD, (void *) min_wrap},
	{"MINOR", MINOR, NULL},
	{"MMDD", MMDD, NULL},
	{"MMDDHMS", MMDDHMS, NULL},
	{"MMDDYY", MMDDYY, NULL},
	{"MMDDYYHMS", MMDDYYHMS, NULL},
	{"MMSSLAT", MMSSLAT, NULL},
	{"MMSSLON", MMSSLON, NULL},
	{"MMYY", MMYY, NULL},
	{"MOD", FUNC_DD, (void *) fmod},
	{"MONTHDAY", MONTHDAY, NULL},
	{"MONTHL", MONTHL, NULL},
	{"MONTHS", MONTHS, NULL},
	{"MONTHSY", MONTHSY, NULL},
	{"MOVE", MOVE, NULL},
	{"NDTR", FUNC_D, (void *) ndtr},
	{"NDTRI", FUNC_D, (void *) ndtri},
	{"NE", NE, NULL},
	{"NEGATE", NEGATE, NULL},
	{"NEW", NEW, NULL},
	{"NONE", NONE, NULL},
	{"NONLFIT", NONLFIT, NULL},
	{"NORM", FUNC_D, (void *) fx},
	{"NORMAL", NORMAL, NULL},
	{"NOT", NOT, NULL},
	{"NXY", NXY, NULL},
	{"OFF", OFF, NULL},
	{"OFFSET", OFFSET, NULL},
	{"OFFSETX", OFFSETX, NULL},
	{"OFFSETY", OFFSETY, NULL},
	{"OFILTER", OFILTER, NULL},
	{"ON", ON, NULL},
	{"ONREAD", ONREAD, NULL},
	{"OP", OP, NULL},
	{"OPPOSITE", OPPOSITE, NULL},
	{"OR", OR, NULL},
	{"OUT", OUT, NULL},
	{"PAGE", PAGE, NULL},
	{"PARA", PARA, NULL},
	{"PARAMETERS", PARAMETERS, NULL},
	{"PARZEN", PARZEN, NULL},
	{"PATTERN", PATTERN, NULL},
	{"PDTR", FUNC_ND, (void *) pdtr},
	{"PDTRC", FUNC_ND, (void *) pdtrc},
	{"PDTRI", FUNC_ND, (void *) pdtri},
	{"PERIOD", PERIOD, NULL},
	{"PERP", PERP, NULL},
	{"PHASE", PHASE, NULL},
	{"PI", CONSTANT, (void *) pi_const},
	{"PIE", PIE, NULL},
	{"PIPE", PIPE, NULL},
	{"PLACE", PLACE, NULL},
	{"POINT", POINT, NULL},
	{"POLAR", POLAR, NULL},
	{"POLYI", POLYI, NULL},
	{"POLYO", POLYO, NULL},
	{"POP", POP, NULL},
	{"PORTRAIT", PORTRAIT, NULL},
	{"POWER", POWER, NULL},
	{"PREC", PREC, NULL},
	{"PREPEND", PREPEND, NULL},
	{"PRINT", PRINT, NULL},
	{"PS", PS, NULL},
	{"PSI", FUNC_D, (void *) psi},
	{"PUSH", PUSH, NULL},
	{"PUTP", PUTP, NULL},
	{"RAD", UCONSTANT, (void *) rad_uconst},
	{"RAND", RAND, NULL},
	{"READ", READ, NULL},
	{"REAL", REAL, NULL},
	{"RECIPROCAL", RECIPROCAL, NULL},
	{"REDRAW", REDRAW, NULL},
	{"REFERENCE", REFERENCE, NULL},
	{"REGRESS", REGRESS, NULL},
	{"RESIZE", RESIZE, NULL},
	{"RESTRICT", RESTRICT, NULL},
	{"REVERSE", REVERSE, NULL},
	{"RGAMMA", FUNC_D, (void *) rgamma},
	{"RIGHT", RIGHT, NULL},
	{"RINT", FUNC_D, (void *) rint},
	{"RISER", RISER, NULL},
	{"RNORM", FUNC_DD, (void *) rnorm},
	{"ROT", ROT, NULL},
	{"ROUNDED", ROUNDED, NULL},
	{"RSUM", RSUM, NULL},
	{"RULE", RULE, NULL},
	{"RUNAVG", RUNAVG, NULL},
	{"RUNMAX", RUNMAX, NULL},
	{"RUNMED", RUNMED, NULL},
	{"RUNMIN", RUNMIN, NULL},
	{"RUNSTD", RUNSTD, NULL},
	{"SAVEALL", SAVEALL, NULL},
	{"SCALE", SCALE, NULL},
	{"SCIENTIFIC", SCIENTIFIC, NULL},
	{"SCROLL", SCROLL, NULL},
	{"SD", SD, NULL},
	{"SET", SET, NULL},
	{"SFORMAT", SFORMAT, NULL},
	{"SHI", FUNC_D, (void *) shi_wrap},
	{"SI", FUNC_D, (void *) si_wrap},
	{"SIGN", SIGN, NULL},
	{"SIN", FUNC_D, (void *) sin},
	{"SINH", FUNC_D, (void *) sinh},
	{"SIZE", SIZE, NULL},
	{"SKIP", SKIP, NULL},
	{"SLEEP", SLEEP, NULL},
	{"SMITH", SMITH, NULL},
	{"SORT", SORT, NULL},
	{"SOURCE", SOURCE, NULL},
	{"SPEC", SPEC, NULL},
	{"SPENCE", FUNC_D, (void *) spence},
	{"SPLINE", SPLINE, NULL},
	{"SPLIT", SPLIT, NULL},
	{"SQR", FUNC_D, (void *) sqr_wrap},
	{"SQRT", FUNC_D, (void *) sqrt},
	{"STACK", STACK, NULL},
	{"STACKED", STACKED, NULL},
	{"STACKEDBAR", STACKEDBAR, NULL},
	{"STACKEDHBAR", STACKEDHBAR, NULL},
	{"STAGGER", STAGGER, NULL},
	{"START", START, NULL},
	{"STDTR", FUNC_ND, (void *) stdtr},
	{"STDTRI", FUNC_ND, (void *) stdtri},
	{"STOP", STOP, NULL},
	{"STRING", STRING, NULL},
	{"STRUVE", FUNC_DD, (void *) struve},
	{"SUBTITLE", SUBTITLE, NULL},
	{"SUM", SUM, NULL},
	{"SWAP", SWAP, NULL},
	{"SYMBOL", SYMBOL, NULL},
	{"TAN", FUNC_D, (void *) tan},
	{"TANH", FUNC_D, (void *) tanh},
	{"TARGET", TARGET, NULL},
	{"TICK", TICKP, NULL},
	{"TICKLABEL", TICKLABEL, NULL},
	{"TICKS", TICKSP, NULL},
	{"TIMER", TIMER, NULL},
	{"TIMESTAMP", TIMESTAMP, NULL},
	{"TITLE", TITLE, NULL},
	{"TO", TO, NULL},
	{"TOP", TOP, NULL},
	{"TRIANGULAR", TRIANGULAR, NULL},
	{"TRUE", ON, NULL},
	{"TYPE", TYPE, NULL},
	{"UNIT", KEY_UNIT, NULL},
	{"UP", UP, NULL},
	{"UPDATEALL", UPDATEALL, NULL},
	{"USE", USE, NULL},
	{"VERSION", VERSION, NULL},
	{"VERTI", VERTI, NULL},
	{"VERTICAL", VERTICAL, NULL},
	{"VERTO", VERTO, NULL},
	{"VGAP", VGAP, NULL},
	{"VIEW", VIEW, NULL},
	{"VX1", VX1, NULL},
	{"VX2", VX2, NULL},
	{"VXMAX", VXMAX, NULL},
	{"VY1", VY1, NULL},
	{"VY2", VY2, NULL},
	{"VYMAX", VYMAX, NULL},
	{"WELCH", WELCH, NULL},
	{"WITH", WITH, NULL},
	{"WORLD", WORLD, NULL},
	{"WRAP", WRAP, NULL},
	{"WRITE", WRITE, NULL},
	{"WX1", WX1, NULL},
	{"WX2", WX2, NULL},
	{"WY1", WY1, NULL},
	{"WY2", WY2, NULL},
	{"X", X_TOK, NULL},
	{"X0", X0, NULL},
	{"X1", X1, NULL},
	{"XAXES", XAXES, NULL},
	{"XAXIS", XAXIS, NULL},
	{"XCOR", XCOR, NULL},
	{"XMAX", XMAX, NULL},
	{"XMIN", XMIN, NULL},
	{"XY", XY, NULL},
	{"XYAXES", XYAXES, NULL},
	{"XYBOXPLOT", XYBOXPLOT, NULL},
	{"XYCOLOR", XYCOLOR, NULL},
	{"XYCOLPAT", XYCOLPAT, NULL},
	{"XYDX", XYDX, NULL},
	{"XYDXDX", XYDXDX, NULL},
	{"XYDXDXDYDY", XYDXDXDYDY, NULL},
	{"XYDXDY", XYDXDY, NULL},
	{"XYDY", XYDY, NULL},
	{"XYDYDY", XYDYDY, NULL},
	{"XYHILO", XYHILO, NULL},
	{"XYR", XYR, NULL},
	{"XYSIZE", XYSIZE, NULL},
	{"XYSTRING", XYSTRING, NULL},
	{"XYVMAP", XYVMAP, NULL},
	{"XYZ", XYZ, NULL},
	{"Y", Y_TOK, NULL},
	{"Y0", Y0, NULL},
	{"Y1", Y1, NULL},
	{"Y2", Y2, NULL},
	{"Y3", Y3, NULL},
	{"Y4", Y4, NULL},
	{"YAXES", YAXES, NULL},
	{"YAXIS", YAXIS, NULL},
	{"YEAR", YEAR, NULL},
	{"YMAX", YMAX, NULL},
	{"YMIN", YMIN, NULL},
	{"YV", FUNC_DD, (void *) yv_wrap},
	{"YYMMDD", YYMMDD, NULL},
	{"YYMMDDHMS", YYMMDDHMS, NULL},
	{"ZERO", ZERO, NULL},
	{"ZEROXAXIS", ALTXAXIS, NULL},
	{"ZEROYAXIS", ALTYAXIS, NULL},
	{"ZETA", FUNC_DD, (void *) zeta},
	{"ZETAC", FUNC_D, (void *) zetac},
	{"ZNORM", ZNORM, NULL}
};

static int maxfunc = sizeof(ikey) / sizeof(symtab_entry);

int get_parser_gno(void)
{
    return whichgraph;
}

int set_parser_gno(int gno)
{
    if (is_valid_gno(gno) == TRUE) {
        whichgraph = gno;
        return RETURN_SUCCESS;
    } else {
        return RETURN_FAILURE;
    }
}

int get_parser_setno(void)
{
    return whichset;
}

int set_parser_setno(int gno, int setno)
{
    if (is_valid_setno(gno, setno) == TRUE) {
        whichgraph = gno;
        whichset = setno;
        /* those will usually be overridden except when evaluating
           a _standalone_ vexpr */
        vasgn_gno = gno;
        vasgn_setno = setno;
        return RETURN_SUCCESS;
    } else {
        return RETURN_FAILURE;
    }
}

void realloc_vrbl(grarr *vrbl, int len)
{
    double *a;
    int i, oldlen;
    
    if (vrbl->type != GRARR_VEC) {
        errmsg("Internal error");
        return;
    }
    oldlen = vrbl->length;
    if (oldlen == len) {
        return;
    } else {
        a = xrealloc(vrbl->data, len*SIZEOF_DOUBLE);
        if (a != NULL || len == 0) {
            vrbl->data = a;
            vrbl->length = len;
            for (i = oldlen; i < len; i++) {
                vrbl->data[i] = 0.0;
            }
        } else {
            errmsg("Malloc failed in realloc_vrbl()");
        }
    }
}


#define PARSER_TYPE_VOID    0
#define PARSER_TYPE_EXPR    1
#define PARSER_TYPE_VEXPR   2

static int parser(char *s, int type)
{
    char *seekpos;
    int i;
    
    if (s == NULL || s[0] == '\0') {
        if (type == PARSER_TYPE_VOID) {
            /* don't consider an empty string as error for generic parser */
            return RETURN_SUCCESS;
        } else {
            return RETURN_FAILURE;
        }
    }
    
    strncpy(f_string, s, MAX_PARS_STRING_LENGTH - 2);
    f_string[MAX_PARS_STRING_LENGTH - 2] = '\0';
    strcat(f_string, " ");
    
    seekpos = f_string;

    while ((seekpos - f_string < MAX_PARS_STRING_LENGTH - 1) && (*seekpos == ' ' || *seekpos == '\t')) {
        seekpos++;
    }
    if (*seekpos == '\n' || *seekpos == '#') {
        if (type == PARSER_TYPE_VOID) {
            /* don't consider an empty string as error for generic parser */
            return RETURN_SUCCESS;
        } else {
            return RETURN_FAILURE;
        }
    }
    
    lowtoupper(f_string);
        
    pos = 0;
    interr = 0;
    expr_parsed  = FALSE;
    vexpr_parsed = FALSE;
    
    yyparse();

    /* free temp. arrays; for a vector expression keep the last one
     * (which is none but v_result), given there have been no errors
     * and it's what we've been asked for
     */
    if (vexpr_parsed && !interr && type == PARSER_TYPE_VEXPR) {
        for (i = 0; i < fcnt - 1; i++) {
            free_tmpvrbl(&(freelist[i]));
        }
    } else {
        for (i = 0; i < fcnt; i++) {
            free_tmpvrbl(&(freelist[i]));
        }
    }
    fcnt = 0;
    
    tgtn = 0;
    
    if ((type == PARSER_TYPE_VEXPR && !vexpr_parsed) ||
        (type == PARSER_TYPE_EXPR  && !expr_parsed)) {
        return RETURN_FAILURE;
    } else {
        return (interr ? RETURN_FAILURE:RETURN_SUCCESS);
    }
}

int s_scanner(char *s, double *res)
{
    int retval = parser(s, PARSER_TYPE_EXPR);
    *res = s_result;
    return retval;
}

int v_scanner(char *s, int *reslen, double **vres)
{
    int retval = parser(s, PARSER_TYPE_VEXPR);
    if (retval != RETURN_SUCCESS) {
        return RETURN_FAILURE;
    } else {
        *reslen = v_result->length;
        if (v_result->type == GRARR_TMP) {
            *vres = v_result->data;
            v_result->length = 0;
            v_result->data = NULL;
        } else {
            *vres = copy_data_column(v_result->data, v_result->length);
        }
        return RETURN_SUCCESS;
    }
}

int scanner(char *s)
{
    int retval = parser(s, PARSER_TYPE_VOID);
    if (retval != RETURN_SUCCESS) {
        return RETURN_FAILURE;
    }
    
    if (gotparams) {
	gotparams = FALSE;
        getparms(paramfile);
    }
    
    if (gotread) {
	gotread = FALSE;
        getdata(whichgraph, readfile, cursource, LOAD_SINGLE);
    }
    
    if (gotnlfit) {
	gotnlfit = FALSE;
        do_nonlfit(nlfit_gno, nlfit_setno, nlfit_warray, NULL, nlfit_nsteps);
        XCFREE(nlfit_warray);
    }
    return retval;
}

static void free_tmpvrbl(grarr *vrbl)
{
    if (vrbl->type == GRARR_TMP) {
        vrbl->length = 0;
        XCFREE(vrbl->data);
    }
}

static void copy_vrbl(grarr *dest, grarr *src)
{
    dest->type = src->type;
    dest->data = xmalloc(src->length*SIZEOF_DOUBLE);
    if (dest->data == NULL) {
        errmsg("Malloc failed in copy_vrbl()");
    } else {
        memcpy(dest->data, src->data, src->length*SIZEOF_DOUBLE);
        dest->length = src->length;
    }
}

grarr *get_parser_arr_by_name(char * const name)
{
     int position;
     char *s;
     
     s = copy_string(NULL, name);
     lowtoupper(s);
     
     position = findf(key, s);
     xfree(s);
     
     if (position >= 0) {
         if (key[position].type == KEY_VEC) {
            return (grarr *) key[position].data;
         }
     }
     
     return NULL;
}

grarr *define_parser_arr(char * const name)
{
     if (get_parser_arr_by_name(name) == NULL) {
	symtab_entry tmpkey;
        grarr *var;
        
        var = xmalloc(sizeof(grarr));
        var->type = GRARR_VEC;
        var->length = 0;
        var->data = NULL;
        
	tmpkey.s = name;
	tmpkey.type = KEY_VEC;
	tmpkey.data = (void *) var;
	if (addto_symtab(tmpkey) == RETURN_SUCCESS) {
	    return var;
	} else {
            return NULL;
        }
     } else {
        return NULL;
     }
}

int undefine_parser_var(void *ptr)
{
    int i;
    
    for (i = 0; i < maxfunc; i++) {
	if (key[i].data == ptr) {
            xfree(key[i].s);
            maxfunc--;
            if (i != maxfunc) {
                memmove(&(key[i]), &(key[i + 1]), (maxfunc - i)*sizeof(symtab_entry));
            }
            key = xrealloc(key, maxfunc*sizeof(symtab_entry));
            return RETURN_SUCCESS;
        }
    }
    return RETURN_FAILURE;
}

static int find_set_bydata(double *data, target *tgt)
{
    int gno, setno, ncol;
    
    if (data == NULL) {
        return RETURN_FAILURE;
    } else {
        for (gno = 0; gno < number_of_graphs(); gno++) {
            for (setno = 0; setno < number_of_sets(gno); setno++) {
                for (ncol = 0; ncol < MAX_SET_COLS; ncol++) {
                    if (getcol(gno, setno, ncol) == data) {
                        tgt->gno   = gno;
                        tgt->setno = setno;
                        return RETURN_SUCCESS;
                    }
                }
            }
        }
    }
    return RETURN_FAILURE;
}

static int findf(symtab_entry *keytable, char *s)
{

    int low, high, mid;

    low = 0;
    high = maxfunc - 1;
    while (low <= high) {
	mid = (low + high) / 2;
	if (strcmp(s, keytable[mid].s) < 0) {
	    high = mid - 1;
	} else {
	    if (strcmp(s, keytable[mid].s) > 0) {
		low = mid + 1;
	    } else {
		return (mid);
	    }
	}
    }
    return (-1);
}

static int compare_keys (const void *a, const void *b)
{
    return (int) strcmp (((const symtab_entry*)a)->s,
                         ((const symtab_entry*)b)->s);
}

/* add new entry to the symbol table */
int addto_symtab(symtab_entry newkey)
{
    int position;
    char *s;
    
    s = copy_string(NULL, newkey.s);
    lowtoupper(s);
    if ((position = findf(key, s)) < 0) {
        if ((key = (symtab_entry *) xrealloc(key, (maxfunc + 1)*sizeof(symtab_entry))) != NULL) {
	    key[maxfunc].type = newkey.type;
	    key[maxfunc].data = newkey.data;
	    key[maxfunc].s = s;
	    maxfunc++;
	    qsort(key, maxfunc, sizeof(symtab_entry), compare_keys);
	    return RETURN_SUCCESS;
	} else {
	    xfree(s);
	    return RETURN_FAILURE;
	}
    } else if (alias_force == TRUE) { /* already exists but alias_force enabled */
        key[position].type = newkey.type;
	key[position].data = newkey.data;
	return RETURN_SUCCESS;
    } else {
	xfree(s);
        return RETURN_FAILURE;
    }
}

/* initialize symbol table */
void init_symtab(void)
{
    int i;
    
    if ((key = (symtab_entry *) xmalloc(maxfunc*sizeof(symtab_entry))) != NULL) {
    	memcpy (key, ikey, maxfunc*sizeof(symtab_entry));
	for (i = 0; i < maxfunc; i++) {
	    key[i].s = xmalloc(strlen(ikey[i].s) + 1);
	    strcpy(key[i].s, ikey[i].s);
	}
	qsort(key, maxfunc, sizeof(symtab_entry), compare_keys);
	return;
    } else {
	key = ikey;
	return;
    }
}

static int getcharstr(void)
{
    if (pos >= strlen(f_string))
	 return EOF;
    return (f_string[pos++]);
}

static void ungetchstr(void)
{
    if (pos > 0)
	pos--;
}

static int yylex(void)
{
    int c, i;
    int found;
    char sbuf[MAX_PARS_STRING_LENGTH + 40];

    while ((c = getcharstr()) == ' ' || c == '\t');
    if (c == EOF) {
	return (0);
    }
    if (c == '"') {
	i = 0;
	while ((c = getcharstr()) != '"' && c != EOF) {
	    if (c == '\\') {
		int ctmp;
		ctmp = getcharstr();
		if (ctmp != '"') {
		    ungetchstr();
		}
		else {
		    c = ctmp;
		}
	    }
	    sbuf[i] = c;
	    i++;
	}
	if (c == EOF) {
	    yyerror("Nonterminating string");
	    return 0;
	}
	sbuf[i] = '\0';
	yylval.sval = copy_string(NULL, sbuf);
	return CHRSTR;
    }
    if (c == '.' || isdigit(c)) {
	double d;
	int i, gotdot = 0;

	i = 0;
	while (c == '.' || isdigit(c)) {
	    if (c == '.') {
		if (gotdot) {
		    yyerror("Reading number, too many dots");
	    	    return 0;
		} else {
		    gotdot = 1;
		}
	    }
	    sbuf[i++] = c;
	    c = getcharstr();
	}
	if (c == 'E' || c == 'e') {
	    sbuf[i++] = c;
	    c = getcharstr();
	    if (c == '+' || c == '-') {
		sbuf[i++] = c;
		c = getcharstr();
	    }
	    while (isdigit(c)) {
		sbuf[i++] = c;
		c = getcharstr();
	    }
	}
	if (gotdot && i == 1) {
	    ungetchstr();
	    return '.';
	}
	sbuf[i] = '\0';
	ungetchstr();
	sscanf(sbuf, "%lf", &d);
	yylval.dval = d;
	return NUMBER;
    }
/* graphs, sets, regions resp. */
    if (c == 'G' || c == 'S' || c == 'R') {
	int i = 0, ctmp = c, gn, sn, rn;
	c = getcharstr();
	while (isdigit(c) || c == '$' || c == '_') {
	    sbuf[i++] = c;
	    c = getcharstr();
	}
	if (i == 0) {
	    c = ctmp;
	    ungetchstr();
	} else {
	    ungetchstr();
	    if (ctmp == 'G') {
	        sbuf[i] = '\0';
		if (i == 1 && sbuf[0] == '_') {
                    gn = get_recent_gno();
                } else if (i == 1 && sbuf[0] == '$') {
                    gn = whichgraph;
                } else {
                    gn = atoi(sbuf);
                }
		if (is_valid_gno(gn) || graph_allocate(gn) == RETURN_SUCCESS) {
		    yylval.ival = gn;
		    return GRAPHNO;
		}
	    } else if (ctmp == 'S') {
	        sbuf[i] = '\0';
		if (i == 1 && sbuf[0] == '_') {
                    sn = get_recent_setno();
                } else if (i == 1 && sbuf[0] == '$') {
                    sn = whichset;
                } else {
		    sn = atoi(sbuf);
                }
		yylval.ival = sn;
		return SETNUM;
	    } else if (ctmp == 'R') {
	        sbuf[i] = '\0';
		rn = atoi(sbuf);
		if (rn >= 0 && rn < MAXREGION) {
		    yylval.ival = rn;
		    return REGNUM;
		} else {
                    errmsg("Invalid region number");
                }
	    }
	}
    }
    if (isalpha(c) || c == '$') {
	char *p = sbuf;

	do {
	    *p++ = c;
	} while ((c = getcharstr()) != EOF && (isalpha(c) || isdigit(c) ||
                  c == '_' || c == '$'));
	ungetchstr();
	*p = '\0';
#ifdef DEBUG
        if (get_debuglevel() == 2) {
	    printf("->%s<-\n", sbuf);
	}
#endif
	found = -1;
	if ((found = findf(key, sbuf)) >= 0) {
	    if (key[found].type == FITPARM) {
		int index = sbuf[1] - '0';
		yylval.ival = index;
		return FITPARM;
	    }
	    else if (key[found].type == FITPMAX) {
		int index = sbuf[1] - '0';
		yylval.ival = index;
		return FITPMAX;
	    }
	    else if (key[found].type == FITPMIN) {
		int index = sbuf[1] - '0';
		yylval.ival = index;
		return FITPMIN;
	    }

	    else if (key[found].type == KEY_VAR) {
		yylval.dptr = (double *) key[found].data;
		return VAR_D;
	    }
	    else if (key[found].type == KEY_VEC) {
		yylval.vrbl = (grarr *) key[found].data;
		return VEC_D;
	    }

	    else if (key[found].type == FUNC_I) {
		yylval.ival = found;
		return FUNC_I;
	    }
	    else if (key[found].type == CONSTANT) {
		yylval.ival = found;
		return CONSTANT;
	    }
	    else if (key[found].type == UCONSTANT) {
		yylval.ival = found;
		return UCONSTANT;
	    }
	    else if (key[found].type == FUNC_D) {
		yylval.ival = found;
		return FUNC_D;
	    }
	    else if (key[found].type == FUNC_ND) {
		yylval.ival = found;
		return FUNC_ND;
	    }
	    else if (key[found].type == FUNC_DD) {
		yylval.ival = found;
		return FUNC_DD;
	    }
	    else if (key[found].type == FUNC_NND) {
		yylval.ival = found;
		return FUNC_NND;
	    }
	    else if (key[found].type == FUNC_PPD) {
		yylval.ival = found;
		return FUNC_PPD;
	    }
	    else if (key[found].type == FUNC_PPPD) {
		yylval.ival = found;
		return FUNC_PPPD;
	    }
	    else if (key[found].type == FUNC_PPPPD) {
		yylval.ival = found;
		return FUNC_PPPPD;
	    }
	    else if (key[found].type == FUNC_PPPPPD) {
		yylval.ival = found;
		return FUNC_PPPPPD;
	    }
	    else {
	        yylval.ival = key[found].type;
	        return key[found].type;
	    }
	} else {
	    yylval.sval = copy_string(NULL, sbuf);
	    return NEW_TOKEN;
	}
    }
    switch (c) {
    case '>':
	return follow('=', GE, GT);
    case '<':
	return follow('=', LE, LT);
    case '=':
	return follow('=', EQ, '=');
    case '!':
	return follow('=', NE, NOT);
    case '|':
	return follow('|', OR, '|');
    case '&':
	return follow('&', AND, '&');
    case '\n':
	return '\n';
    default:
	return c;
    }
}

static int follow(int expect, int ifyes, int ifno)
{
    int c = getcharstr();

    if (c == expect) {
	return ifyes;
    }
    ungetchstr();
    return ifno;
}

static void yyerror(char *s)
{
    char *buf;
    
    buf = copy_string(NULL, s);
    buf = concat_strings(buf, ": ");
    buf = concat_strings(buf, f_string);
    errmsg(buf);
    xfree(buf);
    interr = 1;
}
